#include <gtk/gtk.h>

int main(int argc, char *argv[]) {

	GtkWidget *window;
	GtkWidget *xDashButton;
	GtkWidget *xDemoButton;
	GtkWidget *xAppButton;
	GtkWidget *xRecordButton;
	GtkWidget *xOfflineButton;
	GtkWidget *xCloseButton;

	GtkWidget *xRowBox1;
	GtkWidget *xRowBoxSettings1;
	GtkWidget *xRowBox2;
	GtkWidget *xRowBoxSettings2;
	GtkWidget *xColumnBox1;
	GtkWidget *xColumnBoxSettings1;


	GtkWidget *valign;

	gtk_init(&argc, &argv);

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
	gtk_window_set_default_size(GTK_WINDOW(window), 350, 200);
	gtk_window_set_title(GTK_WINDOW(window), "Home Window");
	gtk_container_set_border_width(GTK_CONTAINER(window), 5);

	xRowBox1 = gtk_hbox_new(TRUE, 2);
	xRowBoxSettings1 = gtk_alignment_new(1, 0, 1, 1);

	xRowBox2 = gtk_hbox_new(TRUE, 5);
	xRowBoxSettings2 = gtk_alignment_new(0, 1, 1, 1);


	xDashButton = gtk_button_new_with_label("DASHBOARD");
	gtk_container_add(GTK_CONTAINER(xRowBox1), xDashButton);

	xDemoButton = gtk_button_new_with_label("DEMO MODE");
	gtk_container_add(GTK_CONTAINER(xRowBox1), xDemoButton);

	xAppButton = gtk_button_new_with_label("APP MODE");
	gtk_container_add(GTK_CONTAINER(xRowBox1), xAppButton);

	xRecordButton = gtk_button_new_with_label("RECORD MODE");
	gtk_container_add(GTK_CONTAINER(xRowBox2), xRecordButton);

	xOfflineButton = gtk_button_new_with_label("OFFLINE MODE");
	gtk_container_add(GTK_CONTAINER(xRowBox2), xOfflineButton);

	xCloseButton = gtk_button_new_with_label("CLOSE");
	gtk_container_add(GTK_CONTAINER(xRowBox2), xCloseButton);

	xColumnBox1 = gtk_vbox_new(TRUE, 1);
	xColumnBoxSettings1 = gtk_alignment_new(0, 1, 1, 1);

	gtk_box_pack_start(GTK_BOX(xColumnBox1), xRowBox1, TRUE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(xColumnBox1), xRowBox2, TRUE, TRUE, 0);

	gtk_container_add(GTK_CONTAINER(window), xColumnBox1);

	g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), G_OBJECT(window));
	gtk_widget_show_all(window);
	gtk_main();
	return 0;
}
