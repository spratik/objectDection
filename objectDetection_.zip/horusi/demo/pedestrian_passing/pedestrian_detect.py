import cv2
import numpy as np
import imutils
import datetime

cap = cv2.VideoCapture('samplevideo (9).mp4')
#cap = cv2.VideoCapture('/home/pi/opencv-3.0.0/samples/cpp/VID_20161116_133426806.mp4')
hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
print "Svm Classifier Loaded Sucessfully"
#out = cv2.VideoWriter('sample.mp4', -1, 20.0, (640,480))
sc=2.0
while(cap.isOpened()):
    ret, frame = cap.read()
    if ret==True:
		
       #frame_fliped = cv2.flip(frame, 0)
       frame_resized = cv2.resize(frame, (640, 480))
       #for (x, y, w, h) in rects:
		#    cv2.rectangle(frame_resized, (x, y), (x + w, y + h), (0, 0, 255), 2) 
       #out.write(fra
       frame_re_hog = imutils.resize(frame_resized, width=min(400, frame_resized.shape[1]))
       start = datetime.datetime.now()
       (rects, weights) = hog.detectMultiScale(frame_re_hog, winStride=(4, 4),padding=(4, 4), scale=sc)
       for (x, y, w, h) in rects:
          cv2.rectangle(frame_re_hog, (x, y), (x + w, y + h), (0, 0, 255), 2)
       print("[INFO] detection took: {}s".format((datetime.datetime.now() - start).total_seconds()))
       cv2.imshow('frame',frame_re_hog)
       if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    else:
       if cv2.waitKey(1) & 0xFF == ord('k'):
            break

cap.release()
cv2.destroyAllWindows()	
