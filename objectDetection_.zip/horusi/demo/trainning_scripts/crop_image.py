import argparse
import cv2
import time
refPt = []
cropping = False
def click_and_crop(event, x, y, flags, param):
	global refPt, cropping
	if event == cv2.EVENT_LBUTTONDOWN:
		refPt = [(x, y)]
		cropping = True
	elif event == cv2.EVENT_LBUTTONUP:
		refPt.append((x, y))
		cropping = False
		cv2.rectangle(resized_image, refPt[0], refPt[1], (0, 255, 0), 2)
		cv2.imshow("image", resized_image)
                print refPt[0][0]," ",refPt[0][1]," ",refPt[1][0]," ",refPt[1][1]
                crop=copy_image[refPt[0][1]:refPt[1][1], refPt[0][0]:refPt[1][0]]
                choice=raw_input("Enter the catagory :")
                if(choice=='p'):
                  folder="positive_col"
                if(choice=='n'):
                   folder="negative_col"
                if(choice=='q'):
                   exit()
                name=time.strftime("%d_%H_%M_%S")+".jpg"
                path=folder+"/"+name
                print path
                cv2.imwrite(path,crop)

ap = argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True, help="Path to the image")
args = vars(ap.parse_args())
image = cv2.imread(args["image"])
resized_image=cv2.resize(image,(1080,680))
copy_image = resized_image.copy()
clone = resized_image.copy()
cv2.namedWindow("image")
cv2.setMouseCallback("image", click_and_crop)

while True:
	cv2.imshow("image", resized_image)
	key = cv2.waitKey(1) & 0xFF
	if key == ord("c"):
		break

print "Crop Completed"
cv2.waitKey(0)
cv2.destroyAllWindows()
