import cv2
import numpy as np
import imutils
import datetime
#create folder name like crop folder.
#Change the video file in below, and this script will create frames for every 10 frames and
#store in croped_images.
cap = cv2.VideoCapture('VID_20161116_133426806.mp4')
print "conversion Started"
print "Status:"
count=0;count1=1
while(cap.isOpened()):
    ret, frame = cap.read()
    if ret==True:
       count=count+1
       frame_resized = cv2.resize(frame, (640, 480))
       gray_image = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2GRAY)
       rows,cols = gray_image.shape
       M = cv2.getRotationMatrix2D((cols/2,rows/2),180,1)
       rotated_image=cv2.warpAffine(gray_image,M,(cols,rows))
       if ((count%10)==1):
          name='croped images/frame'+str(count1)+'.jpg'
          cv2.imshow('frame',rotated_image)
          cv2.imwrite(name,rotated_image)
          print name
          count1=count1+1
       if cv2.waitKey(1) & 0xFF == ord('q'):
          break
    else:
        #if cv2.waitKey(1) & 0xFF == ord('k'):
        break

cap.release()
#out.release()
cv2.destroyAllWindows()	
