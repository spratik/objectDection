#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include "opencv2/imgcodecs.hpp"
#include <opencv2/highgui.hpp>
#include <opencv2/ml.hpp>

#include <string>
#include <iostream>
#include <fstream>
#include <vector>

#include <time.h>

using namespace cv;
using namespace cv::ml;
using namespace std;



void load_images( const string & prefix, const string & filename, vector< Mat > & img_lst )
{
	string line;
	ifstream file;
	file.open( (prefix+filename).c_str() );
	if( !file.is_open() )
	{
		cerr << "Unable to open the list of images from " << filename << " filename." << endl;
		exit( -1 );
	}

	bool end_of_parsing = false;
	while( !end_of_parsing )
	{
		getline( file, line );
		if( line.empty() ) // no more file to read
		{
			end_of_parsing = true;
			break;
		}
		Mat img = imread( (prefix+line).c_str() ); // load the image
		if( img.empty() ) // invalid image, just skip it.
		{
			cout<<"Invalid Image"<<endl;
			continue;
		}
#ifdef _DEBUG
		imshow( "image", img );
		waitKey( 10 );
#endif
		img_lst.push_back( img.clone() );
	}
}


void convert_to_ml(const std::vector< cv::Mat > & train_samples, cv::Mat& trainData )
{
	const int rows = (int)train_samples.size();
	const int cols = (int)std::max( train_samples[0].cols, train_samples[0].rows );

	cv::Mat tmp(1, cols, CV_32FC1); //< used for transposition if needed

	trainData = cv::Mat(rows, cols, CV_32FC1 );
	//cout<<tmp.rows<<","<<tmp.cols<<endl;
	vector< Mat >::const_iterator itr = train_samples.begin();
	vector< Mat >::const_iterator end = train_samples.end();

	for( int i = 0 ; itr != end ; ++itr, ++i )
	{
		CV_Assert( itr->cols == 1 || itr->rows == 1 );
		if( itr->cols == 1 )
		{
			transpose( *(itr), tmp );
			tmp.copyTo( trainData.row( i ) );
		}
		else if( itr->rows == 1 )
		{
			itr->copyTo( trainData.row( i ) );
		}
	}

}



void train_svm( const vector< Mat > & gradient_lst, const vector< int > & labels )
{

	Mat train_data;
	cout << "converting Started..."<<endl;
	convert_to_ml( gradient_lst, train_data );
	cout << "Start training..."<<endl;
	Ptr<SVM> svm = SVM::create();
	svm->setCoef0(0.0);
	svm->setDegree(3);
	svm->setTermCriteria(TermCriteria( CV_TERMCRIT_ITER+CV_TERMCRIT_EPS, 1000, 1e-3 ));
	svm->setGamma(0);
	svm->setKernel(SVM::LINEAR);
	svm->setNu(0.5);
	svm->setP(0.1); // for EPSILON_SVR, epsilon in loss function?
	svm->setC(0.01); // From paper, soft classifier
	svm->setType(SVM::EPS_SVR); // C_SVC; // EPSILON_SVR; // may be also NU_SVR; // do regression task
	svm->train(train_data, ROW_SAMPLE, Mat(labels));
	clog << "...[done]" << endl;
	svm->save( "my_people_detector.yml" );
}


void compute_hog( const vector< Mat > & img_lst, vector< Mat > & gradient_lst, const Size & size )
{
	HOGDescriptor hog;
	hog.winSize = size;
	hog.blockSize=cv::Size(8,8);
	hog.blockStride=cv::Size(4, 4);
	hog.cellSize=cv::Size(4,4 );
	hog.L2HysThreshold= 2.0000000000000001e-01;
	hog.nbins=9;
	hog.gammaCorrection = 0;
	hog.derivAperture=1;
	hog.winSigma=4.0;
	hog.nlevels=20;
	hog.histogramNormType=0;

	Mat gray;
	Mat grayResized;
	vector< Point > location;
	vector< float > descriptors;

	vector< Mat >::const_iterator img = img_lst.begin();
	vector< Mat >::const_iterator end = img_lst.end();

	for( ; img != end ; ++img )
	{
		cvtColor( *img, gray, COLOR_BGR2GRAY );
		resize(gray, grayResized, Size(32, 64), 0, 0, INTER_CUBIC);
		hog.compute( grayResized, descriptors, Size( 8, 8 ), Size( 0,0), location );
		gradient_lst.push_back( Mat( descriptors ).clone() );

	}
}


int main( int argc, char** argv )
{

	Ptr<SVM> svm = SVM::create();
	svm->setCoef0(0.0);
	svm->setDegree(3);
	svm->setTermCriteria(TermCriteria( CV_TERMCRIT_ITER+CV_TERMCRIT_EPS, 1000, 1e-3 ));
	svm->setGamma(0);
	svm->setKernel(SVM::LINEAR);
	svm->setNu(0.5);
	svm->setP(0.1);
	svm->setC(0.01);
	svm->setType(SVM::C_SVC);
    svm = StatModel::load<SVM>("PedestrianClassifier.yml");

	Mat grayimage;
	Mat resized;
	Mat image(imread("frame6.jpg",1));

	resize(image, resized, Size(32,64), 0, 0, INTER_CUBIC);
	cvtColor(resized, grayimage, CV_RGB2GRAY);

	vector<float> features;
	vector<Point> locations;

	HOGDescriptor hog;
	hog.winSize =  Size(32,64);
	hog.blockSize=cv::Size(8,8);
	hog.blockStride=cv::Size(4, 4);
	hog.cellSize=cv::Size(4,4 );
	hog.L2HysThreshold= 2.0000000000000001e-01;
	hog.nbins=9;
	hog.gammaCorrection = 0;
	hog.derivAperture=1;
	hog.winSigma=4.0;
	hog.nlevels=20;
	hog.histogramNormType=0;
	hog.compute( resized, features, Size( 8, 8 ), Size( 0,0), locations );

	Mat test_data(features.size(),1,CV_32FC1);
	Mat test_data_tranpose;
	cv::transpose(test_data, test_data_tranpose);
	cout<<svm->predict(test_data_tranpose)<<endl;

	
}
