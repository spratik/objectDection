
#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include "opencv2/imgcodecs.hpp"
#include <opencv2/highgui.hpp>
#include <opencv2/ml.hpp>

#include <string>
#include <iostream>
#include <fstream>
#include <vector>

#include <time.h>

using namespace cv;
using namespace cv::ml;
using namespace std;

void get_svm_detector(const Ptr<SVM>& svm, vector< float > & hog_detector )
{
	// get the support vectors
	Mat sv = svm->getSupportVectors();
	const int sv_total = sv.rows;
	// get the decision function
	Mat alpha, svidx;
	double rho = svm->getDecisionFunction(0, alpha, svidx);

	CV_Assert( alpha.total() == 1 && svidx.total() == 1 && sv_total == 1 );
	CV_Assert( (alpha.type() == CV_64F && alpha.at<double>(0) == 1.) ||
			(alpha.type() == CV_32F && alpha.at<float>(0) == 1.f) );
	CV_Assert( sv.type() == CV_32F );
	hog_detector.clear();

	hog_detector.resize(sv.cols + 1);
	memcpy(&hog_detector[0], sv.ptr(), sv.cols*sizeof(hog_detector[0]));
	hog_detector[sv.cols] = (float)-rho;
}


void load_images( const string & prefix, const string & filename, vector< Mat > & img_lst )
{
	string line;
	ifstream file;
	file.open( (prefix+filename).c_str() );
	if( !file.is_open() )
	{
		cerr << "Unable to open the list of images from " << filename << " filename." << endl;
		exit( -1 );
	}

	bool end_of_parsing = false;
	while( !end_of_parsing )
	{
		getline( file, line );
		if( line.empty() ) // no more file to read
		{
			end_of_parsing = true;
			break;
		}
		Mat img = imread( (prefix+line).c_str() ); // load the image
		if( img.empty() ) // invalid image, just skip it.
		{
			cout<<"Invalid Image"<<endl;
			continue;
		}
#ifdef _DEBUG
		imshow( "image", img );
		waitKey( 10 );
#endif
		img_lst.push_back( img.clone() );
	}
}


void convert_to_ml(const std::vector< cv::Mat > & train_samples, cv::Mat& trainData )
{
	const int rows = (int)train_samples.size();
	const int cols = (int)std::max( train_samples[0].cols, train_samples[0].rows );

	cv::Mat tmp(1, cols, CV_32FC1); //< used for transposition if needed

	trainData = cv::Mat(rows, cols, CV_32FC1 );
	//cout<<tmp.rows<<","<<tmp.cols<<endl;
	vector< Mat >::const_iterator itr = train_samples.begin();
	vector< Mat >::const_iterator end = train_samples.end();

	for( int i = 0 ; itr != end ; ++itr, ++i )
	{
		CV_Assert( itr->cols == 1 || itr->rows == 1 );
		if( itr->cols == 1 )
		{
			transpose( *(itr), tmp );
			tmp.copyTo( trainData.row( i ) );
		}
		else if( itr->rows == 1 )
		{
			itr->copyTo( trainData.row( i ) );
		}
	}

}




void compute_hog( const vector< Mat > & img_lst, vector< Mat > & gradient_lst, const Size & size )
{
	HOGDescriptor hog;
	hog.winSize = size;
	hog.blockSize=cv::Size(8,8);
	hog.blockStride=cv::Size(4, 4);
	hog.cellSize=cv::Size(4,4 );
	hog.L2HysThreshold= 2.0000000000000001e-01;
	hog.nbins=9;
	hog.gammaCorrection = 0;
	hog.derivAperture=1;
	hog.winSigma=4.0;
	hog.nlevels=20;
	hog.histogramNormType=0;

	Mat gray;
	Mat grayResized;
	vector< Point > location;
	vector< float > descriptors;

	vector< Mat >::const_iterator img = img_lst.begin();
	vector< Mat >::const_iterator end = img_lst.end();

	for( ; img != end ; ++img )
	{
		cvtColor( *img, gray, COLOR_BGR2GRAY );
		resize(gray, grayResized, Size(32, 64), 0, 0, INTER_CUBIC);
		hog.compute( grayResized, descriptors, Size( 8, 8 ), Size( 0,0), location );
		gradient_lst.push_back( Mat( descriptors ).clone() );

	}
}


int main( int argc, char** argv )
{
	vector< Mat > aPositiveList;
	vector< Mat > aNegativeList;
	vector< Mat > aDescriptorList;

	string sSampleImagesPath ="/home/ajis/horusi/eclipse/";
	string sPostiveFileList = "positives.dat";
	string sNegativeFileList = "negatives.dat";
	vector< int > aPredictLabels;

	load_images( sSampleImagesPath, sPostiveFileList, aPositiveList );
	aPredictLabels.assign(aPositiveList.size(), +1 );

	const unsigned int old = (unsigned int)aPredictLabels.size();

	load_images( sSampleImagesPath, sNegativeFileList, aNegativeList );
	aPredictLabels.insert( aPredictLabels.end(), aNegativeList.size(), -1 );

	CV_Assert( old < aPredictLabels.size() );

	compute_hog( aNegativeList, aDescriptorList, Size( 32, 64 ) );
	compute_hog( aPositiveList, aDescriptorList, Size( 32, 64 ) );

	//	cout<<aDescriptorList.size()<<endl;


	Mat train_data;
	convert_to_ml( aDescriptorList, train_data );

	cout<<train_data.rows<<","<<train_data.cols<<endl;

	Ptr<SVM> svm = SVM::create();
	svm->setCoef0(0.0);
	svm->setDegree(3);
	svm->setTermCriteria(TermCriteria(CV_TERMCRIT_ITER+CV_TERMCRIT_EPS, 1000, 1e-3));
	svm->setGamma(0);
	svm->setKernel(SVM::LINEAR);
	svm->setNu(0.5);
	svm->setP(0.1);
	svm->setC(0.01);
	svm->setType(SVM::C_SVC);
	svm->train(train_data, ROW_SAMPLE, Mat(aPredictLabels));
	svm->save( "my_people_detector.yml" );


	const char* filename = "trainned_data.txt";

	ofstream fout(filename);

	if(!fout)
	{
		cout<<"File Not Opened"<<endl;
	}

	for(int i=0; i<train_data.rows; i++)
	{
		for(int j=0; j<train_data.cols; j++)
		{
			fout<<train_data.at<float>(i,j)<<"\t";
		}
		fout<<endl;
	}

	fout.close();


	//	Ptr<SVM> svm1 = SVM::create();
	//	svm1->setCoef0(0.0);
	//	svm1->setDegree(3);
	//	svm1->setTermCriteria(TermCriteria( CV_TERMCRIT_ITER+CV_TERMCRIT_EPS, 1000, 1e-3 ));
	//	svm1->setGamma(0);
	//	svm1->setKernel(SVM::LINEAR);
	//	svm1->setNu(0.5);
	//	svm1->setP(0.1);
	//	svm1->setC(0.01);
	//	svm1->setType(SVM::C_SVC);
	//	svm1 = StatModel::load<SVM>( "my_people_detector.yml");
	//	Mat sv = svm->getUncompressedSupportVectors();
	//	cout<<sv.rows<<", "<<sv.cols<<endl;

	Mat grayimage;
	Mat resized;
	Mat image(imread("/home/ajis/horusi/eclipse/negative/15_12_16_10.jpg",1));

	resize(image, resized, Size(32,64), 0, 0, INTER_CUBIC);
	cvtColor(resized, grayimage, CV_RGB2GRAY);

	vector<float> features;
	vector<Point> locations;

	HOGDescriptor hog;
	hog.winSize =  Size(32,64);
	hog.blockSize=cv::Size(8,8);
	hog.blockStride=cv::Size(4, 4);
	hog.cellSize=cv::Size(4,4 );
	hog.L2HysThreshold= 2.0000000000000001e-01;
	hog.nbins=9;
	hog.gammaCorrection = 0;
	hog.derivAperture=1;
	hog.winSigma=4.0;
	hog.nlevels=20;
	hog.histogramNormType=0;

	hog.compute( resized, features, Size( 8, 8 ), Size( 0,0), locations );

	Mat test_data(features.size(),1,CV_32FC1);
	Mat test_data_tranpose;
	cv::transpose(test_data, test_data_tranpose);
	//	cout<<svm->predict(test_data_tranpose)<<endl;
}

