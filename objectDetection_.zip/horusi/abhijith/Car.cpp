/**
 * @file objectDetection2.cpp
 * @author A. Huaman ( based in the classic Car.cpp in samples/c )
 * @brief A simplified version of Car.cpp, show how to load a cascade classifier and how to find objects (Car + License) in a video stream - Using LBP here
 */
#include "opencv2/objdetect.hpp"
#include "opencv2/videoio.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"

#include <iostream>
#include <stdio.h>

using namespace std;
using namespace cv;

/** Function Headers */
void detectAndDisplay( Mat frame );

/** Global variables */
String Car_cascade_name = "/home/abhi/horusi/abhijith/car.xml";
//String License_cascade_name = "/home/abhi/horusi/abhijith/License_Plate.xml";
CascadeClassifier Car_cascade;
//CascadeClassifier License_cascade;
String window_name = "Capture - Car detection";
/**
 * @function main
 */
int main( void )
{
    VideoCapture capture;
    Mat frame;
    //-- 1. Load the cascade
    if( !Car_cascade.load( Car_cascade_name ) ){ printf("--(!)Error loading Car cascade\n"); return -1; };
  //  if( !License_cascade.load( License_cascade_name ) ){ printf("--(!)Error loading Licenses cascade\n"); return -1; };

    //-- 2. Read the video stream
    capture.open( "/home/horusi/opencv/Videos/14.avi" );
    if ( ! capture.isOpened() ) { printf("--(!)Error opening video capture\n"); return -1; }

    while ( capture.read(frame) )
    {
        if( frame.empty() )
        {
            printf(" --(!) No captured frame -- Break!");
            break;
        }

        //-- 3. Apply the classifier to the frame
        detectAndDisplay( frame );

        //-- bail out if escape was pressed
        int c = waitKey(10);
        if( (char)c == 27 ) { break; }
    }
    return 0;
}

/**
 * @function detectAndDisplay
 */
void detectAndDisplay( Mat frame )
{
    std::vector<Rect> Cars;
    Mat frame_gray;
    double t;
    cvtColor( frame, frame_gray, COLOR_BGR2GRAY );
    equalizeHist( frame_gray, frame_gray );
    t=(double)cvGetTickCount(); 
    
    cv::Point point1, point2;
    point1 = cv::Point(0, 192);    
    point2 = cv::Point(639, 479);
    cv::rectangle(frame, point1, point2, CV_RGB(255, 0, 0), 3, 8, 0);
    

    cv::Rect myROI(0, 192, 639, 240);
    cv::Mat croppedRef(frame, myROI);
    cv::Mat cropped;
    croppedRef.copyTo(cropped);
    cvtColor( cropped, frame_gray, COLOR_BGR2GRAY );
    equalizeHist( frame_gray, frame_gray );
    //imshow(window_name,cropped);
    //waitKey(0);
    
    //-- Detect Cars
    Car_cascade.detectMultiScale( frame_gray, Cars, 1.1, 3, 0, Size(24, 24) );
    t = (double)cvGetTickCount() - t;
    printf( "detection time = %g ms\n", t/((double)cvGetTickFrequency()*1000.) );
    for( size_t i = 0; i < Cars.size(); i++ )
    {
        Mat CarROI = frame_gray( Cars[i] );
        //std::vector<Rect> License;

        //-- In each Car, detect License
    //    License_cascade.detectMultiScale( CarROI, License, 1.1, 2, 0 |CASCADE_SCALE_IMAGE, Size(40, 15) );
    //    if( License.size() == 1)
        {
            //-- Draw the Car
            Point center( Cars[i].x + Cars[i].width/2, Cars[i].y + Cars[i].height/2+192 );
            ellipse( frame, center, Size( Cars[i].width/2, Cars[i].height/2 ), 0, 0, 360, Scalar( 255, 0, 0 ), 2, 8, 0 );

    //        for( size_t j = 0; j < License.size(); j++ )
            { //-- Draw the License
     //           Point License_center( Cars[i].x + License[j].x + License[j].width/2, Cars[i].y + License[j].y + License[j].height/2 );
     //           int radius = cvRound( (License[j].width + License[j].height)*0.25 );
     //           circle( frame, License_center, radius, Scalar( 255, 0, 255 ), 3, 8, 0 );
            }
        }

    }
    //-- Show what you got
    imshow( window_name, frame );
    waitKey(0);
}
