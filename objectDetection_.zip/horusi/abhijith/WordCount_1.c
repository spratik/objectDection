#include<stdio.h>
#include<ctype.h>

int main() {
	FILE *f;
	char ch;
	char buffer[100];
	int wordCount = 0;
	f=fopen("test2.txt","r");

	while (fscanf(f, "%s", buffer) == 1) {
    		wordCount++;
	}
	fclose(f);
	printf("Number of words in the file is: %d\n",wordCount);
	return 0;
}
