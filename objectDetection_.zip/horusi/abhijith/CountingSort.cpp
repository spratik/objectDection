#include <iostream>
using namespace std;

#define SIZE 6

void CountingSort(int a[SIZE]){
	int i=0,j=0,m=0,n=0;
	int index[10] = {0,1,2,3,4,5,6,7,8,9};
	int count[SIZE] = {0};
	int output[SIZE]= {0};
	// For counting the number of occurences
	for(i=0;i<10;i++){
		for(j=0;j<SIZE;j++){
			if(index[i]==a[j]) 
				n++;		
		}
		count[i] = n;
		n = 0;
	}
	// Add the values the array moving left to right and save in the current index.
	for(i=1;i<SIZE;i++){
		count[i]=count[i-1]+count[i];
	}
	// Shift the values one step towards right.
	for(i=SIZE;i>=0;i--){
		count[i]=count[i-1];
	}
	// Place the values in the output array.
	for(i=0;i<SIZE;i++){
		output[count[a[i]]] = a[i];
		count[a[i]]++;
	}	

	cout << "Numbers after sorting: " << endl;
	for(i=0;i<SIZE;i++){
		cout << output[i] << "  ";
	}
	cout << endl;
}
int main(){
	int a[SIZE];
	int i=0;
	cout << "Enter " << SIZE << " numbers: " << endl;
	for(i=0;i<SIZE;i++){
		cin >> a[i];
	}
	cout << "Numbers before sorting: ";
	for(i=0;i<SIZE;i++){
		cout << a[i] << "  ";
	}
	cout << endl;
	CountingSort(a);
	return 0;
}

