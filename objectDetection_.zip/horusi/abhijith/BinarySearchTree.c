// Program to Create a Binary search tree: Add values to the tree, Display the sorted values.


#include<stdio.h>
#include<stdlib.h> // Using this for dynamic memory allocation

struct node{
	int data;
	//int count;
	struct node *nextAddr;
	struct node *previousAddr;
};


// Creating a Binary Tree
void creatingTree(struct node *rootNode, struct node *newNode){
	if(newNode->data <= rootNode->data){
		if(rootNode->previousAddr == NULL){
			rootNode->previousAddr = newNode;
		}
		else{
			creatingTree(rootNode->previousAddr,newNode);
		}
	}
	else{
		if(rootNode->nextAddr == NULL){
			rootNode->nextAddr = newNode;
		}
		else{
			creatingTree(rootNode->nextAddr,newNode);
		}
	}
}

//Display Binary Tree
void displayTree(struct node *rootNode){
	struct node *temp;
	temp=rootNode;
	if(temp != NULL){
		displayTree(temp->previousAddr);
		printf("%d ", temp->data);
		displayTree(temp->nextAddr);
	}
}

int main(){
	int n1;
	char ch = 'n';
	struct node *rootNode;
	//set rootNode = NULL initially
	rootNode = NULL;
	struct node *newNode;
	//newNode = (struct node *)malloc(sizeof(struct node));
	
	do{
		printf("\nEnter 1 to create tree, 2 to display tree and anything else to terminate the program: ");
		scanf("%d",&n1);
		switch(n1){
			case 1: 
				do{				
					newNode = (struct node *)malloc(sizeof(struct node));
					printf("Enter an integer value for the tree: ");
					scanf("%d", &newNode->data);
					
					if(rootNode == NULL){
						rootNode = newNode;
					}
					else{
						creatingTree(rootNode,newNode);
					}
					
					printf("Enter 'Y' or 'y' to add another value, Enter 'N' or 'n' to stop adding values:");
					scanf(" %c",&ch);
					
					//printf("ch = %c\n",ch);
				}while(ch != 'N' && ch != 'n');
				break;
			
			case 2: 
				displayTree(rootNode);
				break;

			default: 
				printf("Invalid Input\n");
				break;
		}
		
	}while(n1 == 1 || n1 == 2);
	return 0;
}

