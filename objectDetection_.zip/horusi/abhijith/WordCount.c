
#include<stdio.h>
#include<ctype.h>

int main() {
	FILE *f;
	char ch;
	int wordCount = 0;
	int space = 1;
	f=fopen("wordCount.txt","r");
	while((ch=getc(f)) != EOF)
	{
		if(isspace(ch) || ch == '\t' || ch == '\n'){
			space = 1;				
			//putchar(ch);
		}
		else if((!isspace(ch) || ch != '\t' || ch != '\n') && space == 1){
			wordCount++;
			space = 0;
		}
	}
	fclose(f);
	printf("Number of words in the file is: %d\n",wordCount);
	return 0;
}
