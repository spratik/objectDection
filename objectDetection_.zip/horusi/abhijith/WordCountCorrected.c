
#include<stdio.h>
#include<ctype.h>

int main() {
	FILE *f;
	char ch;
	int wordCount=0;
	int space=0;

	f=fopen("wor.txt","r");
	while((ch=getc(f)) != EOF)
	{
		space++;
		if(isspace(ch) || ch == '\t' || ch == '\n')
			wordCount++;
		//putchar(ch);
	}
	fclose(f);
	if(space != wordCount){
		printf("Number of words in the file is: %d\n",wordCount);
	}
	else{
		printf("Number of words in the file is: 0\n");
	}
	return 0;
}
