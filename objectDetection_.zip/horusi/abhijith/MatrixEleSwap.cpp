#include<iostream>
using namespace std;

#define ROW 3
#define COLUMN 3

void swap(int x[][COLUMN], int y[][COLUMN]);

int main(){
	int a[ROW][COLUMN], b[ROW][COLUMN];
	int i=0, j=0;
	cout << "Enter the elements for first matrix :" << endl;
	for(i=0;i<ROW;i++){
		for(j=0;j<COLUMN;j++)
			cin >> a[i][j];
	}
	cout << "Enter the elements for second matrix :" << endl;
	for(i=0;i<ROW;i++){
		for(j=0;j<COLUMN;j++)
			cin >> b[i][j];
	}
	cout << "The first matrix is: " << endl;
	for(i=0;i<ROW;i++){
		for(j=0;j<COLUMN;j++){
			cout << a[i][j] << "  ";
		}
		cout << endl;
	}
	cout << "The second matrix is: " << endl;
	for(i=0;i<ROW;i++){
		for(j=0;j<COLUMN;j++){
			cout << b[i][j] << "  ";
		}
		cout << endl;
	}
	swap(a,b);
	return 0;
}

void swap(int a[ROW][COLUMN],int b[ROW][COLUMN]){
	int temp=0,i=0,j=0;
	for(i=0;i<ROW;i++){
		for(j=0;j<COLUMN;j++){
			temp = a[i][j];
			a[i][j] = b[i][j];
			b[i][j] = temp;
		}
	}
	cout << "The first matrix after swapping is: " << endl;
	for(i=0;i<ROW;i++){
		for(j=0;j<COLUMN;j++){
			cout << a[i][j] << "  ";
		}
		cout << endl;
	}
	cout << "The second matrix after swapping is: " << endl;
	for(i=0;i<ROW;i++){
		for(j=0;j<COLUMN;j++){
			cout << b[i][j] << "  ";
		}
		cout << endl;
	}
}
