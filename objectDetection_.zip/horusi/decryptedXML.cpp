#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

#define SIZE 1024

char * decryption(char *encryptedXML)
{
	ifstream infile2;

	infile2.open (encryptedXML);	//opens the file using infile2 (different input file)

	if(!infile2.is_open()){
		cout << "FILE IS NOT OPEN : : " << encryptedXML << endl;
		return ;
	}
	
	char decryptFileName[SIZE];

	string password = "1234";

	if(strstr(encryptedXML, "Car")){
	  strcpy(decryptFileName, "decryptCar.xml");
	}else if(strstr(encryptedXML, "Pedestrin")){
		strcpy(decryptFileName, "decryptedPedestrin.xml");
	}else if(strstr(encryptedXML, "HogPedestrianClassifier")){
		strcpy(decryptFileName, "decryptedHogPedestrianClassifier.xml");
	}	
	
	ofstream file(decryptFileName);
	int  i = 0;
	while (!infile2.eof())	//while not the end of the file
	{
		for (i = 0 ;i < 4 ; i++)	//for loop cycles through the positions of the password array until end of file is reached
		{
			if(infile2.eof()){
				//cout << "END OF THE FILE " << endl;
				break;
			}
			char name;	//character from file to be decrypted
			infile2.get(name);	//gets character from file
			if(infile2.eof()){
				//cout << "END OF THE FILE " << endl;
				break;
			}
			name = name + password[0];	//re-adds the first letter of the password
			name = name - password[i];	//subtracts the proper letter from the password array
			file << name ;			
			//cout << name;	//prints decrypted character to screen
		}	
		i = 0;
	}

	infile2.close();	//closes file that was being decrypted	
	file.close();

	return decryptFileName;
	
}


int main(int argc, char **argv)
{
	if(argc != 2){
	  cout << "USAGE :: EXE INPUTXML_FILE" << endl;
		return 0;
	}
	
	decryption(argv[1]);

}

