import numpy as np
import cv2
from matplotlib import pyplot as plt

bg=cv2.imread("Background.jpg")
capture=cv2.VideoCapture(1)

while True:
	f, frame=capture.read()
	frame_copy=frame-bg
	
	(h,w)=frame_copy.shape[:2]
	sumCols=[]
	for j in range(w):
		col=frame_copy[0:h,j:j+1] #y1:y2, x1:x2
		sumCols.append(np.sum(col))
	cv2.imshow("window",frame);	
	cv2.waitKey(3000)
