#!/usr/bin/python

import numpy as np
import cv2
import datetime as dt
import imutils
import time	
		
width=640
height=480
ctr1=0
number=0
currentRegion=0
CalibrationTimer=0
RegionFlag1=True
RegionFlag2= False
RegionFlag3=False
Region1Time=0
Region2Time=0
Region3Time=0
busName=""

busDict={}
#Dictionary of dictonaries. The key for the inner dictories are 'Bus' followed by the number. Inner dict has 5 keys follows -
#1.Region
#2.Time1
#3.Time2
#4.Time3
#5.TimeDiff
#6.Unsafe
#(Have to add more elements to store details of the HAAR classifier)


#method to calculate the difference between two datetime objects where the fist parameter is the start and the second is end
def calcTimeDiff(time1,time3):
                start=time1[11:]
                end=time3[11:]

                start_dt = dt.datetime.strptime(start, '%H:%M:%S')
                end_dt = dt.datetime.strptime(end, '%H:%M:%S')

                diff = (end_dt - start_dt)
                diff.seconds/60
		return diff
#Detect and return rects with the HAAR classifier
def detect(img, cascade):
    rects = cascade.detectMultiScale(img, scaleFactor=1.1, minNeighbors=6, minSize=(8, 8),
                                     flags=cv2.CASCADE_SCALE_IMAGE)
    if len(rects) == 0:
        return []
    rects[:,2:] += rects[:,:2]
    return rects

#Display the rects detected on the screen
def draw_rects(img, rects, color):
    for x1, y1, x2, y2 in rects:
	if (CalibrationTimer > 40):
        	cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)



cap = cv2.VideoCapture(0)
fgbg = cv2.createBackgroundSubtractorMOG2()

cascade_fn = "classifier/cascade.xml"

cascade = cv2.CascadeClassifier(cascade_fn)

while(1):
    now = dt.datetime.now()
    ret, frame = cap.read()
    CalibrationTimer=CalibrationTimer+1 
    img=frame.copy()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)
    
    fgmask = fgbg.apply(frame)
    regionOccupiedFlag=False	    
    elt =cv2.getStructuringElement(cv2.MORPH_RECT,(5,5))
    opening = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, elt) 
    
    rects = detect(gray, cascade)
    for i in rects:
    	ctr1=1
    draw_rects(frame, rects, (0, 0, 255))

    #draw the ROI
    x1=75
    x2=int(width-75)
    y1=int(height*0.25)
    y2=int(height*0.75)
    cv2.line(frame,(x1,y1),(x2,y1),(255,255,255),3)
    cv2.line(frame,(x1,y2),(x2,y2),(255,255,255),3)
	
    # find contours in the thresholded image
    cnts = cv2.findContours(opening.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    
    cnts = cnts[0] if imutils.is_cv2() else cnts[1]
    # loop over the contours
    for c in cnts:
	# compute the center of the contour
	M = cv2.moments(c)
	cX = int(M["m10"] / M["m00"])
	cY = int(M["m01"] / M["m00"])
	

    	x,y,w,h = cv2.boundingRect(c)
    	ctr=w*h  
	upperCenter=y-h/2
	lowerCenter=y+h/2
    	if(CalibrationTimer> 40 and ctr > 4000 and ctr < 40000):
		cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
		if(cY<y1 and RegionFlag1 is True):
			Region1Time=now.strftime("%Y-%m-%d %H:%M") + ":%d"%now.second
			print "The bus is behind the line at : "+Region1Time
			if(ctr1 is 1):
				print "Star bus behind the line"
				ctr1=0	     	
			RegionFlag1=False
			RegionFlag2=True
			RegionFlag3=True
			currentRegion=1
			if(busDict.has_key(busName) is False):
				number = number +1
				busName='Bus'+str(number)
				busDict[busName]={}
			busDict[busName]['Region'] = currentRegion 
			busDict[busName]['Time1'] = Region1Time
				
		elif(cY>y1 and cY<y2 and RegionFlag2 is True):
			Region2Time=now.strftime("%Y-%m-%d %H:%M") + ":%d"%now.second
			print "The bus is in between the lines at : "+Region2Time
			if(ctr1 is 1):
        	                print "Star bus is in between the lines"
        	                ctr1=0
			RegionFlag2=False
			RegionFlag1=True
			RegionFlag3=True
			currentRegion=2
			busDict[busName]['Region'] = currentRegion
                        busDict[busName]['Time2'] = Region2Time 

		elif (cY>y2 and RegionFlag3 is True):
			Region3Time=now.strftime("%Y-%m-%d %H:%M") + ":%d"%now.second
			print "The bus has crossed the forward line at : "+Region3Time
			if(ctr1 is 1):
        	                print "Star bus has crossed the forward line"
        	                ctr1=0
			RegionFlag3=False
			RegionFlag1=True
			RegionFlag2=True
			currentRegion=3
			busDict[busName]['Region'] = currentRegion
                        busDict[busName]['Time3'] = Region3Time 
			busDict[busName]['TimeDiff'] = calcTimeDiff(busDict[busName]['Time1'],busDict[busName]['Time3'])

		if((upperCenter<y1 and lowerCenter>y1) or (upperCenter<y2 and lowerCenter>y2)):
                        busDict[busName]['Unsafe'] = 1
                else:
                        busDict[busName]['Unsafe'] = 0

    print busDict

    # show the image
    cv2.imshow("Bus Regulator Proof Of Concept", frame)
    cv2.waitKey(20)

 
cap.release()
cv2.destroyAllWindows()
