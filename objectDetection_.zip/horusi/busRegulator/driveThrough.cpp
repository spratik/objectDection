#include "opencv2/objdetect.hpp"
#include "opencv2/videoio.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include "background_segm.hpp"

#include <iostream>
#include <stdio.h>
#include <string>
#include <time.h>
#include <unistd.h> 

using namespace std;
using namespace cv;

/** Function Headers */
//void detectAndDisplay( Mat frame );

/** Global variables */
//String Toy_Car_cascade_name = "classifier/cascade.xml";
//CascadeClassifier Toy_Car_cascade;
String window_name = "Capture - Regulator";
int ctr=1;
time_t t1,t2=0;

/**
 * @function main
 */

//Get current date/time, format is YYYY-MM-DD.HH:mm:ss

/*const std::string currentDateTime() {
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[80];
    tstruct = *localtime(&now);
    strftime(buf, sizeof(buf), "%Y-%m-%d.%X", &tstruct);

    return buf;
}*/


int main( void )
{
	VideoCapture capture;
	Mat frame,fgmask;

	//-- 1. Load the cascade
	/*if( !Toy_Car_cascade.load( Toy_Car_cascade_name ) )
	{
		printf("--(!)Error loading Toy_Car cascade\n"); 
		return -1;
	}*/

	//-- 2. Read the video stream
	capture.open( 0 );
    
	if ( ! capture.isOpened() ) 
	{
		printf("--(!)Error opening video capture\n");
		return -1; 
	}

	while ( capture.read(frame) )
	{
        	if( frame.empty() )
        	{
            		printf(" --(!) No captured frame -- Break!");
            		break;
        	}
		fgbg = createBackgroundSubtractorMOG2();
		
		fgmask=fgbg.apply(frame);

		//draw the ROI
        	float x1=frame.size().width*0.25;
        	float x2=frame.size().width*0.75;
       		float y1=50;
        	float y2=frame.size().height-50;
        	Point p1(x1,y1);
        	Point p2(x1,y2);
        	Point p3(x2,y1);
        	Point p4(x2,y2);
        	line(fgbg,p1,p2,Scalar(0,0,255),3);
        	line(fgbg,p3,p4,Scalar(0,0,255),3);
        	//-- 3. Apply the classifier to the frame
        	
		//detectAndDisplay( frame );

        	//-- bail out if escape was pressed
        	int c = waitKey(10);
        	if( (char)c == 27 ) 
		{
			break;
		}
    	}
	
	
	/*Mat bg_gray,car_gray,bin1,bin2,sub,lol;
	Mat bg = imread("Background.jpg");
        Mat car = imread("WithCar.jpg");
	
	cvtColor( bg, bg_gray, COLOR_BGR2GRAY );
	cvtColor( car, car_gray, COLOR_BGR2GRAY );
	
	//GaussianBlur(bg_gray, bg_gray, Size(5, 5), 0);
	//GaussianBlur(car_gray, car_gray, Size(5, 5), 0);

	absdiff(bg_gray, car_gray, sub);
	
	threshold(sub, bin1, 40, 255.0, CV_THRESH_BINARY);
 	
	//threshold( bg_gray, bin1, 100,150,THRESH_BINARY );	
        //threshold( car_gray, bin2,100,150,THRESH_BINARY );
	//imshow("loool",lol);
	//subtract(bin2,bin1,sub);*/
        imshow(window_name,fgbg);
	waitKey(0);
    return 0;
}

/**
 * @function detectAndDisplay
 */

/*void detectAndDisplay( Mat frame )
{
    	std::vector<Rect> Cars;
    	Mat frame_gray;
    	cvtColor( frame, frame_gray, COLOR_BGR2GRAY );
    	equalizeHist( frame_gray, frame_gray );
	
	//draw the ROI
	float x1=frame.size().width*0.25;
	float x2=frame.size().width*0.75;
	float y1=50;
	float y2=frame.size().height-50;
	Point p1(x1,y1);
	Point p2(x1,y2);
	Point p3(x2,y1);
	Point p4(x2,y2);
	line(frame,p1,p2,Scalar(0,0,255),3);
	line(frame,p3,p4,Scalar(0,0,255),3);

	//-- Detect Cars
    	Toy_Car_cascade.detectMultiScale( frame_gray, Cars, 1.2, 18, 0, Size(32,16) );
	    
	for( size_t i = 0; i < Cars.size(); i++ )
    	{
    		Mat CarROI = frame_gray( Cars[i] );
        	Point center( Cars[i].x + Cars[i].width/2, Cars[i].y + Cars[i].height/2 );
        	if(Cars[i].y + Cars[i].height/2 > 240)
		{	
			if(ctr==1&&Cars[i].x<x1)
			{
				string msg="Customer going for pick up "+currentDateTime();
				cout << msg << endl;
				ctr++;
				
			}
			else if(ctr==2&&Cars[i].x>x1&&Cars[i].x<x2)
			{
				string msg="Customer ordering " +currentDateTime();
				cout << msg << endl;
				ctr++;
			}
			else if(ctr==3&&Cars[i].x>x1&&Cars[i].x>x2)
			{
				string msg="Customer waiting to order "+currentDateTime();
				
				cout << msg << endl;
				ctr=1;
			}
		
			ellipse( frame, center, Size( Cars[i].width/2, Cars[i].height/2 ), 0, 0, 360, Scalar( 255, 0, 0 ), 2, 8, 0 );
		}
	imshow( window_name, frame );
    	}
    	//-Display-
    	imshow( window_name, frame );
}*/

