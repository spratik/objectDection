import numpy as np
import cv2
import datetime
import imutils
import time	
		

cap = cv2.VideoCapture(1)
fgbg = cv2.createBackgroundSubtractorMOG2()

width=640
height=480

flag1=True
flag2= False 
flag3=False


while(1):
    ret, frame = cap.read()

    fgmask = fgbg.apply(frame)
    
    now = datetime.datetime.now()
    elt =cv2.getStructuringElement(cv2.MORPH_RECT,(5,5))
    opening = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, elt) 	
    
    #draw the ROI
    x1=int(width*0.25)
    x2=int(width*0.75)
    y1=50
    y2=int(height-50)
    cv2.line(frame,(x1,y1),(x1,y2),(255,255,255),3)
    cv2.line(frame,(x2,y1),(x2,y2),(255,255,255),3)
	
    # find contours in the thresholded image
    cnts = cv2.findContours(opening.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    
    cnts = cnts[0] if imutils.is_cv2() else cnts[1]
    # loop over the contours
    for c in cnts:
	# compute the center of the contour
	M = cv2.moments(c)
	cX = int(M["m10"] / M["m00"])
	cY = int(M["m01"] / M["m00"])
	# draw the contour and center of the shape on the image
	#cv2.drawContours(frame, c, -1, (0, 255, 0), 2)
	

    x,y,w,h = cv2.boundingRect(c)
    ctr=w*h  
    if(ctr>2000):
	cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)

	if(ctr<25000):
		
		if(cX<x1 and flag1 is True):
			print "Car is waiting to place order at : "+now.strftime("%Y-%m-%d %H:%M:%d") + ":%d"%now.second	     	
			flag1=False
			flag2=True
			flag3=True
		
		elif(cX>x1 and cX<x2 and flag2 is True):
			print "Car is placing order at : "+now.strftime("%Y-%m-%d %H:%M:%d") + ":%d"%now.second	
			flag2=False
			flag1=True
			flag3=True

		elif (cX>x2 and flag3 is True):
			print "Car going for pick up : "+now.strftime("%Y-%m-%d %H:%M:%d") + ":%d"%now.second
			flag3=False
			flag1=True
			flag2=True


    # show the image
    cv2.imshow("Image", frame)
    cv2.waitKey(30)


 

cap.release()
cv2.destroyAllWindows()
