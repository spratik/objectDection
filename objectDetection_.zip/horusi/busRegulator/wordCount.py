words={}
while(1):
	strings=input("Enter a word ")
	if (strings is 'q'):
		print words
		print 'End'
		break
	if(words.has_key(strings)):
		words[strings]=words[strings]+1
	else:
		words[strings]=1
	
