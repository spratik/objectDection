#include <iostream>
#include <fstream>
using namespace std;

int main() {

    ifstream source("/home/horusi/test.txt", ios::binary);
    ofstream dest("/home/horusi/Documents/test2.txt", ios::binary);

    dest << source.rdbuf();

    source.close();
    dest.close();

    return 0;
}
