#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <arpa/inet.h>
#include<iostream>

using namespace std;

int value(string sBuffer, int);
int main(int argc, char *argv [])
{
	/*
		1. getaddrinfo
		2. create a new socket
		3. connect to the socket
		4. send data
	 */

	//Variables Declaration
	struct addrinfo hints, * aSocketInfo;
	int status;
	int nSocket;

	//clear hints
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;
	char *ip=argv[1];
	status = getaddrinfo(ip,"35000", &hints, &aSocketInfo);
	if(status != 0)
	{
		fprintf(stderr, "Error getaddrinfo\n");
		exit(1);
	}

	nSocket = socket(aSocketInfo->ai_family, aSocketInfo->ai_socktype, aSocketInfo->ai_protocol);
	if(nSocket < 0)
	{
		fprintf(stderr, "Error socket \n");
		exit(2);
	}

	status = connect(nSocket, aSocketInfo->ai_addr, aSocketInfo->ai_addrlen);
	if(status < 0)
	{
		fprintf(stderr, "Error connect \n");
		exit(3);
	}

	cout<<"Initializing ...."<<endl;
	char sResponseBuffer[256];
	bzero(sResponseBuffer,256);
	strcpy(sResponseBuffer,"ATZ\r");

	status = write(nSocket,sResponseBuffer,strlen(sResponseBuffer));
	if (status < 0)
		perror("ERROR writing to socket");
	bzero(sResponseBuffer,256);
	status = read(nSocket,sResponseBuffer,255);
	if (status < 0)
		perror("ERROR reading from socket");

	strcpy(sResponseBuffer,"ATH1\r");
	status = write(nSocket,sResponseBuffer,strlen(sResponseBuffer));
	if (status < 0)
		perror("ERROR writing to socket");
	bzero(sResponseBuffer,256);
	status = read(nSocket,sResponseBuffer,255);
	if (status < 0)
		perror("ERROR reading from socket");

	strcpy(sResponseBuffer,"ATE0\r");
	status = write(nSocket,sResponseBuffer,strlen(sResponseBuffer));
	if (status < 0)
		perror("ERROR writing to socket");
	bzero(sResponseBuffer,256);
	status = read(nSocket,sResponseBuffer,255);
	if (status < 0)
		perror("ERROR reading from socket");

	while(1)
	{
		strcpy(sResponseBuffer,"010D\r");
		status = write(nSocket,sResponseBuffer,strlen(sResponseBuffer));
		if (status < 0)
			perror("ERROR writing to socket");
		bzero(sResponseBuffer,256);
		status = read(nSocket,sResponseBuffer,255);
		if (status < 0)
			perror("ERROR reading from socket");
		value(sResponseBuffer,1);
		usleep(5000);

	}
	freeaddrinfo(aSocketInfo);
	close(nSocket);
	return 0;
}

int value(string sBuffer, int nOption){
	int nSubstringIndex=0;
	int t=0;
	string sHexdata;
	string sHex32Bit;
	int nConvertedData=0;


	if(nOption==1)
	{


		if(sBuffer.find("0D")!=-1)
		{
			
			nSubstringIndex=sBuffer.find("0D");

			sHexdata=sBuffer.substr(nSubstringIndex+3,2);

			nConvertedData=strtol(sHexdata.c_str(), NULL, 16);
			cout<<"Speed:"<<nConvertedData<<endl;
		}
		else
		{                 
		}
	}
	return nConvertedData;
}

