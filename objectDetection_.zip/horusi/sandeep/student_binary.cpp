//============================================================================
// Name        : binar2.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include<fstream>
using namespace std;

void hsm(string);
int main() {
	ifstream fin;
	string s;
	char c;
	fin.open("/home/horusi/test.txt",ios::in);
	while(fin.get(c)){
		cout<<c;
		s=s+c;
	}
	hsm(s);
	fin.close();
	return 0;
}

void hsm(string s){
	string c;
	int a=0,b=0,mmarks[3],cmarks[3],pmarks[3],bmarks[3],i;
	for(i=0;i<3;i++){
		a=s.find("maths",a);
		b=s.find(' ',a+7);
		c=s.substr(a+7,b-a-7);
		mmarks[i]=stoi(c);
		a=b;
	}
	a=0;
	for(i=0;i<3;i++){
		a=s.find("physics",a);
		b=s.find(' ',a+9);
		c=s.substr(a+9,b-a-9);
		pmarks[i]=stoi(c);
		a=b;
	}
	a=0;
	for(i=0;i<3;i++){
		a=s.find("chem",a);
		b=s.find(' ',a+6);
		c=s.substr(a+6,b-a-6);
		cmarks[i]=stoi(c);
		a=b;
	}
	a=0;
	for(i=0;i<3;i++){
		a=s.find("bio",a);
		b=s.find(' ',a+5);
		c=s.substr(a+5,b-a-5);
		bmarks[i]=stoi(c);
		a=b;
	}

	cout<<"highest marks in maths ";
	int M=0;
	float Mavg=0;
	for(i=0;i<3;i++){
		if(mmarks[i]>M)
			M=mmarks[i];
		Mavg=Mavg+(float)mmarks[i]/(float)3;
	}
	cout<<M<<endl;
	cout<<"avg marks in maths: "<<Mavg<<endl;

	cout<<"highest marks in physics ";
	int P=0;
	float Pavg=0;
	for(i=0;i<3;i++){
		if(pmarks[i]>P)
			P=pmarks[i];
		Pavg=Pavg+(float)pmarks[i]/(float)3;
	}
	cout<<P<<endl;
	cout<<"avg marks in physics: "<<Pavg <<endl;

	cout<<"highest marks in bio ";
	int B=0;
	float Bavg=0;
	for(i=0;i<3;i++){
		if(bmarks[i]>B)
			B=bmarks[i];
		Bavg=Bavg+(float)bmarks[i]/(float)3;
	}
	cout<<B<<endl;
	cout<<"avg marks in physics: "<<Bavg<<endl;

	cout<<"highest marks in chem ";
	int C=0;
	float Cavg=0;
	for(i=0;i<3;i++){
		if(cmarks[i]>C)
			C=cmarks[i];
		Cavg=Cavg+(float)cmarks[i]/(float)3;
	}
	cout<<C<<endl;
	cout<<"avg marks in chem: "<<Cavg<<endl;

	int tmarks=0;
	int hm;
	for(i=0;i<3;i++){
		int temp;
		temp=mmarks[i]+bmarks[i]+cmarks[i]+pmarks[i];
		if(temp>tmarks){
			hm=i;
			tmarks=temp;
		}
	}
	int index=0;
	for(i=0;i<hm;i++){
		index=s.find("name",index+1);
	}
	int k=s.find("roll no",index)+9;
	cout<<s.substr(index+6,s.find("roll no",index) - index-6)<<
		"roll no "<<s.substr(k,s.find(" ",k)-k)<<" has scored highest marks with total marks of "<<tmarks;
}

