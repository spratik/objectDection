//============================================================================
// Name        : date.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
using namespace std;
class date{
private:
	int d;
	string m;
	int y;
	string month[12]={"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"};
	int days[12]={31,28,31,30,31,30,31,31,30,31,30,31};
public:
	void enterdate(){
		cout<<"enter date in format 03 06 1994(dd mm yyyy)";
		cin>>d>>m>>y;
		int valid=checkdate(d,m,y);
		if(valid==1)
			cout<<"valid date";
		else{
			cout<<"enter valid date"<<endl;
			d=0;
			m='\0';
			y=0;
			this->enterdate();
		}
	}
	int checkdate(int d,string m,int y){
		if( (y%4)==0 && m=="feb"){
			if(d<=29)
				return 1;}
		else{
			int i,t=0;
			for(i=0;i<12;i++){
				if(m==month[i]){
					if(d<=days[i]){
						return 1;
						t=1;
						break;
					}
				}
			}
		if(t==0)
			return 0;
		}
	}
	void datediff(date d){
		int i,j,m1,m2,s=0;
		d=greaterdate(this,d);
		//cout<<this->d<<this->m<<this->y<<endl;
		//cout<<d.d<<d.m<<d.y<<endl;
		for(i=0;i<12;i++)
			if(this->m==month[i])
				break;
		m1=i;
		for(i=0;i<12;i++)
			if(this->m==month[i])
				break;
		m2=i;
		for(i=this->y;i<=d.y;i++){
			for(j=m1;!(j==m2 && i==d.y) && j<12;j++){
				if((i%4)==0){
					if(j==2)
						s=s+29;
					else{
						s=s+days[j];
					}
				}
			}
		}
		s=s+d.d-this->d;
		cout<<"no of days is"<<s<<endl;

	}
	date greaterdate(date *d1, date d2){
		if(d1->y>d2.y){
			date d;
			d=*d1;
			*d1=d2;
			d2=d;
			return d2;
		}
		else if(d1->y==d2.y){
			int m1,m2,i;
			for(i=0;i<12;i++)
				if(d1->m==month[i])
					break;
			m1=i;
			for(i=0;i<12;i++)
				if(d2.m==month[i])
					break;
			m2=i;
			if(m2<m1){
				date d;
				d=*d1;
				*d1=d2;
				d2=d;
				return d2;
			}
			else if(m1==m2){
				if(d1->d>d2.d){
					date d;
					d=*d1;
					*d1=d2;
					d2=d;
					return d2;
				}
			}
		}
		return d2;
	}
	void nearbydates(){
		date yd,td;
		int i;
		for(i=0;i<12;i++)
			if(m==month[i])
				break;
		if(d==days[i] && i!=1 && i!=11){
			td.d=1;
			td.m=month[i+1];
			td.y=y;
		}
		else if(d==days[i] && i==11){
			td.d=1;
			td.m=month[0];
			td.y=y+1;
		}
		else if(y%4==0 && i==1){
			if(d==28){
				td.d=29;
				td.m=m;
				td.y=y;
			}
			if(d==29){
				td.d=1;
				td.m=month[i+1];
				td.y=y;
			}
		}
		else if(y%4!=0 && i==1){
			if(d==28){
			td.d=1;
			td.m=month[i+1];
			td.y=y;
			}
		}
		else{
			td.d=d+1;
			td.m=m;
			td.y=y;
		}


		if(d==1 && i!=0 && i!=2){
			yd.d=days[i-1];
			yd.m=month[i-1];
			yd.y=y;
		}
		else if(d==1 && i==0){
			yd.d=days[11];
			yd.m=month[11];
			yd.y=y-1;
		}
		else if(d==1 && i==2){
			if(y%4 == 0){
				yd.d=29;
				yd.m="feb";
				yd.y=y;
			}
			if(y%4 != 0){
				yd.d=28;
				yd.m="feb";
				yd.y=y;
			}
		}
		else{
			yd.d=d-1;
			yd.m=m;
			yd.y=y;
		}
		cout<<td.d<<td.m<<td.y<<endl;
		cout<<yd.d<<yd.m<<yd.y;
	}
};

int main() {
	date d1;
	d1.enterdate();
	cout<<"enter two dates";
	date d2,d3;
	d2.enterdate();
	d3.enterdate();
	cout<<"date difference and nearby dates"<<endl;
	d2.datediff(d3);
	d2.nearbydates();

}

