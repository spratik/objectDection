//============================================================================
// Name        : radix_sort.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <math.h>
using namespace std;

struct queue{
	int *a;
	int front;
	int end;
	int size;
};

queue* createqueue(int n){
	queue *q=new queue;
	q->a=new int[n];
	q->size=n;
	q->front=-1;
	q->end=-1;
	return(q);
}
void enqueue(queue *q,int n){
	if(q->end==-1 && q->front==-1){
		q->end=0;
		q->front=0;
		q->a[q->front]=n;
	}
	else if(q->end<q->size){
		q->end++;
		q->a[q->end]=n;
	}
}

int dequeue(queue *q){
	int s;
	if(q->front<q->end){
		s=q->a[q->front];
		q->front++;
		return(s);
	}
	if(q->front==q->end){
		s=q->a[q->front];
		q->front=-1;
		q->end=-1;
		return(s);
	}
}
void showqueue(queue *q){
	int s;
	while(q->front<=q->end){
		s=q->a[q->front];
		cout<<q->a[q->front];
		q->front++;}
		q->front=0;
}

int main() {
	int n,i,j,k,p=1;
	cout<<"enter no of entries";
	cin>>n;
	int a[n];
	queue *q=createqueue(n);
	for(i=0;i<n;i++){
		cin>>a[i];
		while(((int)a[i]/(int)pow(10,p))!=0){
			p++;
		}
	}
	int b,c;
	for(i=0;i<p;i++){
		for(j=9;j>=0;j--){
			for(k=0;k<n;k++){
				c=(int)a[k]/(int)pow(10,i);
				if(c % 10==j){
					enqueue(q,a[k]);
				}
			}
		}
		for(k=0;k<n;k++){
			a[k]=dequeue(q);
		}
	}

	for(i=0;i<n;i++)
		cout<<a[i]<<endl;
	return 0;
}

