#include<iostream>
#include<fstream>
#include<map>
using namespace std;
int main(){
	map <string,int>m;
	int i=0;
	string s;
	char c;
	ifstream fin;
	fin.open("sample.txt");
	while(fin.get(c)){
		if(c!=' '){
			s=s+c;
		}
		else{
		m[s]++;
		s='\0';
		}
	}
	fin.close();
	map <string,int>::iterator p=m.begin();
	while(p!=m.end()){
		cout<<p->first<<p->second<<endl;
		p++;
	}
	return 0;
}
