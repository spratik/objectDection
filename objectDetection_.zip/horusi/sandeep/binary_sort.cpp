#include<stdio.h>
#include<conio.h>
struct node{
	struct node *left,*right;
	int info;
};
struct node *insert(struct node*,int);
void inorder(struct node*);
struct node *insert(struct node *root,int info){
	struct node *temp;
	temp=root;
	if(root==NULL){
		struct node *n=malloc(sizeof(struct node));
		n->info=info;
		n->right=NULL;
		n->left=NULL;
		root=n;
	}
	else{
		if(temp->info>info){
			if(temp->left==NULL){
				struct node *newnode=malloc(sizeof(struct node));
				temp->left=newnode;
				newnode->info=info;
				newnode->right=NULL;
				newnode->left=NULL;
			}
		else	
			insert(temp->left,info);
		}
		else{	
			if(temp->right==NULL){
				struct node *newnode=malloc(sizeof(struct node));
				temp->right=newnode;
				newnode->info=info;
				newnode->right=NULL;
				newnode->left=NULL;
			}
		else	
			insert(temp->right,info);
		}
	}
	return(root);
}
void inorder(struct node *root){
	if(root){
		inorder(root->left);
		printf("%d ",root->info);
		inorder(root->right);
	}
}

main(){
	struct node *root;
	root=malloc(sizeof(struct node));
	root=NULL;
	int a,info;
	printf("enter 1 and then the no u want\n to put into binary tree \nenter 2 to sort the entered elements");
	while(1){
	scanf("%d",&a);
	switch(a){
		case 1:
			scanf("%d",&info);
			root=insert(root,info);
			printf("entered\n");
			break;
		case 2:
			inorder(root);
			break;
		}
	}
}


