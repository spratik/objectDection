/*
 * horusclassifier.cpp
 *
 *  Created on: 27-Feb-2017
 *      Author: pratik
 */
#include "horusclassifier.h"
#include <fstream>
#include <dirent.h>
#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include "enum.h"
using namespace cv::ml;

#define SIZE 1024
#define INF 10000
#define MINNEIGHBOURFORLICENCEPLATE 2
#define LICENCEPLATEWIDTH 40
#define LICENCEPLATEHEIGHT 15

extern int g_nFrameHeight;
extern int g_nFrameWidth;

void ThreadParam :: setInitParaForPlayRecordedVideo()
{
	DIR *d;
	char fileList[100][256];
	int index = 0;
	struct dirent *dir;

	d = opendir("/home/horusi/recordvideos");

	if (d){

		while ((dir = readdir(d)) != NULL){
			//printf("%s", dir->d_name);
			if(!((strcmp(dir->d_name, ".") == 0) || (strcmp(dir->d_name, "..") == 0)|| (strstr(dir->d_name, ".Trash") != 0))){
				strcpy(fileList[index++], dir->d_name);
			}
		}
		/// There is No videos
		if(index == 0){
			lowestVideoFileId = highestVideoFileId = 0;
		}else{
			lowestVideoFileId = getLowestVideoFileId(fileList, index);
			cout << "LOWEST ID :: " << lowestVideoFileId << endl;

			highestVideoFileId = getHighestVideoFileId(fileList, index);
			cout << "Highest ID :: " << highestVideoFileId << endl;

		}


	}

	closedir(d);

	//cout << "CURRENT VIDEO ::" << Pass->currentVideoPlay << endl;

	///  Update lowestVideoFileId according to currentVideoPlay
	/// If you click on playBackMode then it come to main GUI
	/// again If you click on PlayBackmode then next video should be play.
	if(currentVideoPlay != 0){

		if(currentVideoPlay <= highestVideoFileId){
			lowestVideoFileId = currentVideoPlay;
		}
	}

}



int ThreadParam :: getVideoCount(bool lowestVideoCount )
{
	DIR *d;
	char fileList[100][256];
	int index = 0;
	struct dirent *dir;

	d = opendir("/home/horusi/recordvideos");

	if (d){

		while ((dir = readdir(d)) != NULL){
			//printf("%s", dir->d_name);
			if(!((strcmp(dir->d_name, ".") == 0) || (strcmp(dir->d_name, "..") == 0)|| (strstr(dir->d_name, ".Trash") != 0))){
				strcpy(fileList[index++], dir->d_name);
			}
		}

		if(index == 0){
			lowestVideoFileId = highestVideoFileId = 0;
		}else{

			if(lowestVideoCount == true){
				lowestVideoFileId = getLowestVideoFileId(fileList, index);
				cout << "LOWEST ID :: " << lowestVideoFileId << endl;
			}else{
				highestVideoFileId = getHighestVideoFileId(fileList, index);
				cout << "Highest ID :: " << highestVideoFileId << endl;
			}
		}
		closedir(d);

	}

	if(lowestVideoCount == true)
	{
		return lowestVideoFileId;
	}else{
		return highestVideoFileId;
	}

}
int ThreadParam :: getHighestVideoFileId()
{

	FILE *in;
	char buff[SIZE];

	char cmd[SIZE]= "ls /home/horusi/recordvideos/ -v";


	if(!(in = popen(cmd, "r"))){
		cout << "popen is fail in getVideoId" << endl;
		exit(0);
	}

	string videoCountStr;

	while(fgets(buff, sizeof(buff), in)!=NULL){}

	//cout << buff<< endl;
	pclose(in);

	for(int i = 0; buff[i] != '\0'; i++){

		if(buff[i] != '.'){
			videoCountStr += buff[i] ;
		}else{
			break;
		}
	}

	return (atoi(videoCountStr.c_str()));


}

int ThreadParam :: getLowestVideoFileId()
{

	FILE *in;
	char buff[SIZE];

	char cmd[SIZE]= "ls /home/horusi/recordvideos/ -v";

	if(!(in = popen(cmd, "r"))){
		cout << "popen is fail in getVideoId" << endl;
		exit(0);
	}

	string videoCountStr;

	while(fgets(buff, sizeof(buff), in)!=NULL){
		break;
	}

	//cout << buff<< endl;
	pclose(in);

	for(int i = 0; buff[i] != '\0'; i++){

		if(buff[i] != '.'){
			videoCountStr += buff[i] ;
		}else{
			break;
		}
	}

	return (atoi(videoCountStr.c_str()));


}

int ThreadParam :: 	errorHandler(VideoCapture &capture,bool error)
{
	std::cout << "exception caught: " << error << std::endl;

	/// if video file present then it throw 1 and if vidoe file not present then
	if(!error){

		stringstream error;

		if(lowestVideoFileId == 0){
			cout << "There is NO VIdeo in errorHandler" << endl;
			Mat img = imread("./offlineDefaultImg.jpg", 1);
			error<<"THERE ARE NO VIDEOS RECORED";
			putText(img, error.str(), Point(100,100), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
			imshow("App Window", img);
			waitKey(3000);
			noVideoRecordedFlag = true;
			img.release();
			capture.release();
			return NOVIDEOSFOUND;

		}else{
			/// if video is corrupted then it should go to next videos
			lowestVideoFileId++;
			currentVideoPlay = lowestVideoFileId;
			if(lowestVideoFileId > highestVideoFileId){
				lowestVideoFileId = 1;
			}
			//capture.release();
			/// Not showing Display MSG when Video is corrupted
			return VIDEOOPENINGERROR;
		}
	}
	return SUCCESS;

}


void ThreadParam :: pauseFunction(Mat preAnalysedFrame,Mat analysedFrame,void *Data)
{
	Mat resizedFrame;

	ThreadParam *Pass = (ThreadParam *)Data;
	Mat displayFrame;
	resize(preAnalysedFrame, resizedFrame, Size(720, 480), 0, 0, INTER_CUBIC); // resize to 1024x768 resolution
	resizedFrame.copyTo(preAnalysedFrame);
	displayFrame=analysedFrame;
	namedWindow("Analyse Window",WINDOW_NORMAL);
	cvSetWindowProperty("Analyse Window", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
	if(Pass->mode==1 || Pass->mode==5)
	{
		preAnalysedFrame.copyTo(analysedFrame);

		Pass->m_pPedestrian->detect(analysedFrame);
		Pass->m_pVehicle->detect(analysedFrame);

		Pass->drawDetection(analysedFrame,Pass->m_pPedestrian->m_axDetectedObjects,
				Pass->m_pVehicle->m_axDetectedObjects,Pass->m_nEndROIy,Pass->m_nleftendx,Pass->m_nrightendx,Pass->m_nHeightROI,
				Pass->m_bShowDetectedPedestrian,Pass->m_bShowDetectedVehicle,Pass->m_bShowDetectedAll,
				true,Pass->m_sHistogramTemplateImage,Pass->m_bShowROIelemination,
				Pass->m_pSvm,Pass->m_bImageclassification,Pass->m_nChoice,Pass);
		displayFrame=analysedFrame;
	}


	while(true)
	{
		imshow("Analyse Window",displayFrame);
		char sKeyboardInterrupt;
		sKeyboardInterrupt = (char) waitKey(10);
		if (sKeyboardInterrupt == 97)
		{
			displayFrame=analysedFrame;
		}
		if(sKeyboardInterrupt == 114)
		{
			displayFrame=resizedFrame;
		}
		if (sKeyboardInterrupt == 27)
		{
			break;
		}
	}
	cvDestroyWindow("Analyse Window");
}
void ThreadParam :: lineconfiguration(Mat& frame,int nROIend,int nleftxend,
		int nrightxend,Point axHighwayROIPolygone[],Point axCityROIPolygone[], void* Data)
{

	ThreadParam *Pass = (ThreadParam *)Data;
	cv::Point2f xHighwayModeLeftRegionStart(1,g_nFrameHeight);
	cv::Point2f xHighwayModeRightRegionStart(g_nFrameWidth,g_nFrameHeight);

	cv::Point2f xCityModeLeftRegionStart(1,g_nFrameHeight);
	cv::Point2f xCityModeRightRegionStart(g_nFrameWidth-1,g_nFrameHeight);

	cv::Point2f xHighwayModeLeftRegionEnd;
	cv::Point2f xHighwayModeRightRegionEnd;

	cv::Point2f xCityModeLeftRegionEnd;
	cv::Point2f xCityModeRightRegionEnd;

	cv::Point2f xHighwayModeLeftRegionStartalternate(1,(g_nFrameHeight-70));
	cv::Point2f xHighwayModeRightRegionStartalternate(g_nFrameWidth,(g_nFrameHeight-70));

	if(Pass->mode==2)
	{

		xHighwayModeLeftRegionStartalternate=cv::Point2f (1,385);
		xHighwayModeRightRegionStartalternate=cv::Point2f (719,385);
	}

	int nHighwayROIincrement=0;

	if(Pass->highwaymode == 1)
	{
		nHighwayROIincrement=50;
		xHighwayModeLeftRegionEnd.y = nROIend-nHighwayROIincrement;
		xHighwayModeRightRegionEnd.y = nROIend-nHighwayROIincrement;
		if(xHighwayModeLeftRegionEnd.y<1)
		{
			nHighwayROIincrement=nHighwayROIincrement+xHighwayModeLeftRegionEnd.y;
		}
	}

	xHighwayModeLeftRegionEnd.x = nleftxend;
	xHighwayModeLeftRegionEnd.y = nROIend-nHighwayROIincrement;
	xHighwayModeRightRegionEnd.x=  nrightxend;
	xHighwayModeRightRegionEnd.y = nROIend-nHighwayROIincrement;

	line(frame,xHighwayModeLeftRegionStart,xHighwayModeLeftRegionStartalternate,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionStartalternate,xHighwayModeLeftRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeRightRegionStart,xHighwayModeRightRegionStartalternate,Scalar(0,255,255),2);
	line(frame,xHighwayModeRightRegionStartalternate,xHighwayModeRightRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionEnd,xHighwayModeRightRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionStart,xHighwayModeRightRegionStart,Scalar(0,255,255),2);

	int nRedROIIncrement=30;
	if(Pass->mode==2)
	{
		nRedROIIncrement=50;
	}



	xCityModeLeftRegionEnd.x =  (int)round(xHighwayModeLeftRegionEnd.x);
	xCityModeLeftRegionEnd.y =  (int)round(xHighwayModeLeftRegionEnd.y+nRedROIIncrement+nHighwayROIincrement);
	xCityModeRightRegionEnd.x=  (int)round(xHighwayModeRightRegionEnd.x);
	xCityModeRightRegionEnd.y = (int)round(xHighwayModeRightRegionEnd.y+nRedROIIncrement+nHighwayROIincrement);

	line(frame,xHighwayModeLeftRegionStart,xCityModeLeftRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xHighwayModeRightRegionStart,xCityModeRightRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xCityModeLeftRegionEnd,xCityModeRightRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xHighwayModeLeftRegionStart,xHighwayModeRightRegionStart,Scalar( 0, 0, 255 ),2);


	Point axHPolygone[]={xHighwayModeLeftRegionStart, xHighwayModeLeftRegionStartalternate,xHighwayModeLeftRegionEnd, xHighwayModeLeftRegionEnd, xHighwayModeRightRegionEnd, xHighwayModeRightRegionEnd,xHighwayModeRightRegionStartalternate, xHighwayModeRightRegionStart, xHighwayModeRightRegionStart, xHighwayModeLeftRegionStart};
	Point axCPolygone[] = {xCityModeLeftRegionStart, xCityModeLeftRegionEnd, xCityModeLeftRegionEnd, xCityModeRightRegionEnd, xCityModeRightRegionEnd, xCityModeRightRegionStart, xCityModeRightRegionStart, xCityModeLeftRegionStart};



	Point b;
	int niterator;
	for(niterator=0;niterator<(sizeof(axHPolygone)/sizeof(b));niterator++)
	{
		axHighwayROIPolygone[niterator]=axHPolygone[niterator];
	}

	for(niterator=0;niterator<(sizeof(axCPolygone)/sizeof(b));niterator++)
	{
		axCityROIPolygone[niterator]=axCPolygone[niterator];
	}

	return;

}

void ThreadParam :: drawPedestrianVehicle(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle,
		int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight)
{
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );
			ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
		}
		else
		{
			nCountingPedestrianFalseObjects++;

		}
	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{
		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{

			Point x1(vehicle[i].x,vehicle[i].y);
			Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));
			rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

		}
		else
		{
			nCountingVehicleFalseObjects++;
		}
	}

}

void ThreadParam :: drawPedestrian(Mat& frame,std::vector<Rect> pedestrian, int &nCountingVehicleFalseObjects,
		int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight)
{
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );
			ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
		}
		else
		{
			nCountingPedestrianFalseObjects++;

		}
	}

}

void ThreadParam :: drawVehicle(Mat& frame,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,
		int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight)
{
	for( size_t i = 0; i < vehicle.size(); i++ )
	{
		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{

			Point x1(vehicle[i].x,vehicle[i].y);
			Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));
			rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

		}
		else
		{
			nCountingVehicleFalseObjects++;
		}
	}

}

int ThreadParam :: orientation(Point p, Point q, Point r)
{
	int val = (q.y - p.y) * (r.x - q.x) -
			(q.x - p.x) * (r.y - q.y);

	if (val == 0) return 0;
	return (val > 0)? 1: 2;
}


bool ThreadParam :: isInside(Point polygon[], int n, Point p)
{
	if (n < 3)  return false;

	Point extreme(INF, p.y);
	int count = 0, i = 0;
	do
	{
		int next = (i+1)%n;
		if (doIntersect(polygon[i], polygon[next], p, extreme))
		{
			if (orientation(polygon[i], p, polygon[next]) == 0)
				return onSegment(polygon[i], p, polygon[next]);

			count++;
		}
		i = next;
	} while (i != 0);
	return count&1;
}


bool ThreadParam:: isInROI(Point x1,Point x2,Point x3,Point x4,Point aROIPolygone[],int nSizeofROIPolygone)
{
	if(isInside(aROIPolygone,nSizeofROIPolygone,x1)||isInside(aROIPolygone,nSizeofROIPolygone,x2)||isInside(aROIPolygone,nSizeofROIPolygone,x3)||isInside(aROIPolygone,nSizeofROIPolygone,x4))
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool  ThreadParam:: doIntersect(Point p1, Point q1, Point p2, Point q2)
{

	int o1 = orientation(p1, q1, p2);
	int o2 = orientation(p1, q1, q2);
	int o3 = orientation(p2, q2, p1);
	int o4 = orientation(p2, q2, q1);

	if (o1 != o2 && o3 != o4)
		return true;

	if (o1 == 0 && onSegment(p1, p2, q1)) return true;

	if (o2 == 0 && onSegment(p1, q2, q1)) return true;

	if (o3 == 0 && onSegment(p2, p1, q2)) return true;

	if (o4 == 0 && onSegment(p2, q1, q2)) return true;

	return false; // Doesn't fall in any of the above cases
}
bool  ThreadParam:: onSegment(Point p, Point q, Point r)
{
	if (q.x <= max(p.x, r.x) && q.x >= min(p.x, r.x) &&
			q.y <= max(p.y, r.y) && q.y >= min(p.y, r.y))
		return true;
	return false;
}



void ThreadParam :: drawVehiclePedestrianROI(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle,
		int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,
		int &nCountingVehicles,int &ROIHeight,Point aROIPolygone[],int &nSizeofROIPolygone,bool &bBountingBoxInside,void* Data)
{
	int nPercentageMatching;
	nCountingPedestrian=0;
	nCountingPedestrianFalseObjects=0;
	nCountingVehicleFalseObjects=0;
	nCountingVehicles=0;
	ThreadParam* Pass = (ThreadParam*) Data;
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		Point x1(pedestrian[i].x,pedestrian[i].y);
		Point x2(pedestrian[i].x+pedestrian[i].width,pedestrian[i].y);
		Point x3(pedestrian[i].x,pedestrian[i].y+pedestrian[i].height);
		Point x4((pedestrian[i].x+pedestrian[i].width),(pedestrian[i].y+pedestrian[i].height));
		Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );

		bBountingBoxInside=isInROI(x1,x2,x3,x4,aROIPolygone,nSizeofROIPolygone);

		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{

			if(bBountingBoxInside)
			{
				ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
				Pass->m_nNoofpedestrianinYellowROI++;
			}

			else
			{
				ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 255, 0 ), 2, 8, 0 );
				Pass->m_nNoofpedestrianinRedROI++;
			}

		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}

	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{

		Point x1(vehicle[i].x,vehicle[i].y);
		Point x2(vehicle[i].x+vehicle[i].width,vehicle[i].y);
		Point x3(vehicle[i].x,vehicle[i].y+vehicle[i].height);
		Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));

		bBountingBoxInside=isInROI(x1,x2,x3,x4,aROIPolygone,nSizeofROIPolygone);

		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{

			if(bBountingBoxInside)
			{
				rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

			}

			else
			{
				rectangle(frame,x1,x4, Scalar( 0, 255, 0 ), 2);
			}

		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}
	}
}


void ThreadParam :: drawVehiclePedestrianHistogramComparision(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle,
		int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,
		int &nCountingVehicles,int &ROIHeight,Point aROIPolygone[],int &nSizeofROIPolygone,
		bool &bBountingBoxInside,int nHistogramChannels[],Mat& xTemplateHistogram,MatND& xcropedImageHistogram,int nHistogramSize[],const float* fHistogramRanges[])
{
	int nPercentageMatching;
	nCountingPedestrian=0;
	nCountingPedestrianFalseObjects=0;
	nCountingVehicleFalseObjects=0;
	nCountingVehicles=0;
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		Mat src1 = frame(pedestrian[i]);
		calcHist( &src1, 1, nHistogramChannels, Mat(),
				xcropedImageHistogram, 2, nHistogramSize, fHistogramRanges,
				true,
				false );

		Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );
		nPercentageMatching=compareHist(xTemplateHistogram,xcropedImageHistogram,CV_COMP_CORREL)*100;
		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			if(nPercentageMatching>25)
			{
				stringstream displayMessage;
				displayMessage <<nPercentageMatching<<"%";
				putText(frame,displayMessage.str() , Point2f(pedestrian[i].x,pedestrian[i].y), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 1);
				ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
			}

			else
			{
				nCountingPedestrianFalseObjects++;

			}
		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}
	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{
		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{

			Point x1(vehicle[i].x,vehicle[i].y);
			Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));
			rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

		}
		else
		{
			nCountingVehicleFalseObjects++;
		}

	}


}

void ThreadParam :: drawVehiclePedestrianSVM(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle,
		int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,Ptr<SVM> svm)
{
	int nPercentageMatching;
	nCountingPedestrian=0;
	nCountingPedestrianFalseObjects=0;
	nCountingVehicleFalseObjects=0;
	nCountingVehicles=0;
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		Point x1(pedestrian[i].x,pedestrian[i].y);
		Point x2(pedestrian[i].x+pedestrian[i].width,pedestrian[i].y);
		Point x3(pedestrian[i].x,pedestrian[i].y+pedestrian[i].height);
		Point x4((pedestrian[i].x+pedestrian[i].width),(pedestrian[i].y+pedestrian[i].height));
		Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );


		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			Mat image = frame(pedestrian[i]);
			Mat resized;
			Mat grayimage;

			resize(image, resized, Size(32,64), 0, 0, INTER_CUBIC);
			cvtColor(resized, grayimage, CV_RGB2GRAY);

			vector<float> features;
			vector<Point> locations;

			HOGDescriptor hog;
			hog.winSize =  Size(32,64);
			hog.blockSize=cv::Size(8,8);
			hog.blockStride=cv::Size(4, 4);
			hog.cellSize=cv::Size(4,4 );
			hog.L2HysThreshold= 2.0000000000000001e-01;
			hog.nbins=9;
			hog.gammaCorrection = 0;
			hog.derivAperture=1;
			hog.winSigma=4.0;
			hog.nlevels=20;
			hog.histogramNormType=0;

			hog.compute( resized, features, Size( 8, 8 ), Size( 0,0), locations );

			Mat test_data(features.size(),1,CV_32FC1);
			Mat test_data_tranpose;
			cv::transpose(test_data, test_data_tranpose);
			int nPrediction=svm->predict(test_data_tranpose);
			if(nPrediction==-1)
			{
				ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar(0,255,255), 2, 8, 0 );
			}

			else
			{
				ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 255, 0 ), 2, 8, 0 );
			}

		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}

	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{

		Point x1(vehicle[i].x,vehicle[i].y);
		Point x2(vehicle[i].x+vehicle[i].width,vehicle[i].y);
		Point x3(vehicle[i].x,vehicle[i].y+vehicle[i].height);
		Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));


		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{
			Point x1(vehicle[i].x,vehicle[i].y);
			Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));
			rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

		}
		else
		{
			nCountingVehicleFalseObjects++;
		}

	}
}

void ThreadParam :: drawSVMHistogram(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,
		int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,
		Point aROIPolygone[],int &nSizeofROIPolygone,bool &bBountingBoxInside,int nHistogramChannels[],
		Mat& xTemplateHistogram,MatND& xcropedImageHistogram,int nHistogramSize[],const float* fHistogramRanges[],Ptr<SVM> svm)
{
	nCountingPedestrian=0;
	nCountingPedestrianFalseObjects=0;
	nCountingVehicleFalseObjects=0;
	nCountingVehicles=0;
	int nPercentageMatching;
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		Mat src1 = frame(pedestrian[i]);
		calcHist( &src1, 1, nHistogramChannels, Mat(),
				xcropedImageHistogram, 2, nHistogramSize, fHistogramRanges,
				true,
				false );

		Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );
		nPercentageMatching=compareHist(xTemplateHistogram,xcropedImageHistogram,CV_COMP_CORREL)*100;
		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			if(nPercentageMatching>25)
			{
				Mat image = frame(pedestrian[i]);
				Mat resized;
				Mat grayimage;

				resize(image, resized, Size(32,64), 0, 0, INTER_CUBIC);
				cvtColor(resized, grayimage, CV_RGB2GRAY);

				vector<float> features;
				vector<Point> locations;

				HOGDescriptor hog;
				hog.winSize =  Size(32,64);
				hog.blockSize=cv::Size(8,8);
				hog.blockStride=cv::Size(4, 4);
				hog.cellSize=cv::Size(4,4 );
				hog.L2HysThreshold= 2.0000000000000001e-01;
				hog.nbins=9;
				hog.gammaCorrection = 0;
				hog.derivAperture=1;
				hog.winSigma=4.0;
				hog.nlevels=20;
				hog.histogramNormType=0;

				hog.compute( resized, features, Size( 8, 8 ), Size( 0,0), locations );

				Mat test_data(features.size(),1,CV_32FC1);
				Mat test_data_tranpose;
				cv::transpose(test_data, test_data_tranpose);
				int nPrediction=svm->predict(test_data_tranpose);
				if(nPrediction==-1)
				{
					ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar(0,255,255), 2, 8, 0 );
				}

				else
				{
					ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 255, 0 ), 2, 8, 0 );
				}
			}

			else
			{
				nCountingPedestrianFalseObjects++;

			}
		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}
	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{
		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{

			Point x1(vehicle[i].x,vehicle[i].y);
			Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));
			rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

		}
		else
		{
			nCountingVehicleFalseObjects++;
		}





	}
}




void ThreadParam :: drawDetection(Mat& frame,Detectobjectdata pedestrian,
		Detectobjectdata vehicle, Detectobjectdata licenceRect, int nEndy,int nleftendx,int nrightendx,
		int ROIHeight,bool bshowdetectedPedestrian,
		bool bshowDetectedVehicle,bool bshowDetectedAll,bool bcompareHistogram,
		string templateImage,bool bROIDisplay,
		Ptr<SVM> svm,bool bImageclassification,int nChoice,void* Data)
{
	ThreadParam *Pass = (ThreadParam *)Data;

	int nCountingPedestrianFalseObjects=0;
	int nCountingVehicleFalseObjects=0;
	int	nCountingPedestrian=0;
	int nCountingVehicles=0;

	Point axHighwayROIPolygone[10];
	Point axCityROIPolygone[8];

	int nSizeofHighwayROIPolygone;
	int nSizeofCityROIPolygone;

	lineconfiguration(frame,nEndy,nleftendx,nrightendx,axHighwayROIPolygone,
			axCityROIPolygone, Pass);

	nSizeofHighwayROIPolygone = sizeof(axHighwayROIPolygone)/sizeof(axHighwayROIPolygone[0]);
	nSizeofCityROIPolygone = sizeof(axCityROIPolygone)/sizeof(axCityROIPolygone[0]);

	bool bHighwayROIBountingBoxInside;
	bool bCityROIBountingBoxInside;

	Mat xSourceImage,xcropedImage;
	MatND xTemplateHistogram,xcropedImageHistogram;

	int nHistogramSize[] = {30, 32};
	float hranges[] = { 0, 180 };
	float sranges[] = { 0, 256 };
	const float* fHistogramRanges[] = { hranges, sranges };

	int nHistogramChannels[] = {0, 1};

	if(bcompareHistogram==true)
	{
		xSourceImage=imread(templateImage);
		calcHist( &xSourceImage, 1, nHistogramChannels, Mat(),
				xTemplateHistogram, 2, nHistogramSize, fHistogramRanges,
				true,
				false );
	}

	switch(nChoice)
	{

	case 1 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		//drawPedestrianVehicle(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight);
		break;

	case 2:
		nCountingPedestrianFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		//drawPedestrian(frame,pedestrian,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight);
		break;


	case 3:
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		//drawVehicle(frame,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight);
		break;

	case 4 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		//drawVehiclePedestrianROI(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,bHighwayROIBountingBoxInside,Data);
		break;

	case 5 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		//drawVehiclePedestrianHistogramComparision(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,bHighwayROIBountingBoxInside,nHistogramChannels,xTemplateHistogram,xcropedImageHistogram,nHistogramSize,fHistogramRanges);
		break;

	case 6 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		//drawVehiclePedestrianSVM(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,svm);
		break;

	case 7 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		//drawSVMHistogram(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,bHighwayROIBountingBoxInside,nHistogramChannels,xTemplateHistogram,xcropedImageHistogram,nHistogramSize,fHistogramRanges,svm);
		break;

	case 8:
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		checkAppMode(frame,pedestrian,vehicle, licenceRect , nCountingVehicleFalseObjects,
				nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,
				ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,
				bHighwayROIBountingBoxInside,Data,axCityROIPolygone,nSizeofCityROIPolygone,
				bCityROIBountingBoxInside,nHistogramChannels,xTemplateHistogram,
				xcropedImageHistogram,nHistogramSize,fHistogramRanges);
	}
	/*if(mode != 1)
	{
		stringstream displaypedestrianMessage;
		displaypedestrianMessage<<"Pedestrians - "<<pedestrian.size()-nCountingPedestrianFalseObjects;
		putText(frame,displaypedestrianMessage.str() , Point2f(500,60), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 2);

		stringstream displayvehicleMessage;
		displayvehicleMessage<<"Vehicles     - "<<vehicle.size()-nCountingVehicleFalseObjects;
		putText(frame,displayvehicleMessage.str() , Point2f(500,80), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 2);

		stringstream displayTotalMessage;
		displayTotalMessage<<"Objects     - "<<(vehicle.size()-nCountingVehicleFalseObjects)+(pedestrian.size()-nCountingPedestrianFalseObjects);
		putText(frame,displayTotalMessage.str() , Point2f(500,40), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 2);

	}*/
}


void ThreadParam :: drawDetection(Mat& frame,std::vector<Rect> pedestrian,
		std::vector<Rect> vehicle, int nEndy,int nleftendx,int nrightendx,
		int ROIHeight,bool bshowdetectedPedestrian,
		bool bshowDetectedVehicle,bool bshowDetectedAll,bool bcompareHistogram,
		string templateImage,bool bROIDisplay,
		Ptr<SVM> svm,bool bImageclassification,int nChoice,void* Data)
{
	ThreadParam *Pass = (ThreadParam *)Data;

	int nCountingPedestrianFalseObjects=0;
	int nCountingVehicleFalseObjects=0;
	int	nCountingPedestrian=0;
	int nCountingVehicles=0;

	Point axHighwayROIPolygone[10];
	Point axCityROIPolygone[8];

	int nSizeofHighwayROIPolygone;
	int nSizeofCityROIPolygone;

	lineconfiguration(frame,nEndy,nleftendx,nrightendx,axHighwayROIPolygone,
			axCityROIPolygone, Pass);

	nSizeofHighwayROIPolygone = sizeof(axHighwayROIPolygone)/sizeof(axHighwayROIPolygone[0]);
	nSizeofCityROIPolygone = sizeof(axCityROIPolygone)/sizeof(axCityROIPolygone[0]);

	bool bHighwayROIBountingBoxInside;
	bool bCityROIBountingBoxInside;

	Mat xSourceImage,xcropedImage;
	MatND xTemplateHistogram,xcropedImageHistogram;

	int nHistogramSize[] = {30, 32};
	float hranges[] = { 0, 180 };
	float sranges[] = { 0, 256 };
	const float* fHistogramRanges[] = { hranges, sranges };

	int nHistogramChannels[] = {0, 1};

	if(bcompareHistogram==true)
	{
		xSourceImage=imread(templateImage);
		calcHist( &xSourceImage, 1, nHistogramChannels, Mat(),
				xTemplateHistogram, 2, nHistogramSize, fHistogramRanges,
				true,
				false );
	}

	switch(nChoice)
	{

	case 1 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawPedestrianVehicle(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight);
		break;

	case 2:
		nCountingPedestrianFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawPedestrian(frame,pedestrian,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight);
		break;


	case 3:
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawVehicle(frame,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight);
		break;

	case 4 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawVehiclePedestrianROI(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,bHighwayROIBountingBoxInside,Data);
		break;

	case 5 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawVehiclePedestrianHistogramComparision(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,bHighwayROIBountingBoxInside,nHistogramChannels,xTemplateHistogram,xcropedImageHistogram,nHistogramSize,fHistogramRanges);
		break;

	case 6 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawVehiclePedestrianSVM(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,svm);
		break;

	case 7 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawSVMHistogram(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,bHighwayROIBountingBoxInside,nHistogramChannels,xTemplateHistogram,xcropedImageHistogram,nHistogramSize,fHistogramRanges,svm);
		break;

	case 8:
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		checkAppMode(frame,pedestrian,vehicle, nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,bHighwayROIBountingBoxInside,Data,axCityROIPolygone,nSizeofCityROIPolygone,bCityROIBountingBoxInside,nHistogramChannels,xTemplateHistogram,xcropedImageHistogram,nHistogramSize,fHistogramRanges);
	}
	if(mode != 1)
	{

		stringstream displaypedestrianMessage;
		displaypedestrianMessage<<"Pedestrians - "<<pedestrian.size()-nCountingPedestrianFalseObjects;
		putText(frame,displaypedestrianMessage.str() , Point2f(500,60), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 2);

		stringstream displayvehicleMessage;
		displayvehicleMessage<<"Vehicles     - "<<vehicle.size()-nCountingVehicleFalseObjects;
		putText(frame,displayvehicleMessage.str() , Point2f(500,80), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 2);

		stringstream displayTotalMessage;
		displayTotalMessage<<"Objects     - "<<(vehicle.size()-nCountingVehicleFalseObjects)+(pedestrian.size()-nCountingPedestrianFalseObjects);
		putText(frame,displayTotalMessage.str() , Point2f(500,40), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 2);

	}
}



void ThreadParam :: checkAppMode(Mat& frame,Detectobjectdata pedestrian,Detectobjectdata vehicle, Detectobjectdata licenceRect, int &nCountingVehicleFalseObjects,
		int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,
		Point aHighwayROIPolygone[],int &nSizeofHighwayROIPolygone,bool &bHighwayROIBountingBoxInside,
		void* Data,Point aCityROIPolygone[],int &nSizeofCityROIPolygone,bool &bCityROIBountingBoxInside,
		int nHistogramChannels[],Mat& xTemplateHistogram,MatND& xcropedImageHistogram,int nHistogramSize[],const float* fHistogramRanges[])
{
	ThreadParam* Pass = (ThreadParam*) Data;

	int nPercentageMatching;
	nCountingPedestrian=0;
	nCountingPedestrianFalseObjects=0;
	nCountingVehicleFalseObjects=0;
	nCountingVehicles=0;
	Mat detectedROI;
	std::vector<Rect> noLicenseplates;
	char distance[SIZE];

	for( int i = 0; i < pedestrian.index; i++ )
	{
		//cout << "PEDE RECT VALUE :: " << pedestrian[i] << endl;

		cv::Rect roi;
		/*cout << "frame width ::" << frame.cols << " " << "frame height ::" << frame.rows << endl;
		cout << " roi.x ::" <<  pedestrian[i].x << " " << "roi.y :: " <<  pedestrian[i].y << " "
				<< "roi.width :: " <<  pedestrian[i].width << " roi.height ::" << pedestrian[i].height << endl;*/


		roi.x = pedestrian.rect[i].x;
		roi.y = pedestrian.rect[i].y;
		roi.width = pedestrian.rect[i].width;
		roi.height = pedestrian.rect[i].height;

		Mat ROI = frame(roi);

		Point x1(pedestrian.rect[i].x,pedestrian.rect[i].y);
		Point x2(pedestrian.rect[i].x+pedestrian.rect[i].width,pedestrian.rect[i].y);
		Point x3(pedestrian.rect[i].x,pedestrian.rect[i].y+pedestrian.rect[i].height);
		Point x4((pedestrian.rect[i].x+pedestrian.rect[i].width),(pedestrian.rect[i].y+pedestrian.rect[i].height));
		Point center( pedestrian.rect[i].x + pedestrian.rect[i].width/2, pedestrian.rect[i].y + pedestrian.rect[i].height/2 );

		calcHist( &ROI, 1, nHistogramChannels, Mat(),
				xcropedImageHistogram, 2, nHistogramSize, fHistogramRanges,
				true,
				false );

		nPercentageMatching=compareHist(xTemplateHistogram,xcropedImageHistogram,CV_COMP_CORREL)*100;

		bHighwayROIBountingBoxInside=isInROI(x1,x2,x3,x4,aHighwayROIPolygone,nSizeofHighwayROIPolygone);
		bCityROIBountingBoxInside=isInROI(x1,x2,x3,x4,aCityROIPolygone,nSizeofCityROIPolygone);
		int roiXpoint=pedestrian.rect[i].y;
		if(roiXpoint > ROIHeight)
		{
			if(nPercentageMatching>25)
			{
				if(bCityROIBountingBoxInside)//red
				{
					ellipse( frame, center, Size( pedestrian.rect[i].width/2, pedestrian.rect[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
					Pass->m_nNoofpedestrianinRedROI++;
				}

				else if(bHighwayROIBountingBoxInside)//yellow
				{
					ellipse( frame, center, Size( pedestrian.rect[i].width/2, pedestrian.rect[i].height/2), 0, 0, 360, Scalar( 0, 255,255 ), 2, 8, 0 );
					Pass->m_nNoofpedestrianinYellowROI++;
				}

				if((pedestrian.rect[i].x + (pedestrian.rect[i].width/2)) >= (Pass->m_nScreenWidth/2))
				{
					Pass->m_nPedestrianRightCount++;
				}
				else
				{
					Pass->m_nPedestrianLeftCount++;
				}

			}
			else
			{
				nCountingPedestrianFalseObjects++;
			}

		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}

	}

	for( int i = 0; i < vehicle.index; i++ )
	{

		Point x1(vehicle.rect[i].x,vehicle.rect[i].y + (frame.rows*0.4));
		Point x2(vehicle.rect[i].x+vehicle.rect[i].width,vehicle.rect[i].y);
		Point x3(vehicle.rect[i].x,vehicle.rect[i].y+vehicle.rect[i].height);
		Point x4((vehicle.rect[i].x+vehicle.rect[i].width),(vehicle.rect[i].y+vehicle.rect[i].height) + (frame.rows*0.4));


		Point pt((vehicle.rect[i].x+vehicle.rect[i].width*3/4),(vehicle.rect[i].y-7) + (frame.rows*0.4));

		bHighwayROIBountingBoxInside=isInROI(x1,x2,x3,x4,aHighwayROIPolygone,nSizeofHighwayROIPolygone);
		bCityROIBountingBoxInside=isInROI(x1,x2,x3,x4,aCityROIPolygone,nSizeofCityROIPolygone);

		int roiXpoint=vehicle.rect[i].y;


		if(roiXpoint > ROIHeight)
		{


			if(bCityROIBountingBoxInside)
			{
				sprintf(distance, "%dM", vehicle.avg[i]);
				//rectangle(frame,x1, x4,Scalar(0,0,255),CV_FILLED);
				putText(frame, distance, pt, CV_FONT_HERSHEY_PLAIN, 2, CV_RGB(0,0,255), 3);
				rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);
				Pass->m_nNoofVehicleinRedROI++;
			}

			else if(bHighwayROIBountingBoxInside)
			{
				sprintf(distance, "%dM",vehicle.avg[i]);
				//rectangle(frame,x1, x4,Scalar(0,255,255),CV_FILLED);
				putText(frame, distance, pt, CV_FONT_HERSHEY_PLAIN, 2, CV_RGB(0,0,255), 3);
				rectangle(frame,x1,x4, Scalar(0,255,255), 2);
				Pass->m_nNoofVehicleinYellowROI++;
			}

			//			}
			//			else
			//			{
			//				nCountingVehicleFalseObjects++;
			//
			//			}
		}

		else
		{
			nCountingVehicleFalseObjects++;
		}

		if((vehicle.rect[i].x + (vehicle.rect[i].width/2)) <= (Pass->m_nScreenWidth/2))
		{
			Pass->m_nVehicleLeftCount++;
		}
		else
		{
			Pass->m_nVehicleRightCount++;
		}
	}

	for( int i = 0; i < licenceRect.index; i++ )
	{

		Point x1(licenceRect.rect[i].x,licenceRect.rect[i].y);
		Point x2(licenceRect.rect[i].x+licenceRect.rect[i].width,licenceRect.rect[i].y);
		Point x3(licenceRect.rect[i].x,licenceRect.rect[i].y+licenceRect.rect[i].height);
		Point x4((licenceRect.rect[i].x+licenceRect.rect[i].width),(licenceRect.rect[i].y+licenceRect.rect[i].height));

		bHighwayROIBountingBoxInside=isInROI(x1,x2,x3,x4,aHighwayROIPolygone,nSizeofHighwayROIPolygone);
		bCityROIBountingBoxInside=isInROI(x1,x2,x3,x4,aCityROIPolygone,nSizeofCityROIPolygone);
		int roiXpoint=licenceRect.rect[i].y;


		if(roiXpoint > ROIHeight)
		{

			if(bCityROIBountingBoxInside)
			{
				rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);
			}

			else if(bHighwayROIBountingBoxInside)
			{
				rectangle(frame,x1,x4, Scalar(0,255,255), 2);
			}
		}
	}
}


void ThreadParam :: checkAppMode(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle,
		int &nCountingVehicleFalseObjects, int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,
		Point aHighwayROIPolygone[],int &nSizeofHighwayROIPolygone,bool &bHighwayROIBountingBoxInside,
		void* Data,Point aCityROIPolygone[],int &nSizeofCityROIPolygone,bool &bCityROIBountingBoxInside,
		int nHistogramChannels[],Mat& xTemplateHistogram,MatND& xcropedImageHistogram,int nHistogramSize[],const float* fHistogramRanges[])
{
	ThreadParam* Pass = (ThreadParam*) Data;

	int nPercentageMatching;
	nCountingPedestrian=0;
	nCountingPedestrianFalseObjects=0;
	nCountingVehicleFalseObjects=0;
	nCountingVehicles=0;
	Mat detectedROI;
	std::vector<Rect> noLicenseplates;

	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		//cout << "PEDE RECT VALUE :: " << pedestrian[i] << endl;

		cv::Rect roi;
		/*cout << "frame width ::" << frame.cols << " " << "frame height ::" << frame.rows << endl;
		cout << " roi.x ::" <<  pedestrian[i].x << " " << "roi.y :: " <<  pedestrian[i].y << " "
				<< "roi.width :: " <<  pedestrian[i].width << " roi.height ::" << pedestrian[i].height << endl;*/


		roi.x = pedestrian[i].x;
		roi.y = pedestrian[i].y;
		roi.width = pedestrian[i].width;
		roi.height = pedestrian[i].height;

		Mat ROI = frame(roi);

		Point x1(pedestrian[i].x,pedestrian[i].y);
		Point x2(pedestrian[i].x+pedestrian[i].width,pedestrian[i].y);
		Point x3(pedestrian[i].x,pedestrian[i].y+pedestrian[i].height);
		Point x4((pedestrian[i].x+pedestrian[i].width),(pedestrian[i].y+pedestrian[i].height));
		Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );

		calcHist( &ROI, 1, nHistogramChannels, Mat(),
				xcropedImageHistogram, 2, nHistogramSize, fHistogramRanges,
				true,
				false );

		nPercentageMatching=compareHist(xTemplateHistogram,xcropedImageHistogram,CV_COMP_CORREL)*100;

		bHighwayROIBountingBoxInside=isInROI(x1,x2,x3,x4,aHighwayROIPolygone,nSizeofHighwayROIPolygone);
		bCityROIBountingBoxInside=isInROI(x1,x2,x3,x4,aCityROIPolygone,nSizeofCityROIPolygone);
		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			if(nPercentageMatching>25)
			{
				if(bCityROIBountingBoxInside)//red
				{
					ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
					Pass->m_nNoofpedestrianinRedROI++;
				}

				else if(bHighwayROIBountingBoxInside)//yellow
				{
					ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 255,255 ), 2, 8, 0 );
					Pass->m_nNoofpedestrianinYellowROI++;
				}

				if((pedestrian[i].x + (pedestrian[i].width/2)) >= (Pass->m_nScreenWidth/2))
				{
					Pass->m_nPedestrianRightCount++;
				}
				else
				{
					Pass->m_nPedestrianLeftCount++;
				}

			}
			else
			{
				nCountingPedestrianFalseObjects++;
			}

		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}

	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{

		Point x1(vehicle[i].x,vehicle[i].y);
		Point x2(vehicle[i].x+vehicle[i].width,vehicle[i].y);
		Point x3(vehicle[i].x,vehicle[i].y+vehicle[i].height);
		Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));

		bHighwayROIBountingBoxInside=isInROI(x1,x2,x3,x4,aHighwayROIPolygone,nSizeofHighwayROIPolygone);
		bCityROIBountingBoxInside=isInROI(x1,x2,x3,x4,aCityROIPolygone,nSizeofCityROIPolygone);
		int roiXpoint=vehicle[i].y;


		if(roiXpoint > ROIHeight)
		{
			int Obj_area = vehicle[i].width * vehicle[i].height;
			cout << "VEHICLE :: AREA ::" << Obj_area << endl;

			Obj_distance = (Ref_area/Obj_area)*Ref_distance;
			cout<<"The Vehicle is at "<< Obj_distance <<" meters away from our Car"<<endl;
			stringstream display;
			display<<Obj_distance;
			putText(frame, display.str(), x1, FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,0), 1);


			if(bCityROIBountingBoxInside)
			{
				rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);
				Pass->m_nNoofVehicleinRedROI++;
			}

			else if(bHighwayROIBountingBoxInside)
			{
				rectangle(frame,x1,x4, Scalar(0,255,255), 2);
				Pass->m_nNoofVehicleinYellowROI++;
			}

		}

		else
		{
			nCountingVehicleFalseObjects++;
		}

		if((vehicle[i].x + (vehicle[i].width/2)) <= (Pass->m_nScreenWidth/2))
		{
			Pass->m_nVehicleLeftCount++;
		}
		else
		{
			Pass->m_nVehicleRightCount++;
		}
	}
}

void ThreadParam :: lineconfiguration(Mat& frame,int nROIend,int nleftxend,
		int nrightxend, int highwaymode)
{

	cv::Point2f xHighwayModeLeftRegionStart(1,480);
	cv::Point2f xHighwayModeRightRegionStart(640,480);

	cv::Point2f xCityModeLeftRegionStart(1,480);
	cv::Point2f xCityModeRightRegionStart(640,480);

	cv::Point2f xHighwayModeLeftRegionEnd;
	cv::Point2f xHighwayModeRightRegionEnd;

	cv::Point2f xCityModeLeftRegionEnd;
	cv::Point2f xCityModeRightRegionEnd;

	cv::Point2f xHighwayModeLeftRegionStartalternate(1,410);
	cv::Point2f xHighwayModeRightRegionStartalternate(640,410);

	int nHighwayROIincrement=0;

	if(highwaymode==1)
	{
		nHighwayROIincrement=50;
	}

	xHighwayModeLeftRegionEnd.x = nleftxend;
	xHighwayModeLeftRegionEnd.y = nROIend-nHighwayROIincrement;
	xHighwayModeRightRegionEnd.x=  nrightxend;
	xHighwayModeRightRegionEnd.y = nROIend-nHighwayROIincrement;


	line(frame,xHighwayModeLeftRegionStart,xHighwayModeLeftRegionStartalternate,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionStartalternate,xHighwayModeLeftRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeRightRegionStart,xHighwayModeRightRegionStartalternate,Scalar(0,255,255),2);
	line(frame,xHighwayModeRightRegionStartalternate,xHighwayModeRightRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionEnd,xHighwayModeRightRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionStart,xHighwayModeRightRegionStart,Scalar(0,255,255),2);

	int nRedROIIncrement=30;

	xCityModeLeftRegionEnd.x =  (int)round(xHighwayModeLeftRegionEnd.x);
	xCityModeLeftRegionEnd.y =  (int)round(xHighwayModeLeftRegionEnd.y+nRedROIIncrement+nHighwayROIincrement);
	xCityModeRightRegionEnd.x=  (int)round(xHighwayModeRightRegionEnd.x);
	xCityModeRightRegionEnd.y = (int)round(xHighwayModeRightRegionEnd.y+nRedROIIncrement+nHighwayROIincrement);

	line(frame,xHighwayModeLeftRegionStart,xCityModeLeftRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xHighwayModeRightRegionStart,xCityModeRightRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xCityModeLeftRegionEnd,xCityModeRightRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xHighwayModeLeftRegionStart,xHighwayModeRightRegionStart,Scalar( 0, 0, 255 ),2);
}

string ThreadParam :: getCheckSumOfLastRecoredVideo(char *videoFilePath)
{
	FILE *in;
	char buff[SIZE];

	char cmd[SIZE];

	string checkSum;

	sprintf(cmd, "python getchecksum.py %s",videoFilePath);

	cout << "CMD :::" << cmd << endl;


	if(!(in = popen(cmd, "r"))){
		cout << "popen is fail in getVideoId" << endl;
		exit(0);
	}

	string videoCountStr;

	while(fgets(buff, sizeof(buff), in)!=NULL){}

	cout <<"CHECKSUM ::" <<  buff;

	for(int i = 0; buff[i] != '\0'; i++){

		if(buff[i] != '\n'){
			checkSum += buff[i];
		}else{
			break;
		}
	}

	pclose(in);

	return checkSum;


}

int ThreadParam :: getLowestVideoFileId(char fileList[][256], int index)
{
	char lowestVideoId[256];
	string lowestAsciiValue;
	string  highestAsciivalue;
	int lowestIntValue;
	int highestIntValue;
	strcpy(lowestVideoId, fileList[0]);

	for(int i = 0; fileList[0][i] != '.'; i++){
		lowestAsciiValue += fileList[0][i];
	}


	lowestIntValue = atoi(lowestAsciiValue.c_str());

	for(int i = 0; i < index  ; i++){
		cout << fileList[i] << endl;

		for(int j = 0; fileList[i][j] != '.'; j++){
			highestAsciivalue += fileList[i][j];
		}
		highestIntValue = atoi(highestAsciivalue.c_str());

		if(highestIntValue < lowestIntValue){
			lowestIntValue = highestIntValue;
			strcpy(lowestVideoId, fileList[i]);
		}

		highestAsciivalue.clear();
	}

	string tmpLowestVideoId;
	for(int i = 0; lowestVideoId[i]!= '.'; i++){
		tmpLowestVideoId += lowestVideoId[i];
	}


	cout <<"LOWEST ID :: " <<  lowestVideoId << endl;
	return atoi(tmpLowestVideoId.c_str());
}
int ThreadParam :: getHighestVideoFileId(char fileList[][256], int index)
{
	char highestVideoId[256];
	string lowestAsciiValue;
	string highestAsciivalue;
	int lowestIntValue;
	int highestIntValue;
	strcpy(highestVideoId, fileList[0]);

	for(int i = 0; fileList[0][i] != '.'; i++){
		highestAsciivalue += fileList[0][i];
	}
	highestIntValue = atoi(highestAsciivalue.c_str());

	for(int i = 0; i < index  ; i++){
		cout << fileList[i] << endl;

		for(int j = 0; fileList[i][j] != '.'; j++){
			lowestAsciiValue += fileList[i][j];
		}
		lowestIntValue = atoi(lowestAsciiValue.c_str());

		if(highestIntValue  < lowestIntValue){
			highestIntValue = lowestIntValue;
			strcpy(highestVideoId, fileList[i]);
		}

		lowestAsciiValue.clear();
	}

	string tmpHighestVideoId;
	for(int i = 0; highestVideoId[i]!= '.'; i++){
		tmpHighestVideoId += highestVideoId[i];
	}
	//cout <<"LOWEST ID :: " <<  lowestVideoId << endl;
	return atoi(tmpHighestVideoId.c_str());
}
void ThreadParam :: computeTimeDifference(struct TIME t1, struct TIME t2, struct TIME *difference){

	// Both time hour is same
	if(t2.hours == t1.hours){

		struct TIME temp;

		temp = t2;
		t2 = t1;
		t1 = temp;

		if(t2.seconds > t1.seconds){
			--t1.minutes;
			t1.seconds += 60;
		}

		difference->seconds = t1.seconds - t2.seconds;

		difference->minutes = t1.minutes - t2.minutes;

		difference->hours = 0;

	}else{

		if(t2.seconds > t1.seconds)
		{
			--t1.minutes;
			t1.seconds += 60;
		}

		difference->seconds = t1.seconds - t2.seconds;
		if(t2.minutes > t1.minutes)
		{
			--t1.hours;
			t1.minutes += 60;
		}
		difference->minutes = t1.minutes-t2.minutes;
		difference->hours = t1.hours-t2.hours;
	}
}

vector <Rect>  HorusClassifier :: detect( Mat& frame, double m_nScaleFactor, int m_nMinNeighbors,
		int m_nFlags, Size m_xMinSize)
{
	Mat tmpImage = frame.clone();
	/*	cout << "MAT TYPE ::" <<  tmpImage.type() << endl;
	cout << "SCALE FACTORE ::" << m_nScaleFactor << endl;*/
	/// crop image and feed to detect object for taking less time
	cv::Rect myROI(0, tmpImage.rows * 0.4 , tmpImage.cols, (tmpImage.rows - tmpImage.rows * 0.4) );
	cv::Mat croppedRef(tmpImage, myROI);

	vector <Rect> rect;
	double timeStart = (double)cvGetTickCount();
	m_xClassifier.detectMultiScale(
			croppedRef,
			rect,
			m_nScaleFactor,
			m_nMinNeighbors,
			m_nFlags,
			m_xMinSize);
	m_nTimeTaken = (double)cvGetTickCount() - timeStart;

	return rect;
}
void  HorusClassifier :: detect( Mat& frame)
{
	double timeStart = (double)cvGetTickCount();
	m_xClassifier.detectMultiScale(
			frame,
			m_axDetectedObjects,
			m_nScaleFactor,
			m_nMinNeighbors,
			m_nFlags,
			m_xMinSize);
	m_nTimeTaken = (double)cvGetTickCount() - timeStart;
}



void HorusClassifier :: display(Mat &frame)
{
	printf( "detection time for %s = %g ms\n", m_sClassifierPath.c_str(),m_nTimeTaken*1000/getTickFrequency());
	if (m_nDisplayShape==1)
	{
		for( size_t i = 0; i < m_axDetectedObjects.size(); i++ )
		{

			Point center( m_axDetectedObjects[i].x + m_axDetectedObjects[i].width/2, m_axDetectedObjects[i].y + m_axDetectedObjects[i].height/2 );
			ellipse( frame, center, Size( m_axDetectedObjects[i].width/2, m_axDetectedObjects[i].height/2), 0, 0, 360, Scalar( 255, 0, 255 ), 4, 8, 0 );
		}
	}
	if(m_nDisplayShape==2)
	{
		if (!m_axDetectedObjects.empty())
		{
			vector< Rect >::const_iterator loc = m_axDetectedObjects.begin();
			vector< Rect >::const_iterator end = m_axDetectedObjects.end();
			for (; loc != end; ++loc)
			{
				rectangle(frame, *loc, Scalar( 255, 0, 255 ), 2);;
			}
		}
	}
	imshow("Detected_objects", frame );
}
void HorusClassifier ::
loadXml(string fileName, float objectScale, int size, int displayShap, int minNeg)
{
	m_sClassifierPath = fileName;
	if(!m_xClassifier.load(m_sClassifierPath) ){
		printf("--(!)Error loading pedestrian cascade\n");
		return;
	};
	m_nScaleFactor = objectScale;
	m_nMinNeighbors = minNeg;
	m_nFlags = 0|CASCADE_SCALE_IMAGE;
	m_xMinSize = Size(size, size);
	m_nDisplayShape = displayShap;
}

void HorusClassifier ::
loadXml(string fileName, float objectScale)
{
	m_sClassifierPath = fileName;
	if(!m_xClassifier.load(m_sClassifierPath) ){
		printf("--(!)Error loading pedestrian cascade\n");
		return;
	};
	m_nScaleFactor = objectScale;
	m_nMinNeighbors = MINNEIGHBOURFORLICENCEPLATE;
	m_nFlags = 0|CASCADE_SCALE_IMAGE;
	m_xMinSize = Size(LICENCEPLATEWIDTH ,LICENCEPLATEHEIGHT);
}


void ThreadParam :: setROI()
{
	m_nframeWidth=720;
	m_nframeHeight=480;
	m_nScreenWidth=720;
	m_nScreenHeight=550;

	FileStorage fileROI;
	fileROI.open("ROISettings.xml", FileStorage::READ);
	if (!fileROI.isOpened())
	{
		fileROI.release();
		fileROI.open("ROISettings.xml", FileStorage::WRITE);
		fileROI << "m_nEndROIy" << 280;
		fileROI << "m_nrightendx" << 390;
		fileROI << "m_nleftendx" << 320;
		fileROI.release();
		cout << "file Recovered.\n" << endl;
		fileROI.open("ROISettings.xml", FileStorage::READ);
	}
	m_nEndROIy=fileROI["m_nEndROIy"];
	m_nrightendx=fileROI["m_nrightendx"];
	m_nleftendx=fileROI["m_nleftendx"];
	fileROI.release();

}
string ThreadParam :: decryption(string encryptedXML)
{
	cout << "DECRYPTED FILE in HORUS CLASSIFIER:: " << encryptedXML << endl;

	//opens the file using infile2 (different input file)
	ifstream infile2(encryptedXML.c_str());

	if(!infile2.is_open()){
		cout << "FILE IS NOT OPEN : : " << encryptedXML.c_str() << endl;
		exit(0);
	}

	char decryptFileName[SIZE];

	string password = "1234";

	if(strstr(encryptedXML.c_str(), "Car")){
		strcpy(decryptFileName, "decryptCar.xml");
	}else if(strstr(encryptedXML.c_str(), "Pedestrin")){
		strcpy(decryptFileName, "decryptedPedestrin.xml");
	}else if(strstr(encryptedXML.c_str(), "HogPedestrianClassifier")){
		strcpy(decryptFileName, "decryptedHogPedestrianClassifier.xml");
	}

	ofstream file(decryptFileName);
	int  i = 0;
	while (!infile2.eof())	//while not the end of the file
	{
		for (i = 0 ;i < 4 ; i++)	//for loop cycles through the positions of the password array until end of file is reached
		{
			if(infile2.eof()){
				//cout << "END OF THE FILE " << endl;
				break;
			}
			char name;	//character from file to be decrypted
			infile2.get(name);	//gets character from file
			if(infile2.eof()){
				//cout << "END OF THE FILE " << endl;
				break;
			}
			name = name + password[0];	//re-adds the first letter of the password
			name = name - password[i];	//subtracts the proper letter from the password array
			file << name ;
			//cout << name;	//prints decrypted character to screen
		}
		i = 0;
	}

	infile2.close();	//closes file that was being decrypted
	file.close();

	return string(decryptFileName);

}

void ThreadParam ::  setDefultValue()
{
	std :: string tmpData;
	cv :: FileStorage  xmlRead("setting.xml", cv :: FileStorage :: READ);

	if (!xmlRead.isOpened()){
		std :: cout << "Failed to open " << std ::endl;
		return ;
	}

	cv::FileNode node = xmlRead["DefaultArgument"];

	node["PedestrianFilename"] >> sPedestrianFilename;

	cout << sPedestrianFilename << endl;

	//sPedestrianFilename = decryption(sPedestrianFilename);


	node["VehicleFilename"] >> sVehicleFilename;

	//sVehicleFilename = decryption(sVehicleFilename);

	//cout << "VehicalFileName :: "  <<  sVehicleFilename << endl;


	node["VideoFilename"] >> m_sVideoFilename;
	node["LicencePlateName"] >> m_sLicencePlateFileName;
	node["HistogramTemplateImage"] >> m_sHistogramTemplateImage;
	node["HeightROI"] >> m_nHeightROI;

	node["PedestrianDetectionScale"] >> fPedestrianDetectionScale;
	node["VehicleDetectionScale"] >> fVehicleDetectionScale;
	node["LicencePlateDetectionScale"] >> fLicencePlateDetectionScale;

	node["PedestrianDetectionminSize"] >> nPedestrianDetectionminSize;
	node["VehicleDetectionminSize"] >> nVehicleDetectionminSize;
	node["Choice"] >> m_nChoice;
	node["mode"] >> mode;
	node["citymode"] >> citymode;
	node["highwaymode"] >> highwaymode;
	node["ndisplayVideo"] >> ndisplayVideo;
	node ["recordmin"] >> recordmin ;//sec
	//cout << "RECORD MIN :: " << recordmin   << endl;
	node["Key1"]  >> m_nKey1;
	node["Key2"] >> m_nKey2;
	node["Key3"] >> m_nKey3;

	tmpData.clear();
	node["ShowDetectedPedestrian" ] >> tmpData;

	if(strcmp(tmpData.c_str(), "false") == 0){
		m_bShowDetectedPedestrian = 0;
	}else{
		m_bShowDetectedPedestrian = 1;
	}
	tmpData.clear();

	node["keypad"] >> tmpData;
	if(strcmp(tmpData.c_str(), "false") == 0){
		keyPadAccessFlag = false;
	}else{
		keyPadAccessFlag = true;
	}

	tmpData.clear();
	node["displayvideo"] >> tmpData;
	if(strcmp(tmpData.c_str(), "false") == 0){
		displayvideoCmdLine = false;
	}else{
		displayvideoCmdLine = true;
	}

	tmpData.clear();

	node["ShowDetectedVehicle"]  >> tmpData;

	if(strcmp(tmpData.c_str(), "false") == 0){
		m_bShowDetectedVehicle = 0;
	}else{
		m_bShowDetectedVehicle = 1;
	}

	tmpData.clear();

	node["ShowDetectedAll"] >> tmpData;

	if(strcmp(tmpData.c_str(), "false") == 0){
		m_bShowDetectedAll = 0;
	}else{
		m_bShowDetectedAll = 1;
	}

	tmpData.clear();
	node["ShowROIelemination"] >>  tmpData;

	if(strcmp(tmpData.c_str(), "false") == 0){
		m_bShowROIelemination = 0;
	}else{
		m_bShowROIelemination = 1;
	}

	tmpData.clear();
	node["HistogramComparision"] >> tmpData;
	if(strcmp(tmpData.c_str(), "false") == 0){
		m_bShowROIelemination = 0;
	}else{
		m_bShowROIelemination = 1;
	}
	tmpData.clear();
	node["Imageclassification"] >> tmpData;

	if(strcmp(tmpData.c_str(), "false") == 0){
		m_bImageclassification = 0;
	}else{
		m_bImageclassification = 1;
	}
	tmpData.clear();
	node["InvertVideo"] >> tmpData ;
	if(strcmp(tmpData.c_str(), "false") == 0){
		m_bInvertVideo = 0;
	}else{
		m_bInvertVideo = 1;
	}
	node["ModeSwitch"] >> m_nModeSwitch;
}
void ThreadParam :: nextMode(Mat xGuiWindow )
{
	Mat xGuiWindowCopy;
	xGuiWindow.copyTo(xGuiWindowCopy);

	int nFirstRectangleEndx=m_nScreenWidth/3;
	int nFirstRectangleEndy=m_nScreenHeight/2;

	int nSecondRectangleEndx=(m_nScreenWidth/3)+nFirstRectangleEndx;
	int nSecondRectangleEndy=(m_nScreenHeight/2);

	int nThirdRectangleEndx=(m_nScreenWidth/3)+nSecondRectangleEndx;
	int nThirdRectangleEndy=m_nScreenHeight/2;

	Mat overlay;
	double alpha = 0.6;
	xGuiWindowCopy.copyTo(overlay);
	int thickness=10;
	if(m_nModeSwitch==1)
	{
		rectangle( xGuiWindowCopy, Point( 0+thickness, 0+thickness ), Point(nFirstRectangleEndx-thickness ,nFirstRectangleEndy-thickness), Scalar( 123, 255, 255 ), -1, 4 );
		cout<<m_nModeSwitch<<endl;
	}

	else if(m_nModeSwitch==2)
	{
		rectangle( xGuiWindowCopy, Point(nFirstRectangleEndx+thickness , 0+thickness ), Point(nSecondRectangleEndx-thickness ,nSecondRectangleEndy-thickness), Scalar( 123, 255, 255 ), -1, 4 );
		cout<<m_nModeSwitch<<endl;

	}

	else if(m_nModeSwitch==3)
	{
		rectangle( xGuiWindowCopy, Point( nSecondRectangleEndx+thickness, 0+thickness ), Point(nThirdRectangleEndx-thickness ,nThirdRectangleEndy-thickness), Scalar( 123, 255, 255 ), -1, 4 );
		cout<<m_nModeSwitch<<endl;

	}

	else if(m_nModeSwitch==4)
	{
		rectangle( xGuiWindowCopy, Point(0+thickness,nFirstRectangleEndy+thickness), Point(nFirstRectangleEndx-thickness ,m_nScreenHeight-thickness), Scalar( 123, 255, 255 ), -1, 4 );
		cout<<m_nModeSwitch<<endl;
	}

	else if(m_nModeSwitch==5)
	{
		rectangle( xGuiWindowCopy, Point(nFirstRectangleEndx+thickness , nSecondRectangleEndy+thickness ), Point(nSecondRectangleEndx-thickness,m_nScreenHeight-thickness), Scalar( 123, 255, 255 ), -1, 4 );
		cout<<m_nModeSwitch<<endl;

	}

	else if(m_nModeSwitch==6)
	{
		rectangle( xGuiWindowCopy, Point( nSecondRectangleEndx+thickness, nThirdRectangleEndy+thickness ), Point(nThirdRectangleEndx-thickness ,m_nScreenHeight-thickness), Scalar( 123, 255, 255 ), -1, 4 );
		cout<<m_nModeSwitch<<endl;

	}

	addWeighted(overlay, alpha, xGuiWindowCopy, 1 - alpha, 0, xGuiWindowCopy);

	m_xGuiBackground=xGuiWindowCopy;

}
void ThreadParam :: nextCloudeMode(Mat xGuiWindow)
{

	Mat xGuiWindowCopy;
	xGuiWindow.copyTo(xGuiWindowCopy);

	int nFirstRectangleEndx=m_nScreenWidth/3;
	int nFirstRectangleEndy=m_nScreenHeight/2;

	int nSecondRectangleEndx=(m_nScreenWidth/3)+nFirstRectangleEndx;
	int nSecondRectangleEndy=(m_nScreenHeight/2);

	int nThirdRectangleEndx=(m_nScreenWidth/3)+nSecondRectangleEndx;
	int nThirdRectangleEndy=m_nScreenHeight/2;

	Mat overlay;
	double alpha = 0.6;
	xGuiWindowCopy.copyTo(overlay);


	if(m_nUpdateModeSwitch==1)
	{
		rectangle( xGuiWindowCopy, Point( 0, 0 ), Point(nFirstRectangleEndx ,nFirstRectangleEndy), Scalar( 255, 255, 255 ), -1, 4 );
		cout<<m_nUpdateModeSwitch<<endl;
	}

	else if(m_nUpdateModeSwitch==2)
	{
		rectangle( xGuiWindowCopy, Point(nFirstRectangleEndx , 0 ), Point(nSecondRectangleEndx ,nSecondRectangleEndy), Scalar( 255, 255, 255 ), -1, 4 );
		cout<<m_nUpdateModeSwitch<<endl;

	}

	else if(m_nUpdateModeSwitch==3)
	{
		rectangle( xGuiWindowCopy, Point( nSecondRectangleEndx, 0 ), Point(nThirdRectangleEndx ,nThirdRectangleEndy), Scalar( 255, 255, 255 ), -1, 4 );
		cout<<m_nUpdateModeSwitch<<endl;

	}
	else if(m_nUpdateModeSwitch == 4)
	{
		rectangle( xGuiWindowCopy, Point(0,nFirstRectangleEndy), Point(nFirstRectangleEndx ,m_nScreenHeight), Scalar( 255, 255, 255 ), -1, 4 );
		cout<<m_nModeSwitch<<endl;
	}

	else if(m_nUpdateModeSwitch == 5)
	{
		rectangle( xGuiWindowCopy, Point(nFirstRectangleEndx , nSecondRectangleEndy ), Point(nSecondRectangleEndx,m_nScreenHeight), Scalar( 255, 255, 255 ), -1, 4 );
		cout<<m_nModeSwitch<<endl;
	}



	addWeighted(overlay, alpha, xGuiWindowCopy, 1 - alpha, 0, xGuiWindowCopy);

	m_xGuiUpdateBackground = xGuiWindowCopy;

}

int ThreadParam ::  buttonPress()
{
	delay(1);
	if (digitalRead (m_nKey1) == 0)
	{
		//cout << "key -1 is press " << endl;
		delay(300);
		return 1;

	}

	if (digitalRead (m_nKey3) == 0)
	{
		//cout << "key - 3 is press" << endl;
		delay(300);
		return 3;
	}

	if (digitalRead (m_nKey2) == 0)
	{
		//cout << "key - 2 is press" << endl;
		delay(300);
		return 2;
	}

	return 0;
}

