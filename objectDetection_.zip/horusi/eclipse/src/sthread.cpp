/*
 * Thread.cpp
 *
 *  Created on: March,13 2017
 *      Author: pratik solanki
 */

#include "sthread.h"
#include <iostream>
#include <wiringPi.h>
#include "horusclassifier.h"
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netdb.h>
#include <ifaddrs.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <linux/if_link.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "modes.h"
#include "overlay.h"
#include <sys/time.h>
#include <sys/stat.h>
#include <dirent.h>
#include <string.h>
#include <algorithm>
#include "Recordmode.h"
#include "enum.h"

using namespace std;
#define OFFLINEMODE 3
#define LOGFILELINE 10000
#define BUFFERSIZE 100
#define INITBUFFER 500000
#define MAINTAINONEFPS(time) 2000000 - (time * 1000)
#define MILISECOND 1000
#define VEHICLETIMESTEP 1000
#define PEDESTRAINTIMESTEP 1500
#define WAITTIME 500000
#define SECONDSTOMICROSECONDS 1000000
#define SIZE 1024
#define FPS 30.0
#define ROTATED_IMAGE 0
#define CALULATEROWOVERLAP(v1, v2) (double)(v1/v2) * 100
#define NOOFVIDOES 60
#define RECORDMINUTES  1800
extern pthread_mutex_t mutexWifiStatus;
extern pthread_cond_t  condWifiStatus;

extern pthread_mutex_t mutexDisplayRecordedFrame;
extern pthread_cond_t  condDisplayRecordedFrame;

extern pthread_mutex_t mutexRecordModeExit;


pthread_mutex_t mutexObjectDetectionLoggingProtect=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexLogGlobalDataWriteAcess=PTHREAD_MUTEX_INITIALIZER;

pthread_cond_t  condLogDataWriteAcess  = PTHREAD_COND_INITIALIZER;

pthread_cond_t  condAppmodeLicencePlateFrameReady  = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutexAppmodeLicencePlateFrameReady = PTHREAD_MUTEX_INITIALIZER;

pthread_cond_t condWaitTime = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutexWaitTime = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t condWaitTimeOver = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutexWaitTimeOver = PTHREAD_MUTEX_INITIALIZER;

pthread_cond_t  condRecordFrameReady   = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutexRecordFrameReady = PTHREAD_MUTEX_INITIALIZER;

pthread_mutex_t  mutexcondLogDataWriteAcess  = PTHREAD_MUTEX_INITIALIZER;

pthread_mutex_t mutexcondAppmodeVehicleFrameReady=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t prevetDestroyWindow=PTHREAD_MUTEX_INITIALIZER;

pthread_mutex_t mutexAppmodeVehicleFrameaccess     = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  condAppmodeVehicleFrameReady   = PTHREAD_COND_INITIALIZER;

pthread_cond_t  conDisplayUserFeedback   = PTHREAD_COND_INITIALIZER;

pthread_mutex_t mutexDisplayUserFeedback = PTHREAD_MUTEX_INITIALIZER;

pthread_mutex_t frameAccessForAppmode     = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t detectedObjectAccess = PTHREAD_MUTEX_INITIALIZER;

pthread_cond_t  condPlayRecoredVideo   = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutexPlayRecoredVideoAccess=PTHREAD_MUTEX_INITIALIZER;


pthread_mutex_t mutexcondAppmodePedestrianFrameReady=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexAppmodePedestrianFrameaccess     = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  condAppmodePedestrianFrameReady   = PTHREAD_COND_INITIALIZER;
pthread_cond_t  condEXITAPPMODE   = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutexEXITAPPMODE     = PTHREAD_MUTEX_INITIALIZER;


pthread_mutex_t mutexcondAppmodeDisplayFrameReady=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexAppmodeDisplayframeaccess=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t condAppmodeDisplayFrameReady=PTHREAD_COND_INITIALIZER;


pthread_mutex_t mutexAppmodeSignalAcess=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t condAppmodeSignal=PTHREAD_COND_INITIALIZER;

pthread_mutex_t mutexAppmodeStopSignalAcess=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t condAppmodeStopSignal=PTHREAD_COND_INITIALIZER;

pthread_mutex_t mutexAppmodePedestrianStopSignalAcess=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t condAppmodePedestrianStopSignal=PTHREAD_COND_INITIALIZER;

FILE *pDetectionLogFile;


#define EMPTYQUEUE -1


// global data for logging

string sLogThreadName;
string sLogXMLName;
float nLogScale;
int nLogMinNeighbour;
int nLogminimumsize;
int nLogObjects;
double nLogDetectionTime;
float nLogCpuUsage;
int g_nFrameHeight;
int g_nFrameWidth;


void *wifiStatus(void *data)
{
	bool networkStatus = false;
	ThreadParam &globalData = (*(ThreadParam *)data);
	struct ifaddrs *ifaddr, *ifa;
	int family, s, n;
	char host[NI_MAXHOST];

	while(1){
		pthread_cond_wait( &condWifiStatus, &mutexWifiStatus );

		cout<<"wifi Thread Running"<<endl;



		if (getifaddrs(&ifaddr) == -1) {
			perror("getifaddrs");
			exit(EXIT_FAILURE);
		}


		/* Walk through linked list, maintaining head pointer so we
	              can free list later */

		for (ifa = ifaddr, n = 0; ifa != NULL; ifa = ifa->ifa_next, n++) {
			if (ifa->ifa_addr == NULL)
				continue;

			family = ifa->ifa_addr->sa_family;

			/* Display interface name and family (including symbolic
	                  form of the latter for the common families) */

			if((strcmp(ifa->ifa_name, "wlp3s0") == 0) || (strcmp(ifa->ifa_name, "wlo1") == 0) || (strcmp(ifa->ifa_name, "wlan0") == 0)){


				/*printf("%-8s %s (%d)\n",
	                      ifa->ifa_name,
	                      (family == AF_PACKET) ? "AF_PACKET" :
	                      (family == AF_INET) ? "AF_INET" :
	                      (family == AF_INET6) ? "AF_INET6" : "???",
	                      family);
				 */
				/* For an AF_INET* interface address, display the address */

				if (family == AF_INET || family == AF_INET6) {
					s = getnameinfo(ifa->ifa_addr,
							(family == AF_INET) ? sizeof(struct sockaddr_in) :
									sizeof(struct sockaddr_in6),
									host, NI_MAXHOST,
									NULL, 0, NI_NUMERICHOST);
					if (s != 0) {
						printf("getnameinfo() failed: %s\n", gai_strerror(s));
						exit(EXIT_FAILURE);
					}

					//printf("\t\taddress: <%s>\n", host);
					networkStatus = true;
					break;
				} /*else if (family == AF_PACKET && ifa->ifa_data != NULL) {
	                   struct rtnl_link_stats *stats = ifa->ifa_data;

	                   printf("\t\ttx_packets = %10u; rx_packets = %10u\n"
	                          "\t\ttx_bytes   = %10u; rx_bytes   = %10u\n",
	                          stats->tx_packets, stats->rx_packets,
	                          stats->tx_bytes, stats->rx_bytes);
	               }*/
			}
		}
		if(networkStatus == true){
			//cout << "Network is connected" << endl;
			freeifaddrs(ifaddr);
			globalData.networkCheck = true;
			networkStatus = false;

		}else{
			freeifaddrs(ifaddr);
			globalData.networkCheck = false;
			networkStatus = false;
			//cout << "there is no network" << endl;
			//AG continue;
		}

		pthread_cond_signal(&condWifiStatus);


	}

}

void * keyReader(void *dat)
{

	ThreadParam &globalData = *((ThreadParam *)dat);

	Mat OriginalHomeWindow;
	globalData.m_xGuiBackground.copyTo(OriginalHomeWindow);
	globalData.nextMode(OriginalHomeWindow);

	Mat OriginalUpdateHomeWindow;
	globalData.m_xGuiUpdateBackground.copyTo(OriginalUpdateHomeWindow);
	globalData.nextCloudeMode(OriginalUpdateHomeWindow);

	/// For configure GPIO pins
	if(globalData.m_bRaspberry){

		if(wiringPiSetup() < 0){
			cout << "wiringPi library load fail" << endl;
			exit(0);
		}

		pinMode(1,INPUT);
		pinMode(4,INPUT);
		pinMode(5,INPUT);



		pullUpDnControl(1, PUD_UP);
		pullUpDnControl(4, PUD_UP);
		pullUpDnControl(5, PUD_UP);
	}

	int keyNum = 0;

	if(globalData.m_bRaspberry){

		while(1){

			ThreadParam &globalData = *((ThreadParam *)dat);

			keyNum = globalData.buttonPress();

			if((keyNum == 1) || (keyNum == 2) || (keyNum == 3)){
				cout << "KEY " << keyNum << " number is press" << endl;
			}

			if(keyNum == 1){

				cout << "CloudeModeFlag ::" << globalData.cloudeModeFlag << endl;

				if(!globalData.cloudeModeFlag){

					if(globalData.mode == 0)
					{
						globalData.m_nModeSwitch=abs((globalData.m_nModeSwitch % 6) + 1);
						globalData.nextMode(OriginalHomeWindow);
					}
					if(globalData.mode == OFFLINEMODE){

						globalData.keyOnePress = true;
						cout << "KEY ONE IS PRESS in ------------------->Thread" << endl;
					}

				}else {
					//cout << "MODE ::::: IN THREAD ::" << globalData.mode  << endl;
					if(globalData.updateMode == 0)
					{
						globalData.m_nUpdateModeSwitch = abs((globalData.m_nUpdateModeSwitch % 5) + 1);
						globalData.nextCloudeMode(OriginalUpdateHomeWindow);
					}

				}

			}

			if(keyNum == 3){
				if(!globalData.cloudeModeFlag){

					if(globalData.mode==0)
					{
						globalData.m_nModeSwitch=( abs (globalData.m_nModeSwitch - 1) % 6);
						if(globalData.m_nModeSwitch==0){
							globalData.m_nModeSwitch = 6;
						}
						globalData.nextMode(OriginalHomeWindow);
					}

					if(globalData.mode == OFFLINEMODE){
						globalData.keyThreePress = true;
						cout << "KEY Three IS PRESS-------------------> THREAD" << endl;
					}
				}else {

					//cout << "MODE ::::: IN THREAD ::" << globalData.mode  << endl;
					if(globalData.updateMode==0)
					{
						globalData.m_nUpdateModeSwitch=(abs(globalData.m_nUpdateModeSwitch-1) % 5);
						if(globalData.m_nUpdateModeSwitch == 0){
							globalData.m_nUpdateModeSwitch = 5;
						}
						globalData.nextCloudeMode(OriginalUpdateHomeWindow );
					}


				}

			}

			if(keyNum == 2){

				if(!globalData.cloudeModeFlag){

					if(globalData.mode == 0){
						globalData.mode = globalData.m_nModeSwitch;
					}else{
						globalData.mode = 0;
					}
				}else{

					if(globalData.updateMode == 0){
						globalData.updateMode = globalData.m_nUpdateModeSwitch;
					}else{
						globalData.updateMode = 0;
					}
				}
			}
		}
		usleep(100000);
	}
}

template <class T>
int  numDigits(T number)
{
	int digits = 0;
	if (number < 0) digits = 1;
	while (number) {
		number /= 10;
		digits++;
	}
	return digits;
}



void *displayRecordedImage(void *data)
{

	string diffStr = "";
	int rWidth = 0;
	int rHeight = 0;
	char fileName [1024];
	char difftime [1024];
	int tmp;
	Mat frame;
	double startTime = 0;
	double  endTime = 0;
	int nWaitTime=0;
	Modes mode;
	double  displayStartTime = 0;
	double  displyEndTime = 0;

	ThreadParam &globalData = ( *( ThreadParam *)data);

	while(1){

		//pthread_mutex_lock(&globalData.recordSignalMutex);
		//perror("pthread_mutex_lock:");

		cout << "WIATING FOR SIGNAL" << endl;

		pthread_cond_wait( &globalData.recordCond, &globalData.recordSignalMutex );

		//pthread_mutex_unlock(&globalData.recordSignalMutex);
		//perror("pthread_mutex_unlock:");

		cout << " GET  SIGNAL" << endl;

		usleep(INITBUFFER);

		while(globalData.mode == 4){

			startTime = cvGetTickCount();

			//cout << "READ  FRAME ::" << globalData.readCursor << endl;

			//pthread_mutex_lock(&globalData.recordMutex2);

			frame = globalData.queueFrame[globalData.readCursor];


			if(frame.empty()){
				cout << "THERE IS NO IMAGE" << endl;
				nWaitTime=globalData.writeFrameTime*1000;
				usleep(nWaitTime);
				continue;
			}

			mode.lineconfiguration(frame,globalData.m_nEndROIy,globalData.m_nleftendx,globalData.m_nrightendx,globalData.highwaymode);

			time_t rawtime1;

			struct tm * timeinfo1;

			time (&rawtime1);
			timeinfo1 = localtime (&rawtime1);

			globalData.endTime.hours    =  timeinfo1->tm_hour;
			globalData.endTime.minutes = timeinfo1->tm_min;
			globalData.endTime.seconds = timeinfo1->tm_sec;

			globalData.computeTimeDifference(globalData.startTime, globalData.endTime, &globalData.difference);

			//cout << "differnt :: seconds ::" << globalData.difference.seconds << endl;


			if(numDigits(globalData.difference.minutes) == 1 || numDigits(globalData.difference.minutes) == 0 ){
				sprintf(difftime,"0%d", globalData.difference.minutes);
				diffStr = difftime;
			}else{
				sprintf(difftime,"%d",globalData.difference.minutes);
				diffStr =difftime;
			}

			if(numDigits(globalData.difference.seconds) == 1){
				sprintf(difftime,":0%d", globalData.difference.seconds);
				diffStr = diffStr + difftime;
			}else{
				sprintf(difftime,":%d", globalData.difference.seconds);
				diffStr = diffStr + difftime;
			}

			sprintf(fileName, "FILE : %d.avi", globalData.videoId);

			rHeight = 80;
			rWidth = 40;

			putText(frame, fileName, Point(rWidth, rHeight), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);

			rHeight = 100;
			rWidth = 40;

			sprintf(fileName, "TIME : %s", diffStr.c_str());
			putText(frame, fileName, Point(rWidth, rHeight), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);

			rHeight = 40;
			rWidth = 40;

			putText(frame, "HORUS-I", Point(rWidth, rHeight), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);

			rHeight = 60;
			rWidth = 40;

			putText(frame, "RECORD MODE", Point(rWidth, rHeight), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);

			imshow("Record Window", frame);

			waitKey(1);



			endTime = (cvGetTickCount()-startTime)/((double)cvGetTickFrequency()*1000);

			cout  << " READ CURSOR ::  " << globalData.readCursor <<  " READ THREAD TIME :: " <<  endTime << endl;

			//			cout<< "read frame time : "<<endTime<<endl;
			//			cout<< "write frame time : "<<globalData.writeFrameTime<<endl;
			nWaitTime=0;
			if(endTime < globalData.writeFrameTime)
			{
				nWaitTime=(globalData.writeFrameTime-endTime);
				cout<<"waiting for remaining time : "<< nWaitTime <<endl;
				usleep(nWaitTime);
			}

			cout<<"Total loop timing : "<< globalData.writeFrameTime - endTime<<endl;

			globalData.queueFrame[globalData.readCursor].release();

			globalData.readCursor ++;

			globalData.readCursor = globalData.readCursor % BUFFERSIZE;

			//cout << "BEFORE UNLOCK in thread" << endl;

			//pthread_mutex_unlock(&globalData.recordMutex1);

			//cout << "after unlock in thread  :: "  << endl;

		}
		cout << "NOW MOODE == 4 CONDITion fail" << endl;

		globalData.writeCursor = 0;
		globalData.readCursor = 0;

	}
}


void AppCallBackWindow(int event, int x, int y, int flags, void* userdata)
{
	ThreadParam* PassedArguments=(ThreadParam *)userdata;
	int count = 0;
	int buttonRegion = g_nFrameWidth - (g_nFrameWidth /6);

	if  ( event == EVENT_LBUTTONDOWN )
	{
		if((y<(g_nFrameHeight/1.15)) && (x < buttonRegion))
		{
			PassedArguments->mode=0;
			cout << "MODE 0 " <<  endl;
		}
		else
		{
			int nButtonTotalRegion=(g_nFrameWidth-g_nFrameWidth/10)-(g_nFrameWidth/10);
			int nFirstEnd=g_nFrameWidth/10+(nButtonTotalRegion/3);
			int nSecondEnd=nFirstEnd+(nButtonTotalRegion/3);
			int nThirdEnd=nSecondEnd+(nButtonTotalRegion/3);

			int playRecordedVideoFirstStartx = g_nFrameWidth - (g_nFrameWidth /6);

			int playRecordedVideoFirstEndy = g_nFrameHeight/3;

			int playRecordedVideoSecondStartx = playRecordedVideoFirstStartx;
			int playRecordedVideoSecondStarty = playRecordedVideoFirstEndy;

			int playRecordedVideoSecondEndx = g_nFrameWidth;
			int playRecordedVideoSecondEndy = playRecordedVideoFirstEndy * 2;


			if(x>g_nFrameWidth/10 && x<nFirstEnd)
			{
				cout<<"city"<<endl;
				PassedArguments->highwaymode=0;
				PassedArguments->citymode=1;
				PassedArguments->citymodeUserFeedBackStatus = ! PassedArguments->citymodeUserFeedBackStatus;
			}

			if(x>nFirstEnd && x<nSecondEnd)
			{

				if(PassedArguments->ndisplayVideo)
				{
					PassedArguments->ndisplayVideo=0;
				}
				else
				{
					PassedArguments->ndisplayVideo=1;
				}
				PassedArguments->videoDisplayUserFeedBackStatus = !PassedArguments->videoDisplayUserFeedBackStatus;
			}

			if(x>nSecondEnd && x<nThirdEnd && (y>(g_nFrameHeight/1.15)))
			{
				cout<<"Highway"<<endl;
				PassedArguments->citymode=0;
				PassedArguments->highwaymode=1;
				PassedArguments->highwaymodeUserFeedBackStatus = !PassedArguments->highwaymodeUserFeedBackStatus;
			}

			if((x > playRecordedVideoFirstStartx) && (y < playRecordedVideoFirstEndy)){
				cout<<"playback video"<<endl;
				PassedArguments->recordVideoFlag = !PassedArguments->recordVideoFlag;
				cout << "RECORDEDVIDEOFLAG ::" << PassedArguments->recordVideoFlag << endl;
				PassedArguments->cameraInputFlag = true;
				cout << "cameraInputFlag BUTTON ::" << PassedArguments->cameraInputFlag << endl;
				PassedArguments->swithchInputUserFeedBackStatus = !PassedArguments->swithchInputUserFeedBackStatus;


			}

			if((x > playRecordedVideoSecondStartx) && ((x <= playRecordedVideoSecondEndx)) &&
					(y <= playRecordedVideoSecondEndy) && (y > playRecordedVideoSecondStarty)){
				cout<<"pause video"<<endl;
				PassedArguments->pauseButton = !PassedArguments->pauseButton;
				PassedArguments->pauseButtonUserFeedBackStatus = !PassedArguments->pauseButtonUserFeedBackStatus;

			}

		}
	}
}


int getfileCount(char *folderPath)
{
	DIR *pdirectory;
	struct dirent *aFolder;
	int nFileCount=0;
	pdirectory= opendir(folderPath);
	if (pdirectory != NULL)
	{
		while (aFolder = readdir(pdirectory))
		{
			if(strstr(aFolder->d_name,".log"))
			{
				nFileCount++;
			}
		}
	}
	nFileCount++;
	return nFileCount;
}

void logCopyData(String sThreadName,
		String sXMLName,float nScale,
		int nMinimumNeighbour,
		int nMinimumsize,int nNoObjects,double nDetectionTime,float nCpusage)
{

	pthread_mutex_lock(&mutexLogGlobalDataWriteAcess);
	sLogThreadName=sThreadName;
	sLogXMLName=sXMLName;
	nLogMinNeighbour=nMinimumNeighbour;
	nLogminimumsize=nMinimumsize;
	nLogObjects=nNoObjects;
	nLogDetectionTime=nDetectionTime;
	nLogCpuUsage=nCpusage;
	pthread_mutex_unlock(&mutexLogGlobalDataWriteAcess);
	pthread_cond_signal(&condLogDataWriteAcess);
}

void *logAppMode(void *globalData)
{

	ThreadParam* Pass = (ThreadParam*) globalData;

	int nLineCount=0;
	String sThreadName;
	String sXMLName;
	float nScale;
	int nMinimumNeighbour;
	int nMinimumsize;
	int nNoObjects;
	double nDetectionTime;
	float nCpusage;
	struct stat filesize;
	float nlogFileSize;
	double startTime = cvGetTickCount();
	FILE * pLogFile;
	int nFilesCount=getfileCount("/home/horusi/horus-i/data/log");
	char sFilename[1024];
	sprintf(sFilename,"/home/horusi/horus-i/data/log/%d.log", nFilesCount);
	pLogFile = fopen(sFilename, "w");
	fprintf(pLogFile,"Thread,XML,Scale,MinNeigh,MinSize,Objects,Time,CPU Usage\n");
	fclose(pLogFile);

	while(1)
	{
		if(nLineCount>LOGFILELINE)
		{
			nFilesCount=getfileCount("/home/horusi/horus-i/data/log");
			sprintf(sFilename,"/home/horusi/horus-i/data/log/%d.log", nFilesCount);
			pLogFile = fopen(sFilename, "w");
			fprintf(pLogFile,"Thread,XML,Scale,MinNeigh,MinSize,Objects,Time,CPU Usage\n");
			fclose(pLogFile);
			nLineCount=0;

		}
		pthread_cond_wait(&condLogDataWriteAcess,&mutexcondLogDataWriteAcess);
		pthread_mutex_lock(&mutexLogGlobalDataWriteAcess);
		sThreadName=sLogThreadName;
		sXMLName=sLogXMLName;
		nMinimumNeighbour=nLogMinNeighbour;
		nMinimumsize=nLogminimumsize;
		nNoObjects=nLogObjects;
		nDetectionTime=nLogDetectionTime;
		nCpusage=nLogCpuUsage;
		pthread_mutex_unlock(&mutexLogGlobalDataWriteAcess);
		pLogFile=fopen(sFilename,"a");
		fprintf(pLogFile, "%s,%s,%.2f,%d,%d,%d,%.2f,%.2f\n", sThreadName.c_str(), sXMLName.c_str(), nScale, nMinimumNeighbour, nMinimumsize, nNoObjects, nDetectionTime, nCpusage);
		fclose(pLogFile);
		nLineCount++;
	}
}




void overlayframe(Mat& adrawAnalyseFrame,void *globalData,
		Detectobjectdata vehicleRect, Detectobjectdata pedRect,
		Detectobjectdata licenceRect ,int vidId,Mat &pauseFrame ,bool bOverlayButtons)
{

	ThreadParam* Pass = (ThreadParam*) globalData;
	overlayvariables overlayData;
	Mat axForegroungImage;
	char tmpVideoFile[SIZE];
	char vidFile[SIZE];

	Rect LeftpedestrianRectangle(overlayData.nLeftFirstRectangleStartx,overlayData.nLeftFirstRectangleStarty, overlayData.pedestrianiconImageresized.cols, overlayData.pedestrianiconImageresized.rows);
	Rect LeftPedestrianredRectangle(overlayData.nLeftSecondRectangleStartx,overlayData.nLeftSecondRectangleStarty, overlayData.pedestrianiconImageresized.cols, overlayData.pedestrianiconImageresized.rows);
	Rect LeftVehicleRectangle(overlayData.nLeftThirdRectangleStartx,overlayData.nLeftThirdRectangleStarty, overlayData.pedestrianiconImageresized.cols, overlayData.pedestrianiconImageresized.rows);
	Rect LeftVehicleredRectangle(overlayData.nLeftFourthRectangleStartx,overlayData.nLeftFourthRectangleStarty, overlayData.pedestrianiconImageresized.cols, overlayData.pedestrianiconImageresized.rows);

	Rect RightpedestrianRectangle(overlayData.nRightFirstRectangleStartx,overlayData.nRightFirstRectangleStarty, overlayData.pedestrianiconImageresized.cols, overlayData.pedestrianiconImageresized.rows);
	Rect RightPedestrianredRectangle(overlayData.nRightSecondRectangleStartx,overlayData.nRightSecondRectangleStarty, overlayData.pedestrianiconImageresized.cols, overlayData.pedestrianiconImageresized.rows);
	Rect RightVehicleRectangle(overlayData.nRightThirdRectangleStartx,overlayData.nRightThirdRectangleStarty, overlayData.pedestrianiconImageresized.cols, overlayData.pedestrianiconImageresized.rows);
	Rect RightVehicleredRectangle(overlayData.nRightFourthRectangleStartx,overlayData.nRightFourthRectangleStarty, overlayData.pedestrianiconImageresized.cols, overlayData.pedestrianiconImageresized.rows);

	Modes modes;

	Pass->drawDetection(adrawAnalyseFrame,pedRect, vehicleRect,licenceRect,
			Pass->m_nEndROIy,Pass->m_nleftendx,Pass->m_nrightendx,Pass->m_nHeightROI,
			Pass->m_bShowDetectedPedestrian,Pass->m_bShowDetectedVehicle,Pass->m_bShowDetectedAll,
			true,Pass->m_sHistogramTemplateImage,Pass->m_bShowROIelemination,
			Pass->m_pSvm,Pass->m_bImageclassification,8,Pass);

	if(Pass->pauseButton == true){
		adrawAnalyseFrame.copyTo(pauseFrame);
	}

	if(Pass->displayvideoCmdLine == false){

		if(Pass->ndisplayVideo)
		{
			overlayData.DisplayStringVideoMode="Hide video";
		}
		else
		{
			overlayData.DisplayStringVideoMode="DISPLAY video";
			adrawAnalyseFrame=overlayData.BackgroundImage.clone();
			if(Pass->pauseButton != true){
				Pass->lineconfiguration(adrawAnalyseFrame,Pass->m_nEndROIy,Pass->m_nleftendx
						,Pass->m_nrightendx, Pass->highwaymode);
			}

		}

	}else{

		if(!Pass->ndisplayVideo)
		{
			overlayData.DisplayStringVideoMode="Hide video";
		}
		else
		{
			overlayData.DisplayStringVideoMode="DISPLAY video";
			adrawAnalyseFrame=overlayData.BackgroundImage.clone();
			if(Pass->pauseButton != true){
				Pass->lineconfiguration(adrawAnalyseFrame,Pass->m_nEndROIy,Pass->m_nleftendx
						,Pass->m_nrightendx, Pass->highwaymode);
			}

		}

	}


	double alpha = 0.4;
	adrawAnalyseFrame.copyTo(axForegroungImage);

	if(Pass->m_nNoofpedestrianinYellowROI)
	{
		if(Pass->m_nPedestrianLeftCount)
		{
			overlayData.pedestrianiconImageresized.copyTo(adrawAnalyseFrame(LeftpedestrianRectangle));
		}
		if(Pass->m_nPedestrianRightCount)
		{
			overlayData.pedestrianiconImageresized.copyTo(adrawAnalyseFrame(RightpedestrianRectangle));
		}
	}
	if(Pass->m_nNoofpedestrianinRedROI)
	{
		if(Pass->m_nPedestrianLeftCount)
		{
			overlayData.pedestrianrediconImageresized.copyTo(adrawAnalyseFrame(LeftPedestrianredRectangle));
		}
		if(Pass->m_nPedestrianRightCount)
		{
			overlayData.pedestrianrediconImageresized.copyTo(adrawAnalyseFrame(RightPedestrianredRectangle));
		}
	}
	if(Pass->m_nNoofVehicleinYellowROI)
	{
		if(Pass->m_nVehicleLeftCount)
		{
			overlayData.vehicleiconImageresized.copyTo(adrawAnalyseFrame(LeftVehicleRectangle));
		}
		if(Pass->m_nVehicleRightCount)
		{
			overlayData.vehicleiconImageresized.copyTo(adrawAnalyseFrame(RightVehicleRectangle));
		}
	}
	if(Pass->m_nNoofVehicleinRedROI)
	{
		if(Pass->m_nVehicleLeftCount)
		{
			overlayData.vehiclerediconImageresized.copyTo(adrawAnalyseFrame(LeftVehicleredRectangle));
		}
		if(Pass->m_nVehicleRightCount)
		{
			overlayData.vehiclerediconImageresized.copyTo(adrawAnalyseFrame(RightVehicleredRectangle));
		}
	}

	Pass->m_nNoofpedestrianinRedROI=0;
	Pass->m_nNoofpedestrianinYellowROI=0;
	Pass->m_nNoofVehicleinRedROI=0;
	Pass->m_nNoofVehicleinYellowROI=0;

	Pass->m_nVehicleLeftCount=0;
	Pass->m_nVehicleRightCount=0;
	Pass->m_nPedestrianLeftCount=0;
	Pass->m_nPedestrianRightCount=0;


	rectangle( adrawAnalyseFrame, Point(overlayData.nFirstButtonStartx,overlayData.nFirstButtonStarty), Point(overlayData.nFirstButtonEndx ,overlayData.nFirstButtonEndy), Scalar( 0, 0, 255 ), -1, 4 );
	rectangle( adrawAnalyseFrame, Point(overlayData.nSecondButtonStartx,overlayData.nSecondButtonStarty), Point(overlayData.nSecondButtonEndx ,overlayData.nSecondButtonEndy), Scalar( 255, 0, 255 ), -1, 4 );
	rectangle( adrawAnalyseFrame, Point(overlayData.nThirdButtonStartx,overlayData.nThirdButtonStarty), Point(overlayData.nThirdButtonEndx ,overlayData.nThirdButtonEndy), Scalar( 0, 0, 255 ), -1, 4 );
	rectangle( adrawAnalyseFrame, Point(overlayData.playRecordedVideoFirstStartx, overlayData.playRecordedVideoFirstStarty), Point(overlayData.playRecordedVideoFirstEndx  ,overlayData.playRecordedVideoFirstEndy), Scalar( 0, 0, 255 ), -1, 4 );
	rectangle( adrawAnalyseFrame, Point(overlayData.playRecordedVideoSecondStartx, overlayData.playRecordedVideoSecondStarty), Point(overlayData.playRecordedVideoSecondEndx  ,overlayData.playRecordedVideoSecondEndy), Scalar( 0, 255, 0 ), -1, 4 );


	cv::addWeighted(axForegroungImage, alpha, adrawAnalyseFrame, 1 - alpha, 0, adrawAnalyseFrame);

	putText(adrawAnalyseFrame, "City Mode", Point((overlayData.nFirstButtonStartx+((overlayData.nFirstButtonEndx-overlayData.nFirstButtonStartx)/4)),(overlayData.nFirstButtonStarty+((overlayData.nFirstButtonEndy-overlayData.nFirstButtonStarty)/2))), FONT_HERSHEY_PLAIN,1.2,CV_RGB(0,255,0), 2);
	putText(adrawAnalyseFrame, overlayData.DisplayStringVideoMode, Point((overlayData.nFirstButtonEndx+((overlayData.nSecondButtonEndx-overlayData.nSecondButtonStartx)/6)),(overlayData.nSecondButtonStarty+((overlayData.nSecondButtonEndy-overlayData.nSecondButtonStarty)/2))), FONT_HERSHEY_PLAIN,1.2,CV_RGB(0,255,0), 2);
	putText(adrawAnalyseFrame, "Highway Mode", Point((overlayData.nThirdButtonStartx+((overlayData.nThirdButtonEndx-overlayData.nThirdButtonStartx)/6)),(overlayData.nThirdButtonStarty+((overlayData.nThirdButtonEndy-overlayData.nThirdButtonStarty)/2))), FONT_HERSHEY_PLAIN,1.2,CV_RGB(0,255,0), 2);

	putText(adrawAnalyseFrame,overlayData.displayHoruseye.str() , Point2f(100,40), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
	putText(adrawAnalyseFrame,overlayData.displayMode.str() , Point2f(100,60), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);


	putText(adrawAnalyseFrame, "Switch" , Point2f(overlayData.playRecordedVideoFirstStartx + 10,overlayData.playRecordedVideoFirstStarty + 50), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
	putText(adrawAnalyseFrame, "Input" , Point2f(overlayData.playRecordedVideoFirstStartx + 10,overlayData.playRecordedVideoFirstStarty + 70), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
	putText(adrawAnalyseFrame, "Pause" , Point2f(overlayData.playRecordedVideoSecondStartx + 10 ,overlayData.playRecordedVideoSecondStarty + 50), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);

	sprintf(vidFile, "Record Video", Pass->videoId);
	putText(adrawAnalyseFrame, vidFile , Point2f(300,50), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);

	if(Pass->recordVideoFlag == true){
		sprintf(tmpVideoFile, "FILE %d.avi",vidId);
		putText(adrawAnalyseFrame,tmpVideoFile, Point(100, 80), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
	}
	if(Pass->pauseButton == true){

		rectangle( pauseFrame, Point(overlayData.nFirstButtonStartx,overlayData.nFirstButtonStarty), Point(overlayData.nFirstButtonEndx ,overlayData.nFirstButtonEndy), Scalar( 0, 0, 255 ), -1, 4 );
		rectangle( pauseFrame, Point(overlayData.nSecondButtonStartx,overlayData.nSecondButtonStarty), Point(overlayData.nSecondButtonEndx ,overlayData.nSecondButtonEndy), Scalar( 255, 0, 255 ), -1, 4 );
		rectangle( pauseFrame, Point(overlayData.nThirdButtonStartx,overlayData.nThirdButtonStarty), Point(overlayData.nThirdButtonEndx ,overlayData.nThirdButtonEndy), Scalar( 0, 0, 255 ), -1, 4 );
		rectangle( pauseFrame, Point(overlayData.playRecordedVideoFirstStartx, overlayData.playRecordedVideoFirstStarty), Point(overlayData.playRecordedVideoFirstEndx  ,overlayData.playRecordedVideoFirstEndy), Scalar( 0, 0, 255 ), -1, 4 );
		rectangle( pauseFrame, Point(overlayData.playRecordedVideoSecondStartx, overlayData.playRecordedVideoSecondStarty), Point(overlayData.playRecordedVideoSecondEndx  ,overlayData.playRecordedVideoSecondEndy), Scalar( 0, 255, 0 ), -1, 4 );


		cv::addWeighted(axForegroungImage, alpha, pauseFrame, 1 - alpha, 0, pauseFrame);

		putText(pauseFrame, "City Mode", Point((overlayData.nFirstButtonStartx+((overlayData.nFirstButtonEndx-overlayData.nFirstButtonStartx)/4)),(overlayData.nFirstButtonStarty+((overlayData.nFirstButtonEndy-overlayData.nFirstButtonStarty)/2))), FONT_HERSHEY_PLAIN,1.2,CV_RGB(0,255,0), 2);
		putText(pauseFrame, overlayData.DisplayStringVideoMode, Point((overlayData.nFirstButtonEndx+((overlayData.nSecondButtonEndx-overlayData.nSecondButtonStartx)/6)),(overlayData.nSecondButtonStarty+((overlayData.nSecondButtonEndy-overlayData.nSecondButtonStarty)/2))), FONT_HERSHEY_PLAIN,1.2,CV_RGB(0,255,0), 2);
		putText(pauseFrame, "Highway Mode", Point((overlayData.nThirdButtonStartx+((overlayData.nThirdButtonEndx-overlayData.nThirdButtonStartx)/6)),(overlayData.nThirdButtonStarty+((overlayData.nThirdButtonEndy-overlayData.nThirdButtonStarty)/2))), FONT_HERSHEY_PLAIN,1.2,CV_RGB(0,255,0), 2);

		putText(pauseFrame,overlayData.displayHoruseye.str() , Point2f(100,40), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
		putText(pauseFrame,overlayData.displayMode.str() , Point2f(100,60), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);

		putText(adrawAnalyseFrame, "Switch" , Point2f(overlayData.playRecordedVideoFirstStartx + 10,overlayData.playRecordedVideoFirstStarty + 50), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
		putText(adrawAnalyseFrame, "Input" , Point2f(overlayData.playRecordedVideoFirstStartx + 10,overlayData.playRecordedVideoFirstStarty + 70), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
		putText(pauseFrame, "Pause" , Point2f(overlayData.playRecordedVideoSecondStartx + 10 ,overlayData.playRecordedVideoSecondStarty + 50), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
	}
}

void *playRecordedVideo(void *Data)
{

	ThreadParam* Pass = (ThreadParam*) Data;

	char vidFile[SIZE];
	Mat axFrame;

	while(1){
		pthread_cond_wait( &condPlayRecoredVideo, &mutexPlayRecoredVideoAccess);

		/// set parameter for play recorded videos
		Pass->setInitParaForPlayRecordedVideo();

		while((Pass->lowestVideoFileId <=  Pass->highestVideoFileId)
				&& (Pass->recordVideoFlag == true) && (Pass->mode == 1)){

			VideoCapture capture;

			sprintf(vidFile, "/home/horusi/recordvideos/%d.avi",Pass->lowestVideoFileId);

			cout << "vidFile in appMode :::"  << vidFile << endl;

			try
			{
				throw capture.open(vidFile);
			}

			catch( bool error)
			{
				int rs = Pass->errorHandler(capture, error);
				if(rs == VIDEOOPENINGERROR){
					continue;
				}else if(rs == NOVIDEOSFOUND){
					cout << "LOOP IS BREAK" << endl;
					cout << "there is no video " << endl;
					/// there is no video found
					break;
				}
			}

			int count = 0;
			Mat tmpCaptureFrame;

			while(Pass->mode == 1)
			{
				capture.read(axFrame);
				if(!axFrame.data){
					cout << "There is no frame" << endl;
					break;
				}
				pthread_mutex_lock( &frameAccessForAppmode );
				if(Pass->m_bInvertVideo == true){
					Mat matRotation = getRotationMatrix2D( Point(axFrame.cols/2, axFrame.rows/2), 180, 1 );
					// Rotate the image
					Mat imgRotated;
					warpAffine( axFrame, imgRotated, matRotation, axFrame.size() );
					tmpCaptureFrame = imgRotated.clone();
					resize(tmpCaptureFrame, Pass->m_xAppFrame, Size(720, 480), 0, 0, INTER_CUBIC);
				}else{
					resize(axFrame, Pass->m_xAppFrame, Size(720, 480), 0, 0, INTER_CUBIC);
				}

				pthread_cond_signal(&condAppmodeVehicleFrameReady);
				pthread_cond_signal(&condAppmodePedestrianFrameReady);

				pthread_mutex_unlock( &frameAccessForAppmode );

				if(count == 0){
					count = 1;
					pthread_cond_signal(&condAppmodeDisplayFrameReady);
				}
				axFrame.release();

			}


			//	Pass->m_bAppmodeavilable=false;
			capture.release();
			axFrame.release();

			Pass->lowestVideoFileId++;

			Pass->currentVideoPlay = Pass->lowestVideoFileId;

			/*
				if(Pass->lowestVideoFileId > Pass->highestVideoFileId){
					Pass->lowestVideoFileId = 1;
				}*/

		}
		Pass->exitFromPlayVideo = true;

		if(Pass->noVideoRecordedFlag != true){
			cout << "COME OUT FROM APPMODE " << endl;
			pthread_cond_wait( &condEXITAPPMODE, &mutexEXITAPPMODE);
			cout << "waiting over" << endl;

		}
		cvDestroyWindow("App Window");
		Pass->highwaymode=0;
		Pass->citymode=1;
		Pass->mode = 0;
		Pass->noVideoRecordedFlag = false;
		Pass->recordVideoFlag = false;
		pthread_cond_signal(&condAppmodeStopSignal);

	}

}

int initForPlayRecordedVideo(ThreadParam* Pass, VideoCapture &capture)
{
	char vidFile[SIZE];

	sprintf(vidFile, "/home/horusi/recordvideos/%d.avi",Pass->lowestVideoFileId);

	cout << "vidFile in appMode :::"  << vidFile << endl;

	try
	{
		throw capture.open(vidFile);
	}

	catch( bool error)
	{
		int rs = Pass->errorHandler(capture, error);
		return rs;

	}
	return SUCCESS;

}

void displayUserFeedback(ThreadParam *Pass)
{
	Mat image = imread("BackGround.jpg", 1);
	if(!image.data){
		cout << "BackGround.jpg image not present in DisplayAppMode" << endl;
		exit(0);
	}
	putText(image, "LOADING ....." , Point(100, 100), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
	pthread_mutex_lock(&prevetDestroyWindow);
	imshow("App Window",image);
	waitKey(100);
	pthread_mutex_unlock(&prevetDestroyWindow);
	image.release();
	/*	if(Pass->swithchInputUserFeedBackStatus == true) Pass->swithchInputUserFeedBackStatus = false;*/
	if(Pass->pauseButtonUserFeedBackStatus == true) Pass->pauseButtonUserFeedBackStatus = false;
	if(Pass->citymodeUserFeedBackStatus == true) Pass->citymodeUserFeedBackStatus = false;
	if(Pass->highwaymodeUserFeedBackStatus == true) Pass->highwaymodeUserFeedBackStatus = false;
	if(Pass->videoDisplayUserFeedBackStatus == true) Pass->videoDisplayUserFeedBackStatus = false;
}


void *captureAppmodeFrames(void *Data)
{
	ThreadParam* Pass = (ThreadParam*) Data;

	Mat axFrame;
	Mat axBlankBackground;
	Mat axErrorWindow;
	overlayvariables overlaydata;
	overlaydata.BackgroundImage.copyTo(axBlankBackground);
	putText(axBlankBackground, "Loading ", Point(((Pass->m_nScreenWidth/2)-75), Pass->m_nScreenHeight/2.5), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
	overlaydata.BackgroundImage.copyTo(axErrorWindow);
	putText(axErrorWindow, "Camera cannot open ", Point(((Pass->m_nScreenWidth/2)-200), Pass->m_nScreenHeight/2.5), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
	char vidFile[SIZE];
	g_nFrameWidth=640;
	g_nFrameHeight=480;

	while(1)
	{
		cout<<"Threads Waiting for Signal....."<<endl;
		pthread_cond_wait( &condAppmodeSignal, &mutexAppmodeSignalAcess );
		cout<<"\n\nThreads Started ....."<<endl;

		/// flag for exit from displayAPP mode
		Pass->exitFromPlayVideo = false;

		namedWindow("App Window",WINDOW_NORMAL);
		cvSetWindowProperty("App Window", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
		setMouseCallback("App Window",AppCallBackWindow,Pass);
		imshow("App Window",axBlankBackground);
		waitKey(10);

		Pass->m_bAppmodeavilable=true;

		VideoCapture capture;
		if(strcmp(Pass->m_sVideoFilename.c_str(), "NULL") == 0){
			capture.open(0);
		}else{
			capture.open(Pass->m_sVideoFilename);
		}

		if ( ! capture.isOpened() )
		{
			imshow("App Window",axErrorWindow);
			waitKey(2000);
			Pass->mode=0;
			capture.release();
			axFrame.release();
			cvDestroyWindow("App Window");
			pthread_cond_signal(&condAppmodeStopSignal);
			continue;
		}

		int count = 0;
		int ncount = 0;
		Mat tmpCaptureFrame;
		bool flag = true;

		while(Pass->mode == 1)
		{

			capture.read(axFrame);
			pthread_mutex_lock( &frameAccessForAppmode );

			if(!axFrame.data || Pass->cameraInputFlag == true){

				cout << "There is no frame in appmode" << endl;

				capture.release();
				Pass->m_xAppFrame.release();

				Mat image = imread("BackGround.jpg", 1);
				if(!image.data){
					cout << "BackGround.jpg image not present in DisplayAppMode" << endl;
					exit(0);
				}
				putText(image, "LOADING ....." , Point(100, 100), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
				pthread_mutex_lock(&prevetDestroyWindow);
				imshow("App Window",image);
				waitKey(100);
				pthread_mutex_unlock(&prevetDestroyWindow);

				/// set parameter for play recorded videos
				Pass->setInitParaForPlayRecordedVideo();

				if((Pass->lowestVideoFileId <=  Pass->highestVideoFileId)
						&& (Pass->recordVideoFlag == true) && (Pass->mode == 1)){
					int rs = initForPlayRecordedVideo(Pass, capture);
					/// while video is playing before completion of the video
					/// If I press the button then it should switch to camera feed
					Pass->cameraInputFlag = false;

					if(rs != SUCCESS){

						if(rs == NOVIDEOSFOUND){
							cout << "THERE IS NO VIDEOS" << endl;
							Pass->recordVideoFlag = false;
							if(strcmp(Pass->m_sVideoFilename.c_str(), "NULL") == 0){
								capture.open(0);
							}else{
								capture.open(Pass->m_sVideoFilename);
							}

							if (!capture.isOpened())
							{
								imshow("App Window",axErrorWindow);
								waitKey(2000);
								Pass->mode=0;
								capture.release();
								axFrame.release();
								cvDestroyWindow("App Window");
								pthread_cond_signal(&condAppmodeStopSignal);
								break;
							}
							pthread_mutex_unlock( &frameAccessForAppmode );
							continue;
						}
					}
					Pass->lowestVideoFileId++;
					Pass->currentVideoPlay = Pass->lowestVideoFileId;
					pthread_mutex_unlock( &frameAccessForAppmode );
					continue;
				}else{
					/// while video is playing before compltion of the video
					/// If I press the button then it should switch to camera feed
					Pass->cameraInputFlag = false;
					cout << "open the camera feed" << endl;
					if(strcmp(Pass->m_sVideoFilename.c_str(), "NULL") == 0){
						capture.open(0);
					}else{
						capture.open(Pass->m_sVideoFilename);
					}
					if (!capture.isOpened())
					{
						imshow("App Window",axErrorWindow);
						waitKey(2000);
						Pass->mode=0;
						capture.release();
						axFrame.release();
						cvDestroyWindow("App Window");
						pthread_cond_signal(&condAppmodeStopSignal);
						break;
					}
					flag = true;
					pthread_mutex_unlock( &frameAccessForAppmode );
					continue;
				}

			}
			if(Pass->m_bInvertVideo == true){

				Mat matRotation = getRotationMatrix2D( Point(axFrame.cols/2, axFrame.rows/2), 180, 1 );
				// Rotate the image
				Mat imgRotated;
				warpAffine( axFrame, imgRotated, matRotation, axFrame.size() );

				tmpCaptureFrame = imgRotated.clone();
				//				resize(tmpCaptureFrame, Pass->m_xAppFrame, Size(720, 480), 0, 0, INTER_CUBIC);

			}
			else
			{
				//				resize(axFrame, Pass->m_xAppFrame, Size(720, 480), 0, 0, INTER_CUBIC);
				axFrame.copyTo(Pass->m_xAppFrame);
			}


			pthread_cond_signal(&condAppmodeVehicleFrameReady);
			pthread_cond_signal(&condAppmodePedestrianFrameReady);
			pthread_cond_signal(&condAppmodeLicencePlateFrameReady);
			if(Pass->recordVideoFlag != true){
				pthread_cond_signal(&condRecordFrameReady);
			}

			pthread_mutex_unlock( &frameAccessForAppmode );

			if(count == 0){
				count = 1;
				pthread_cond_signal(&condAppmodeDisplayFrameReady);
			}
			axFrame.release();
		}

		pthread_cond_wait( &condEXITAPPMODE, &mutexEXITAPPMODE);
		cvDestroyWindow("App Window");
		capture.release();
		axFrame.release();
		Pass->highwaymode=0;
		Pass->citymode=1;
		Pass->mode = 0;
		pthread_cond_signal(&condAppmodeStopSignal);

	}
}
float avgDistance(ThreadParam* Pass, Rect rect)
{
	int Obj_area = rect.width * rect.height;
	//cout << "VEHICLE :: AREA ::" << Obj_area << endl;

	Pass->Obj_distance = (Pass->Ref_area/Obj_area)*Pass->Ref_distance;
	//cout<<"The Vehicle is at "<< Obj_distance <<" meters away from our Car"<<endl;
	//stringstream display;
	//display<<Obj_distance;
	//putText(frame, display.str(), x1, FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,0), 1);
	return Pass->Obj_distance;
}

void displayDistance(int Avg, Mat &displayFrame, Rect finalDistancerect, ThreadParam* Pass)
{
	cout<<"The Vehicle is at "<< Avg <<" meters away from our Car"<<endl;
	stringstream display;
	display<<Avg;
	Point pt((finalDistancerect.x+finalDistancerect.width*3/4),(finalDistancerect.y + (displayFrame.rows*0.4)));
	Point pt1((finalDistancerect.x+finalDistancerect.width),(finalDistancerect.y-15 + (displayFrame.rows*0.4)));
	Point pt2((finalDistancerect.x+finalDistancerect.width*3/4),(finalDistancerect.y-7) + (displayFrame.rows*0.4));

	if(finalDistancerect.y > Pass->m_nHeightROI)
	{
		rectangle(displayFrame,pt,pt1,Scalar(0,0,255),CV_FILLED);
		putText(displayFrame, display.str()+"m", pt2, CV_FONT_HERSHEY_PLAIN, 2, CV_RGB(0,0,255), 3);
	}	
	/*else
	{
		rectangle(displayFrame,pt,pt1,Scalar(0,255,255),CV_FILLED);
		putText(displayFrame, display.str()+"m", pt2, CV_FONT_HERSHEY_PLAIN, 2, CV_RGB(0,0,255), 3);
	}*/
}



void overlapRect(Detectobjectdata &vehicle, ThreadParam* Pass)
{
	bool exitFlag = false;

	/// if there is one rectangle value then no need of avg
	if(vehicle.index == 1){
		cout << "THERE IS ONE OBJECT " << endl;
		int objectDistance = avgDistance(Pass, vehicle.rect[0]);
		vehicle.avg[0] = objectDistance;

	}else{

		for (int i = 0; i < vehicle.index; i++) {

			Rect tmpRect = vehicle.rect[i];
			//	cout << "COMPARING INDEX IS ::" << tmpRect << endl;
			exitFlag = false;
			int Avg=0,count=0;
			int Sum = 0;
			for (int j = i + 1; j < vehicle.index;) {

				/*cout << "REC1 :::"  << tmpRect << endl;
				cout << "RECT2 ::" << vehicle.rect[j] << endl;
				cout << "AREA :: " << (tmpRect & vehicle.rect[j]).area() << endl;*/

				bool intersects = ((vehicle.rect[j] & tmpRect).area() > 0);

				if(intersects){
					exitFlag = true;
					Sum = Sum + avgDistance(Pass, vehicle.rect[j]);
					count++;

					for(int k = j; k < vehicle.index; k++){
						vehicle.rect[k] = vehicle.rect[k + 1];
					}

					vehicle.index--;

				}else{
					j++;
				}
			}

			if(exitFlag == true){
				Avg=Sum/count;
				vehicle.avg[vehicle.indexforAvg++] = Avg;
			}else{
				int objectDistance = avgDistance(Pass, tmpRect);
				vehicle.avg[vehicle.indexforAvg++] = objectDistance;
			}
		}
	}

}
void overlapRect(Detectobjectdata &object)
{
	/*	cout << "BEFORE ::" ;
	for(int i = 0; i < object.index; i++){
		cout <<  object.rect[i] << endl;
	}*/

	for (int i = 0; i < object.index; i++) {

		Rect tmpRect = object.rect[i];
		//	cout << "COMPARING INDEX IS ::" << tmpRect << endl;

		for (int j = i + 1; j < object.index;) {

			/*cout << "REC1 :::"  << tmpRect << endl;
			cout << "RECT2 ::" << vehicle.rect[j] << endl;
			cout << "AREA :: " << (tmpRect & vehicle.rect[j]).area() << endl;*/

			bool intersects = ((object.rect[j] & tmpRect).area() > 0);

			if(intersects){
				for(int k = j; k < object.index; k++){
					object.rect[k] = object.rect[k + 1];
				}
				object.index--;

			}else{
				j++;
			}
		}
	}
	/*	cout << "AFTER ::" ;
	for(int i = 0; i < object.index; i++){
		cout <<  object.rect[i] << endl;
	}*/
}

void pauseFrame(Mat &displayFrame, ThreadParam *Pass)
{
	putText(displayFrame, "PAUSE FRAME" , Point(300, 50), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
	while(Pass->pauseButton){
		pthread_mutex_lock(&prevetDestroyWindow);
		imshow("App Window",displayFrame);
		waitKey(1);
		pthread_mutex_unlock(&prevetDestroyWindow);
	}
}

void *DisplayAppmode(void *globalData)
{
	ThreadParam* Pass = (ThreadParam*) globalData;
	Mat frame;

	double endTime = 0;
	double tmpTimeDiff = 0;
	double sumOfTime = 0;


	int delay = 0;

	Detectobjectdata tmpVehicleDetect;
	Detectobjectdata tmpPedDetect;
	Detectobjectdata tmpLicencePlate;
	Mat displayFrame;

	vector <Rect> filterVehicleRect;
	vector <Rect> filterPedRect;
	char tmpVideoFile[SIZE];
	int vidId = 0;
	Mat tmpPauseFrame;
	char vidFile[SIZE];
	double timeDiff = 0;
	while(1)
	{
		pthread_cond_wait( &condAppmodeDisplayFrameReady, &mutexcondAppmodeDisplayFrameReady);

		while(Pass->mode == 1){

			endTime = cvGetTickCount();
			pthread_mutex_lock( &frameAccessForAppmode );
			Pass->displayFrame = Pass->m_xAppFrame.clone();
			vidId = Pass->lowestVideoFileId;
			pthread_mutex_unlock( &frameAccessForAppmode );

			if(!Pass->displayFrame.data){
				cout << "There is no frame in DisplayAppMode " << endl;
				usleep(WAITTIME);
				continue;
			}
			pthread_mutex_lock( &detectedObjectAccess );
			tmpVehicleDetect = Pass->vehicleDetect;
			tmpPedDetect = Pass->pedDetect;
			tmpLicencePlate = Pass->licencePlateDetect;

			Pass->vehicleDetect.index = 0;
			Pass->vehicleDetect.indexforAvg = 0;
			Pass->pedDetect.index = 0;
			Pass->licencePlateDetect.index = 0;

			pthread_mutex_unlock( &detectedObjectAccess);

			overlapRect(tmpVehicleDetect, Pass);

			overlapRect(tmpPedDetect);

			cout << "BEFORE SIZE ::" << tmpPedDetect.index << endl;
			overlapRect(tmpLicencePlate);
			cout << "AFTER SIZE ::" << tmpPedDetect.index << endl;

			overlayframe(Pass->displayFrame,Pass,tmpVehicleDetect, tmpPedDetect,
					tmpLicencePlate,vidId,tmpPauseFrame,true);


			timeDiff = ((cvGetTickCount()- endTime)/ ((double)cvGetTickFrequency() * MILISECOND));
			cout << "TIMEDIFF IN DISPLAY :: " << timeDiff << endl;



			if(Pass->pauseButton == true){
				if(!tmpPauseFrame.data){
					cout << "pause frame not present" << endl;
					Mat image = imread("BackGround.jpg", 1);
					if(!image.data){
						cout << "BackGround.jpg image not present in DisplayAppMode" << endl;
						/// Release memory
						displayFrame.release();
						filterVehicleRect.clear();
						tmpPauseFrame.release();
						/*tmpVehicleDetect.rect.clear();
						tmpPedDetect.rect.clear();*/
						continue;
					}
					putText(image, "LOADING ....." , Point(100, 100), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
					pthread_mutex_lock(&prevetDestroyWindow);
					imshow("App Window",image);
					waitKey(2000);
					pthread_mutex_unlock(&prevetDestroyWindow);

				}else{
					pauseFrame(tmpPauseFrame, Pass);

				}
			}


			double stTime = cvGetTickCount();

			while(1){

				if((Pass->highwaymodeUserFeedBackStatus == true) ||
						(Pass->pauseButtonUserFeedBackStatus == true) || (Pass->citymodeUserFeedBackStatus == true)||
						(Pass->videoDisplayUserFeedBackStatus == true) ){

					displayUserFeedback(Pass);
					break;
				}else{

					pthread_mutex_lock(&prevetDestroyWindow);
                                	imshow("App Window",Pass->displayFrame);
                               		 waitKey(1);
                                	pthread_mutex_unlock(&prevetDestroyWindow);
				}

				tmpTimeDiff = ((cvGetTickCount()- stTime)/ ((double)cvGetTickFrequency() * MILISECOND));
				tmpTimeDiff += timeDiff;

				if(tmpTimeDiff >= 2000){
					break;
				}
			}

			displayFrame.release();
			filterVehicleRect.clear();
			tmpPauseFrame.release();
		}
		cout << "give signal to appmode to destroy window" << endl;
		/// Signal to app mode to destroy the window
		pthread_cond_signal(&condEXITAPPMODE);
	}
}

void displayframecopy(void *globalData,Mat& axDetectedframe)
{
	ThreadParam* Pass = (ThreadParam*) globalData;
	pthread_mutex_lock( &mutexAppmodeDisplayframeaccess );
	axDetectedframe.copyTo(Pass->m_xAppDisplayFrame);
	pthread_mutex_unlock( &mutexAppmodeDisplayframeaccess);
	if(Pass->mode==1 && Pass->m_bAppmodeavilable)
	{
		pthread_cond_signal(&condAppmodeDisplayFrameReady);
	}
}

void *DetectAppmodeVehicle(void *Data)
{
	Mat axFrameVehicleAnalyse;
	Mat axFrameunresized;

	ThreadParam* Pass = (ThreadParam*) Data;
	Modes modes;

	string sXMLName;
	float nScale;
	int nMinNeighbour;
	int nminimumsize;
	int nObjects;

	double m_nScaleFactor;
	int m_nMinNeighbors;
	int m_nFlags;
	Size m_xMinSize;
	HorusClassifier* m_pVehicle;

	while (1)
	{
		pthread_cond_wait( &condAppmodeVehicleFrameReady, &mutexcondAppmodeVehicleFrameReady );
		pthread_mutex_lock( &frameAccessForAppmode);
		Pass->tmpDisplayFrame = Pass->m_xAppFrame.clone();
		if(Pass->tmpDisplayFrame.empty() ){
			printf(" --(!) No captured frame -- Break!");
			pthread_mutex_unlock( &frameAccessForAppmode );
			continue;
		}

		m_pVehicle = Pass->m_pVehicle;
		m_nScaleFactor  =  m_pVehicle->m_nScaleFactor;
		m_nMinNeighbors =  m_pVehicle->m_nMinNeighbors;
		m_nFlags        =  m_pVehicle->m_nFlags;
		m_xMinSize      =  m_pVehicle->m_xMinSize;

		sXMLName=Pass->sVehicleFilename.c_str();
		nScale=Pass->fVehicleDetectionScale;
		nminimumsize=Pass->nVehicleDetectionminSize;
		nObjects=Pass->m_pVehicle->m_axDetectedObjects.size();
		pthread_mutex_unlock( &frameAccessForAppmode );

		/// Detect Object
		double startTime = cvGetTickCount();
		Pass->detectedRect = m_pVehicle->detect(Pass->tmpDisplayFrame,
				m_nScaleFactor,m_nMinNeighbors, m_nFlags,  m_xMinSize);
		double endTime = cvGetTickCount();

		/// Copy variable for display frame
		pthread_mutex_lock(&detectedObjectAccess);
		//Pass->vehicleDetect.frame = Pass->tmpDisplayFrame.clone();
		/*	Pass->vehicleDetect.startTime = startTime;
		Pass->vehicleDetect.endTime = endTime;*/

		for(auto it : Pass->detectedRect){

			Pass->vehicleDetect.rect[Pass->vehicleDetect.index] = it;
			++Pass->vehicleDetect.index;
			//cout << "RECT :: " << Pass->vehicleDetect.rect[Pass->index++] << endl;
		}

		pthread_mutex_unlock(&detectedObjectAccess);

		logCopyData("vehicle",sXMLName, nScale, 0, nminimumsize, nObjects, ((endTime-startTime)/((double)cvGetTickFrequency()*1000)), 0.0);

	}

}

void *DetectAppmodePedestrian(void *Data)
{
	Mat axFramePdestrainAnalyse;

	Mat axFrameunresized;

	ThreadParam* Pass = (ThreadParam*) Data;
	Modes modes;

	string sXMLName;
	float nScale;
	int nMinNeighbour;
	int nminimumsize;
	int nObjects;
	vector <Rect> detectedRect;

	double m_nScaleFactor;
	int m_nMinNeighbors;
	int m_nFlags;
	Size m_xMinSize;
	Mat tmpDisplayFrame;


	double startTime = 0;
	double endTime = 0;
	HorusClassifier* m_pPedestrian;

	while (1)
	{
		pthread_cond_wait( &condAppmodePedestrianFrameReady, &mutexcondAppmodePedestrianFrameReady );

		pthread_mutex_lock( &frameAccessForAppmode );
		Pass->tmpDisplayFramePed = Pass->m_xAppFrame.clone();
		if(Pass->tmpDisplayFramePed.empty() ){
			printf(" --(!) No captured frame -- Break!");
			pthread_mutex_unlock( &frameAccessForAppmode );
			continue;
		}
		m_pPedestrian = Pass->m_pPedestrian;
		m_nScaleFactor = m_pPedestrian->m_nScaleFactor;
		m_nMinNeighbors = m_pPedestrian->m_nMinNeighbors;
		m_nFlags = m_pPedestrian->m_nFlags;
		m_xMinSize = m_pPedestrian->m_xMinSize;
		sXMLName=Pass->sPedestrianFilename.c_str();
		nScale=Pass->fPedestrianDetectionScale;
		nminimumsize=Pass->nPedestrianDetectionminSize;
		nObjects=Pass->m_pPedestrian->m_axDetectedObjects.size();
		pthread_mutex_unlock( &frameAccessForAppmode );

		/// Detect Object
		double startTime = cvGetTickCount();
		Pass->detectedRectPed = m_pPedestrian->detect(Pass->tmpDisplayFramePed,
				m_nScaleFactor,m_nMinNeighbors, m_nFlags,  m_xMinSize);
		double endTime = cvGetTickCount();

		/// Copy variable for display frame
		pthread_mutex_lock(&detectedObjectAccess);
		for(auto it : Pass->detectedRectPed){
			Pass->pedDetect.rect[Pass->pedDetect.index] = it;
			++Pass->pedDetect.index;
		}

		pthread_mutex_unlock(&detectedObjectAccess);

		logCopyData("pedestrian",sXMLName, nScale, 0, nminimumsize, nObjects, ((endTime-startTime)/((double)cvGetTickFrequency()*1000)), 0.0);
	}
}


void *recordVideos(void *Data)
{
	ThreadParam* Pass = (ThreadParam*) Data;
	int count = 0;
	Recordmode recordMode;
	char vidFile[SIZE];
	char removeVidId[SIZE];
	VideoWriter video;
	int nFrameWidth=g_nFrameWidth;
	int  nFrameHeight=g_nFrameHeight;
	int videoId = 0;
	while(1){

		pthread_cond_wait( &condRecordFrameReady, &mutexRecordFrameReady );

		pthread_mutex_lock( &frameAccessForAppmode);
		Pass->recordFrame = Pass->m_xAppFrame.clone();
		if(Pass->recordFrame.empty() ){
			printf(" --(!) No captured frame -- Break!");
			pthread_mutex_unlock( &frameAccessForAppmode );
			continue;
		}
		pthread_mutex_unlock( &frameAccessForAppmode );
		nFrameHeight=g_nFrameHeight;
		nFrameWidth=g_nFrameWidth;
		if(count == 0){
			cout << "ENTER into REcordvidoes in APP Mode" << endl;
			/// Give count of videos present in recordVideos
			videoId = Pass->getVideoCount();
			/// if there is no video
			if(videoId == 0){
				cout << "there is no video recorded" << endl;
				Pass->videoId = 1;
			}else{
				Pass->videoId = ++videoId;
			}

			sprintf(vidFile , "/home/horusi/recordvideos/%d.avi", Pass->videoId);
			cout << "VideFile ::" << vidFile << endl;
			video.open(vidFile, CV_FOURCC('M','J','P','G'), 30,
					Size(nFrameWidth,nFrameHeight), true);
		}



		video.write(Pass->recordFrame);

		if(count == RECORDMINUTES) {

			if(videoId >= NOOFVIDOES){
				int lowestVidId =  Pass->getVideoCount(true);
				sprintf(removeVidId, "rm -rf /home/horusi/recordvideos/%d.avi", lowestVidId);
				cout << "removeVidId ::" << removeVidId << endl;
				system(removeVidId);
			}
			count = 0;
		}else{
			count++;
		}
	}
}

void *DetectAppmodeLicencePlate(void *Data)
{
	Mat axFramePdestrainAnalyse;
	Mat axFrameunresized;

	ThreadParam* Pass = (ThreadParam*) Data;

	string sXMLName;
	float nScale;
	int nMinNeighbour;
	int nminimumsize;
	int nObjects;
	vector <Rect> detectedRect;

	double m_nScaleFactor;
	int m_nMinNeighbors;
	int m_nFlags;
	Size m_xMinSize;
	Mat tmpDisplayFrame;

	double startTime = 0;
	double endTime = 0;
	HorusClassifier* licencePlate;

	while (1)
	{
		pthread_cond_wait( &condAppmodeLicencePlateFrameReady, &mutexAppmodeLicencePlateFrameReady );

		pthread_mutex_lock( &frameAccessForAppmode );
		Pass->tmpDisplayFrameLic = Pass->m_xAppFrame.clone();
		if(Pass->tmpDisplayFrameLic.empty() ){
			printf(" --(!) No captured frame -- Break!");
			pthread_mutex_unlock( &frameAccessForAppmode );
			continue;
		}
		licencePlate = Pass->m_pLicencePlate;
		m_nScaleFactor = licencePlate->m_nScaleFactor;
		m_nMinNeighbors = licencePlate->m_nMinNeighbors;
		m_nFlags = licencePlate->m_nFlags;
		m_xMinSize = licencePlate->m_xMinSize;
		nScale=Pass->fLicencePlateDetectionScale;
		pthread_mutex_unlock( &frameAccessForAppmode );

		/// Detect object
		startTime = cvGetTickCount();
		Pass->detectedRectLic = licencePlate->detect(Pass->tmpDisplayFrameLic,
				m_nScaleFactor,m_nMinNeighbors, m_nFlags,  m_xMinSize);
		endTime = cvGetTickCount();

		/// Copy variable for display frame
		pthread_mutex_lock(&detectedObjectAccess);
		for(auto it : Pass->detectedRectLic){
			Pass->licencePlateDetect.rect[Pass->licencePlateDetect.index] = it;
			++Pass->licencePlateDetect.index;
		}

		pthread_mutex_unlock(&detectedObjectAccess);
		//logCopyData("pedestrian",sXMLName, nScale, 0, nminimumsize, nObjects, ((endTime-startTime)/((double)cvGetTickFrequency()*1000)), 0.0);
	}
}


void Sthread :: initializeThread(ThreadParam &globalData)
{


	int nThreadStatus;

	if(globalData.keyPadAccessFlag == true){
		cout << "KEYPAD FLAG PRESENT " << endl;

		/// create the thread
		nThreadStatus = pthread_create(&globalData.keyReaderThread , NULL, keyReader, (void *)&globalData);
		if(nThreadStatus)
		{
			cout << "pthread_create is not create" << endl;
			exit(0);
		}
	}else{
		cout << "KEYPAD FLAG NOT PRESENT " << endl;
	}

	/// create the thread
	nThreadStatus = pthread_create(&globalData.wifiStatusThread , NULL, wifiStatus, (void *)&globalData);
	if(nThreadStatus)
	{
		cout << "pthread_create is not create" << endl;
		exit(0);
	}

	nThreadStatus = pthread_create(&globalData.DisplayThread, NULL, displayRecordedImage, (void *)&globalData);
	if(nThreadStatus)
	{
		cout << "pthread_create is not create" << endl;
		exit(0);
	}

	nThreadStatus=pthread_create( &globalData.threadCapture, NULL, &captureAppmodeFrames,(void *)&globalData);
	if(nThreadStatus)
	{
		cout << "Capture App Mode thread Not started" << endl;
	}

	nThreadStatus=pthread_create( &globalData.threadVehicleDetect, NULL, &DetectAppmodeVehicle, (void *)&globalData);

	if(nThreadStatus)
	{
		cout << "App Mode Vehicle detection thread Not started" << endl;
	}


	nThreadStatus=pthread_create( &globalData.threadPedestrianDetect, NULL, &DetectAppmodePedestrian, (void *)&globalData);
	if(nThreadStatus)
	{
		cout << "App Mode Pedestrian detection thread Not started" << endl;
	}

	nThreadStatus=pthread_create( &globalData.licencePlate, NULL, &DetectAppmodeLicencePlate, (void *)&globalData);
	if(nThreadStatus)
	{
		cout << "Logging thread Not started" << endl;
	}


	nThreadStatus=pthread_create( &globalData.threadDisplay, NULL, &DisplayAppmode, (void *)&globalData);

	if(nThreadStatus)
	{
		cout << "App Mode Display thread Not started" << endl;
	}

	nThreadStatus = pthread_create( &globalData.threadLogging, NULL, &logAppMode, (void *)&globalData);
	if(nThreadStatus)
	{
		cout << "Logging thread Not started" << endl;
	}

	nThreadStatus=pthread_create( &globalData.recordVideo, NULL, &recordVideos, (void *)&globalData);
	if(nThreadStatus)
	{
		cout << "Logging thread Not started" << endl;
	}


}

/*
 * release the thread
 */

void Sthread :: release( ThreadParam &globalData)
{


}

