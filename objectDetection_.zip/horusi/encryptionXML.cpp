#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

#define SIZE 1024

void Encryption(char* inputXML)
{
	ifstream infile;

	ofstream outfile;

	//cout << inputXML << endl;

	// Input XMl
	infile.open (inputXML);	//opens the file to be encrypted
	
	if(!infile.is_open()){
		cout << "inputFile of the xml is not open" << endl;
		return ; 
	}

	/// Set Password
	string password = "1234";

	/// Create Encrypted file for input xml
	char outfileloc[SIZE];

	if(strstr(inputXML, "pedestrian")){

	 strcpy(outfileloc, "encryptedPedestrin.txt");

	}else if(strstr(inputXML, "car")){

	 strcpy(outfileloc, "encryptedCar.txt");
	
	}else if(strstr(inputXML, "HogPedestrianClassifier")){
	
	 strcpy(outfileloc, "encryptedHogPedestrianClassifier.txt");	

	}

	//opens the output file
	outfile.open (outfileloc); 

	int  i = 0;
	while (!infile.eof())	//while not the end of the file
	{
		for (i = 0 ;i < 4 ; i++)	//for loop cycles through the positions of the password array until end of file is reached
		{
			if(infile.eof()){
				cout << "END OF THE FILE " << endl;
				break;
			}

			char name;	//character from file to be encrypted
			infile.get(name);	//gets character from the file
			
			if(infile.eof()){
				cout << "END OF THE FILE " << endl;
				break;
			}


			//cout << "BEFORE ::" <<  name << endl;
			name = name + password[i];	//adds the part of the password array
			name = name - password[0];	//subtracts the first letter of the password (keeps characters printable)
			//cout << "AFTER ::" <<  name << endl;	
			outfile << name;	//prints that character to the output file
		}
		i = 0;
	}

	infile.close();	 //closes the original file
	outfile.close();	//closes the file encryption

	//cout << "\n\n";	//aesthetic purposes
}

int main(int argc, char **argv)
{
	if(argc != 2){
	  cout << "USAGE :: EXE INPUTXML_FILE" << endl;
	  return 0;
	}
	
	Encryption(argv[1]);
	//Decryption();
return 0;
}

