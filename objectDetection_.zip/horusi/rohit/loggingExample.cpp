#include<stdio.h>
#include<iostream>
#include<fstream>

using namespace std;	

int main()
{
	double	timeEnd=5.0;	
      FILE *fptr;
      fptr = fopen("log.txt", "w");
      fprintf(fptr, "time end = %f", timeEnd);
      fclose(fptr);
}

