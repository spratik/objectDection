#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h> 
#include <pthread.h>

#define NUM_THREADS 3

int ctr=1;

struct thread_data
{
	char *message;
	int interval;
        pthread_cond_t *condTimerSignal;
        pthread_mutex_t *mutexcondTimerSignal;
};


void *clock1(void *threadarg)
{
   while(1)
	{
	struct thread_data *my_data;
	my_data = (struct thread_data *) threadarg;
	pthread_cond_wait(my_data->condTimerSignal,my_data->mutexcondTimerSignal);
	printf("   %s",my_data->message);
	}
}

int main()
{
	time_t start = time(NULL);
	char str[100];
	char str1[100];
	int x;
	int y;
	int timerFlag=1;
	int rc;
	int i=0;
	printf("Enter how often to display time in seconds \n");
	scanf("%d",&timerFlag);
	printf("Enter the first String and the first time period in seconds \n");
	scanf("%s %d",str,&x);
	printf("Enter the second String and the seocnd time period in seconds \n");
	scanf("%s %d",str1,&y);

	pthread_t threads[NUM_THREADS];
	struct thread_data td[NUM_THREADS];
	pthread_cond_t condDisplaywait[NUM_THREADS] = {PTHREAD_COND_INITIALIZER,PTHREAD_COND_INITIALIZER,PTHREAD_COND_INITIALIZER};
	pthread_mutex_t mutexcondDisplaywait[NUM_THREADS] = {PTHREAD_MUTEX_INITIALIZER,PTHREAD_MUTEX_INITIALIZER,PTHREAD_MUTEX_INITIALIZER};
 

      	td[0].message = str;
	td[0].interval=x;
        td[0].condTimerSignal=&condDisplaywait[0];
        td[0].mutexcondTimerSignal=&mutexcondDisplaywait[0];
     	rc = pthread_create(&threads[0], NULL,clock1, (void *)&td[0]);

        td[1].message = str1;
        td[1].interval=y;
        td[1].condTimerSignal=&condDisplaywait[1];
        td[1].mutexcondTimerSignal=&mutexcondDisplaywait[1];
        rc = pthread_create(&threads[1], NULL,clock1, (void *)&td[1]);

	char output[50];
	snprintf(output, 50, "%ld", time(NULL));

	td[2].message = output;
        td[2].interval=timerFlag;
        td[2].condTimerSignal=&condDisplaywait[2];
        td[2].mutexcondTimerSignal=&mutexcondDisplaywait[2];
        rc = pthread_create(&threads[2], NULL,clock1, (void *)&td[2]);

	while(1)
	{
	      printf("\n");
       	      if(ctr%td[0].interval==0)
		{
			pthread_cond_signal(&condDisplaywait[0]);
		}

              if(ctr%td[1].interval==0)
                {
                        pthread_cond_signal(&condDisplaywait[1]);
                }
		if(ctr%timerFlag==0)
		{
			pthread_cond_signal(&condDisplaywait[2]);
		}

	usleep(1000000);
        ctr++;
	}
	return 0;
}
