#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h> 
#include<string.h>

#define NUM_THREADS 2

struct thread_data
{
	char message[100];
	int interval;
};

void *printData(void *threadarg)
{
        int count=0;
        thread_data* my_data = (thread_data*) threadarg;

	my_data = (struct thread_data *) threadarg;

        while(1)
	{
        	if((count%(my_data->interval))==0)
		{
			printf("%s",my_data->message);
		}
                count++;
		usleep(10000);
	}
}


int main()
{
	time_t start = time(NULL);
	char str[100];
	char str1[100];
	int x;
	int y;
	int timerFlag;
	printf("Enter the first String and the first time period in seconds \n");
	scanf("%s",str);

	pthread_t threads[NUM_THREADS];
	struct thread_data td[NUM_THREADS];

        strcpy(td[0].message,"sdfsdsd");
        td[0].interval=2;
        int returnValue=pthread_create(&threads[0], NULL, printData,(void *)&td[0]);

        pthread_join(threads[0],NULL);

	return 0;
}
