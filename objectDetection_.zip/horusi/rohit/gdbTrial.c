int main(int argc, char **argv)
{
	int i=argc*2;
	i++;
	return i;
}
