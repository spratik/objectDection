#include "opencv2/objdetect.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace std;
using namespace cv;

void detect( Mat& frame, CascadeClassifier& cascade,std::vector<Rect>& detected_objects,double scale,int size)
{


    cascade.detectMultiScale( frame, detected_objects,
        scale, 3, 0
        |CASCADE_SCALE_IMAGE,
        Size(size, size) );
}


void draw( Mat& frame, std::vector<Rect>& detected_objects)
{
     double start = (double)cvGetTickCount();
     for( size_t i = 0; i < detected_objects.size(); i++ )
	{
                        Point x1(detected_objects[i].x,detected_objects[i].y);
			Point x4((detected_objects[i].x+detected_objects[i].width),(detected_objects[i].y+detected_objects[i].height));
			rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);
        }
     double end=cvGetTickCount()-start;
}


string cascadeName;
string nestedCascadeName;
Mat frame;


int main( int argc, const char** argv )
{
    VideoCapture capture;
    capture.open("/home/horusi/record/recordvideos/2.avi");
    CascadeClassifier vehicle;
    vector<Rect> vehicle_objects;

    double start;
    double meantimedetectvehicle=0;
    double meantimedetectpedestrian=0;

    double meantimedrawvehicle=0;
    double meantimedrawpedestrian=0;

    double scale;
    int count=0;
    int size=0;
    CascadeClassifier pedestrian;
    vector<Rect> pedestrian_objects;

    String vehiclecascadexml ="car.xml";
    vehicle.load(vehiclecascadexml);

    String pedestriancascadexml ="pedestrian.xml";
    pedestrian.load(pedestriancascadexml);


    if( capture.isOpened() )
    {
        cout << "Video capturing has been started ...\n" << endl;

        for(;;)
        {
            count++;
            capture >> frame;
            if( frame.empty() )
                break;
            Mat frame1 = frame.clone();
            start=cvGetTickCount();
            scale=1.1;
            size=24;
            detect( frame1, vehicle,vehicle_objects,scale,size);
            meantimedetectvehicle+=(cvGetTickCount()-start)/((double)cvGetTickFrequency()*1000.);

            start=cvGetTickCount();
            draw(frame1,vehicle_objects);
            meantimedrawvehicle+=(cvGetTickCount()-start)/((double)cvGetTickFrequency()*1000.);

            Mat frame2 = frame.clone();

            start=cvGetTickCount();
            scale=1.03;
            size=16;
            detect( frame2, pedestrian,pedestrian_objects,scale,size);
            meantimedetectpedestrian+=(cvGetTickCount()-start)/((double)cvGetTickFrequency()*1000.);

            start=cvGetTickCount();
            draw(frame1,pedestrian_objects);
            meantimedrawpedestrian+=(cvGetTickCount()-start)/((double)cvGetTickFrequency()*1000.);

            imshow( "result", frame1);
            int c = waitKey(1);
            if( c == 27 || c == 'q' || c == 'Q' )
                break;
        }
    }
    cout<<"Frame Read : "<<count<<"\n"<<endl;
    cout<<"Detection time of vehicle = "<<meantimedetectvehicle/count<<"\n"<<endl;
    cout<<"Draw time of vehicle= "<<meantimedrawvehicle/count<<"\n"<<endl;
    cout<<"Detection time of pedestrian = "<<meantimedetectpedestrian/count<<"\n"<<endl;
    cout<<"Draw time of pdestrian = "<<meantimedrawpedestrian/count<<"\n"<<endl;

    return 0;
}



