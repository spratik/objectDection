#!/bin/bash

cd /home/horusi/insuri/

ulimit -c unlimited

datadirectory="/home/horusi/insuri/data"
if [ ! -d "$datadirectory" ]
then
	sudo mkdir -p /home/horusi/insuri/data
	sudo chmod -R 777 /home/horusi/insuri/data
else
	echo "Data folder found"
fi

coredumpdirectory="/home/horusi/insuri/data/coredumps"
if [ ! -d "$coredumpdirectory" ]
then
	sudo mkdir -p /home/horusi/insuri/data/coredumps
	sudo chmod -R 777 /home/horusi/insuri/data/coredumps
else
        echo "Core dump folder found"
fi

sudo ./coredump.sh

logdirectory="/home/horusi/insuri/data/log"
if [ ! -d "$logdirectory" ]
then
	sudo mkdir -p /home/horusi/insuri/data/log
	sudo chmod -R 777 /home/horusi/insuri/data/log
else
        echo "Log folder found"
fi


file="/home/horusi/insuri/updateflag"
if [ -f "$file" ]
then
	echo "Flag found."
        echo "Updating software"
        sudo python update.py /home/horusi/cache/ /home/horusi/insuri/
else
	echo "flag not found."
        echo "Software up to date"
fi

sudo rm -f /home/horusi/app
sudo rm -f /home/horusi/back
switchingappfile="/home/horusi/app"

while true
do
if [ -f "$switchingappfile" ]
then
        echo "MANAGE Mode switching"
        sudo xinit ./Horusi -mpsflag -bootwithbackup
        sudo rm -f /home/horusi/app
else
        echo "APP Mode Switching...."
        sudo xinit ./Horusi -mpsflag
        sudo rm -f /home/horusi/back
fi
done
