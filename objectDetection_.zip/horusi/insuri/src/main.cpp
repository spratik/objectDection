
#include "horusi.h"
#include "optionparser.h"
#include "horusclassifier.h"
#include "modes.h"
#include "sthread.h"
#include <fstream>
#include <string>
using namespace cv;
using namespace cv::ml;
using namespace std;

#define INF 10000
#define RECORDMIN 5
#define MINNEIGHBOURFORPEDSTRION 5
#define MINNEIGHBOURFORVEHICAL 7

bool g_bMPSFlag;
int g_nBackupMode;
int g_nBackupModeBoot;
string g_sTimeStamp;
Rect a;


void guiFunctionCall(int event, int x, int y, int flags, void* Data)
{
	ThreadParam* Pass = (ThreadParam*) Data;
	if  ( event == EVENT_LBUTTONDOWN )
	{
		int nFirstRectangleEndx=Pass->m_nScreenWidth/3;
		int nFirstRectangleEndy=Pass->m_nScreenHeight/2;

		int nSecondRectangleEndx=(Pass->m_nScreenWidth/3)+nFirstRectangleEndx;
		int nSecondRectangleEndy=(Pass->m_nScreenHeight/2);

		int nThirdRectangleEndx=(Pass->m_nScreenWidth/3)+nSecondRectangleEndx;
		int nThirdRectangleEndy=Pass->m_nScreenHeight/2;
		Mat frame=imread("BackGround.jpg");
		if(x<nFirstRectangleEndx && x<nSecondRectangleEndx && y<nFirstRectangleEndy)
		{
			Pass->mode=1;
			cout<<"mode 1 switched"<<endl;
		}

		if(x>nFirstRectangleEndx && x<nSecondRectangleEndx && y<nFirstRectangleEndy)
		{
			Pass->mode=2;
			cout<<"mode 2 switched"<<endl;
		}

		if(x>nSecondRectangleEndx && x<Pass->m_nScreenWidth && y<nFirstRectangleEndy)
		{
			Pass->mode=3;
			cout<<"mode 3 switched"<<endl;
		}

		if(x<nFirstRectangleEndx && x<nSecondRectangleEndx && y>nFirstRectangleEndy)
		{
			Pass->mode=4;
			cout<<"mode 4 switched"<<endl;

		}
		if(x>nFirstRectangleEndx && x<nSecondRectangleEndx && y>nFirstRectangleEndy)
		{
			Pass->mode=5;
			cout<<"mode 5 switched"<<endl;

		}

		if(x>nSecondRectangleEndx && x<Pass->m_nScreenWidth && y>nFirstRectangleEndy)
		{
			Pass->mode=6;
			cout<<"mode 6 switched"<<endl;

		}
	}
}



void highguiDesign(Mat &guiBackground,int nScreenWidth, int nScreenHeight)
{

	int nFirstRectangleEndx=nScreenWidth/3;
	int nFirstRectangleEndy=nScreenHeight/2;

	int nSecondRectangleEndx=(nScreenWidth/3)+nFirstRectangleEndx;
	int nSecondRectangleEndy=(nScreenHeight/2);

	int nThirdRectangleEndx=(nScreenWidth/3)+nSecondRectangleEndx;
	int nThirdRectangleEndy=nScreenHeight/2;

	cv::Mat roi = guiBackground(cv::Rect(0, 0, nFirstRectangleEndx ,nFirstRectangleEndy));
	Mat overlay;
	double alpha = 0.6;
	guiBackground.copyTo(overlay);

	int thickness=10;
	rectangle( guiBackground, Point( 0+thickness, 0+thickness ), Point(nFirstRectangleEndx-thickness ,nFirstRectangleEndy-thickness), Scalar( 255, 0, 0 ), thickness, 4 );
	rectangle( guiBackground, Point(nFirstRectangleEndx+thickness , 0+thickness ), Point(nSecondRectangleEndx-thickness ,nSecondRectangleEndy-thickness), Scalar( 255, 0, 0 ),thickness , 4 );
	rectangle( guiBackground, Point( nSecondRectangleEndx+thickness, 0+thickness ), Point(nThirdRectangleEndx-thickness ,nThirdRectangleEndy-thickness), Scalar( 255, 0, 0 ), thickness, 4 );

	rectangle( guiBackground, Point(0+thickness,nFirstRectangleEndy+thickness), Point(nFirstRectangleEndx-thickness ,nScreenHeight-thickness), Scalar( 255, 0, 0 ), thickness, 4 );
	rectangle( guiBackground, Point(nFirstRectangleEndx+thickness , nSecondRectangleEndy+thickness ), Point(nSecondRectangleEndx-thickness,nScreenHeight-thickness), Scalar( 255, 0, 0 ), thickness, 4 );
	rectangle( guiBackground, Point( nSecondRectangleEndx+thickness, nThirdRectangleEndy+thickness ), Point(nThirdRectangleEndx-thickness ,nScreenHeight-thickness), Scalar( 255, 0, 0 ), thickness, 4 );

	cv::addWeighted(overlay, alpha, guiBackground, 1 - alpha, 0, guiBackground);

	putText(guiBackground, "APP", Point((nFirstRectangleEndx/3),nFirstRectangleEndy/2), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	putText(guiBackground, "DEMO", Point((nFirstRectangleEndx+(nFirstRectangleEndx/4)), nFirstRectangleEndy/2), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	putText(guiBackground, "PLAYBACK", Point((nSecondRectangleEndx+(nFirstRectangleEndx/12)),nFirstRectangleEndy/2), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	putText(guiBackground, "RECORD", Point((nFirstRectangleEndx/5),((nFirstRectangleEndy/2)+nFirstRectangleEndy)), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	putText(guiBackground, "SETTINGS", Point((nFirstRectangleEndx+(nFirstRectangleEndx/8.8)),((nFirstRectangleEndy/2)+nFirstRectangleEndy)), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	putText(guiBackground, "MANAGE", Point((nSecondRectangleEndx+(nFirstRectangleEndx/5.8)),((nFirstRectangleEndy/2)+nFirstRectangleEndy)), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);

}

void  highguiDesignForCloud(Mat &guiBackground,int nScreenWidth, int nScreenHeight,String version)
{
	int nFirstRectangleEndx=nScreenWidth/3;
	int nFirstRectangleEndy=nScreenHeight/2;
	int nSecondRectangleEndx=(nScreenWidth/3)+nFirstRectangleEndx;
	int nSecondRectangleEndy=(nScreenHeight/2);

	int nThirdRectangleEndx=(nScreenWidth/3)+nSecondRectangleEndx;
	int nThirdRectangleEndy=nScreenHeight/2;

	//	Mat roi = guiBackground(cv::Rect(0, 0, nFirstRectangleEndx ,nFirstRectangleEndy));
	Mat overlay;

	double alpha = 0.6;
	guiBackground.copyTo(overlay);

	int thickness=10;

	rectangle( guiBackground, Point( 0+thickness, 0+thickness ), Point(nFirstRectangleEndx-thickness ,nFirstRectangleEndy-thickness), Scalar( 255, 0, 0 ), thickness, 4 );
	rectangle( guiBackground, Point(nFirstRectangleEndx+thickness , 0+thickness ), Point(nSecondRectangleEndx-thickness ,nSecondRectangleEndy-thickness), Scalar( 255, 0, 0 ),thickness , 4 );
	rectangle( guiBackground, Point( nSecondRectangleEndx+thickness, 0+thickness ), Point(nThirdRectangleEndx-thickness ,nThirdRectangleEndy-thickness), Scalar( 255, 0, 0 ), thickness, 4 );

	rectangle( guiBackground, Point(0+thickness,nFirstRectangleEndy+thickness), Point(nFirstRectangleEndx-thickness ,nScreenHeight-thickness), Scalar( 255, 0, 0 ), thickness, 4 );
	if(g_bMPSFlag==1)
	{
		rectangle( guiBackground, Point(nFirstRectangleEndx+thickness , nSecondRectangleEndy+thickness ), Point(nSecondRectangleEndx-thickness,nScreenHeight-thickness), Scalar( 255, 0, 0 ), thickness, 4 );
		rectangle( guiBackground, Point(nSecondRectangleEndx+thickness , nFirstRectangleEndy+thickness ), Point(nThirdRectangleEndx-thickness,nScreenHeight-thickness),Scalar( 255, 0, 0 ), thickness, 4 );

	}
	else
	{
		rectangle( guiBackground, Point(nFirstRectangleEndx+thickness , nSecondRectangleEndy+thickness ), Point(nSecondRectangleEndx-thickness,nScreenHeight-thickness), Scalar( 255, 0, 0 ), thickness, 4 );
	}
	cv::addWeighted(overlay, alpha, guiBackground, 1 - alpha, 0, guiBackground);

	putText(guiBackground, "UPLOAD", Point((nFirstRectangleEndx/5.8),nFirstRectangleEndy/3), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	putText(guiBackground, "VIDEO", Point(((nFirstRectangleEndx/4)),nFirstRectangleEndy/1.5), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	putText(guiBackground, "UPDATE", Point((nFirstRectangleEndx+(nFirstRectangleEndx/5.8)),nFirstRectangleEndy/3), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	putText(guiBackground, "SOFTWARE", Point((nFirstRectangleEndx+(nFirstRectangleEndx/14)),nFirstRectangleEndy/1.5), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	putText(guiBackground, "WIFI", Point((nSecondRectangleEndx+((nFirstRectangleEndx/3.))),nFirstRectangleEndy/3), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	putText(guiBackground, "STATUS", Point((nSecondRectangleEndx+((nFirstRectangleEndx/5.8))),nFirstRectangleEndy/1.5), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	if(g_bMPSFlag!=1)
	{
		putText(guiBackground, "EXIT ", Point((nFirstRectangleEndx+(nFirstRectangleEndx/4)),((nFirstRectangleEndy/1.8)+nFirstRectangleEndy)), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	}
	else
	{
		putText(guiBackground, "EXIT ", Point((nSecondRectangleEndx+(nFirstRectangleEndx/4)),((nFirstRectangleEndy/1.8)+nFirstRectangleEndy)),  FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
		putText(guiBackground, "BACKUP ", Point((nFirstRectangleEndx+(nFirstRectangleEndx/5.8)),((nFirstRectangleEndy/1.8)+nFirstRectangleEndy)), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);

	}
	putText(guiBackground, "DELETE", Point((nFirstRectangleEndx/5.8),((nFirstRectangleEndy/3)+nFirstRectangleEndy)), FONT_HERSHEY_PLAIN,2.5 , CV_RGB(0,0,0), 3);
	putText(guiBackground, "ALL", Point((nFirstRectangleEndx/3),((nFirstRectangleEndy/1.7)+nFirstRectangleEndy)), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);
	putText(guiBackground, "VIDEOS", Point((nFirstRectangleEndx/5.8),((nFirstRectangleEndy/1.2)+nFirstRectangleEndy)), FONT_HERSHEY_PLAIN, 2.5, CV_RGB(0,0,0), 3);


	putText(guiBackground , version, Point((nFirstRectangleEndx),(nScreenHeight-10)), FONT_HERSHEY_PLAIN, 2, CV_RGB(0,255,0), 3);

}

int main( int argc, char *argv[] )
{


	ThreadParam tp;
	Mat axVybe;
	Mat axVybeImageread=imread("appsplash.png"); //(tp.m_nScreenWidth, tp.m_nScreenHeight, CV_8UC3, Scalar(0,0,0));
	resize(axVybeImageread, axVybe, Size(720, 480), 0, 0, INTER_CUBIC); // resize to 1024x768 resolution
	namedWindow("Gui Window",WINDOW_NORMAL);
	cvSetWindowProperty("Gui Window", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
	setMouseCallback("Gui Window", guiFunctionCall, &tp);
	imshow("Gui Window",axVybe);
	waitKey(500);

	int nResponsescreenblank;
	nResponsescreenblank=system("./offpowersaver.sh");

	if(nResponsescreenblank==0)
	{
		cout<<"Power saver settings turned off"<<endl;;
	}
	else
	{
		cout<<"Unable to switch off power saver"<<endl;;
	}



	const String parameters =

			"{help                      |     | }"
			"{pedestrianclassifier      |     | }"
			"{vehicleclassifier         |     | }"
			"{videofile                 |     | }"
			"{showhistogramcomparision  |     | }"
			"{showboth                  |     | }"
			"{showroielemination        |     | }"
			"{heightofroi               |     | }"
			"{invertvideo               |     | }"
			"{pedestrianscaling         |     | }"
			"{vehiclescaling            |     | }"
			"{vehicleminimumsize        |     | }"
			"{pedestrianminimumsize     |     | }"
			"{pedestrianclassification  |     | }"
			"{recordmodetime            |     | }"
			"{raspberry                 |     | }"
			"{keypad                    |     | }"
			"{displayvideo              |     | }"
			"{mpsflag                   |     | }"
			"{bootwithbackup            |     | }"
			;

	HorusClassifier pedestrian, vehicle, licenceNumPlate;

	tp.setDefultValue();

	tp.m_pPedestrian = &pedestrian;
	tp.m_pVehicle = &vehicle;
	tp.m_pLicencePlate = &licenceNumPlate;

	int displayShapForCar = 1;
	int displayShapForVehical = 2;

	OptionParse parseArg;

	parseArg.passArgument(argc, argv, parameters, tp);

	cout<<"Horus-i analyzing (f)" << tp.m_sVideoFilename << endl;
	cout<<"Using classifiers: " << endl;
	cout<<"\t(p)" << tp.sPedestrianFilename <<" with scaling(s):" << tp.fPedestrianDetectionScale<<" and sizing(w) " << tp.nPedestrianDetectionminSize<<endl;
	cout<< "\t(v)" << tp.sVehicleFilename <<" with scaling(s):" <<tp.fVehicleDetectionScale<<" and sizing(x) " <<tp.nVehicleDetectionminSize <<endl;
	cout << "RECORD MIN :: " << tp.recordmin << endl;
	cout<<"Region of Interest: " <<endl;
	cout<<"Mps Flag : "<<g_bMPSFlag<<endl;
	cout<<"Backup Flag : "<<g_nBackupModeBoot<<endl;

	pedestrian.loadXml(tp.sPedestrianFilename, tp.fPedestrianDetectionScale,
			tp.nPedestrianDetectionminSize, displayShapForCar,  MINNEIGHBOURFORPEDSTRION);


	vehicle.loadXml(tp.sVehicleFilename, tp.fVehicleDetectionScale,
			tp.nVehicleDetectionminSize, displayShapForVehical,  MINNEIGHBOURFORVEHICAL);

	licenceNumPlate.loadXml(tp.m_sLicencePlateFileName, tp.fLicencePlateDetectionScale);

	tp.initHOGFeature();
	tp.processHOGFeature();

	ifstream pFilepointer;
	pFilepointer.open("horusiversioncheck");
	if(pFilepointer)
	{
		pFilepointer >> tp.sSoftwareVersion;
		cout<< tp.sSoftwareVersion<<endl;
	}
	else
	{
		cout<<"file Not Found"<<endl;

	}
	pFilepointer.close();

	pFilepointer.open("/home/horusi/backupmodeboot");

	if(!pFilepointer)
		g_nBackupMode=0;
	else
		g_nBackupMode=1;
	pFilepointer.close();

	tp.m_xGuiBackgroundunresized=imread("mainMenuBackground.jpg"); //(tp.m_nScreenWidth, tp.m_nScreenHeight, CV_8UC3, Scalar(0,0,0));
	resize(tp.m_xGuiBackgroundunresized, tp.m_xGuiBackground, Size(720, 480), 0, 0, INTER_CUBIC); // resize to 1024x768 resolution
	tp.m_nScreenHeight=tp.m_xGuiBackground.rows;
	tp.m_nScreenWidth=tp.m_xGuiBackground.cols;
	highguiDesign(tp.m_xGuiBackground,tp.m_nScreenWidth,tp.m_nScreenHeight);
	tp.m_sRecordedfile="Recorded.avi";


	tp.m_xGuiUpdateBackgroundUnresized = imread("mainMenuBackground.jpg");
	resize(tp.m_xGuiUpdateBackgroundUnresized, tp.m_xGuiUpdateBackground, Size(720, 480), 0, 0, INTER_CUBIC);
	tp.m_nScreenHeight = tp.m_xGuiUpdateBackground.rows;
	tp.m_nScreenWidth = tp.m_xGuiUpdateBackground.cols;
	highguiDesignForCloud(tp.m_xGuiUpdateBackground,tp.m_nScreenWidth,tp.m_nScreenHeight,tp.sSoftwareVersion);

	Sthread sthread;

	sthread.initializeThread(tp);

	Modes mod;

	mod.processMode(tp);

	sthread.release(tp);

	return 0;
}

