/*
 * Recordmode.cpp
 *
 *  Created on: 16-May-2017
 *      Author: pratik
 */


#include "Recordmode.h"
#include <unistd.h>
#include "overlay.h"

#define BUFFERSIZE 100

#define RECORDMINUTES  1800

#define NOOFVIDOES 61

#define MAXVIDOESCOUNT 1000

#define SIZE 2048


void RecordCallBackWindow(int event, int x, int y, int flags, void* userdata)
{
	ThreadParam* PassedArguments=(ThreadParam *)userdata;


	if  ( event == EVENT_LBUTTONDOWN )
	{

		PassedArguments->mode=0;
	}


}

int Recordmode :: getVideoId()
{
	FILE *in;
	char buff[SIZE];

	char cmd[SIZE]= "ls /home/horusi/recordvideos/ -v";

	if(!(in = popen(cmd, "r"))){
		cout << "popen is fail in getVideoId" << endl;
		exit(0);
	}

	string videoCountStr;

	while(fgets(buff, sizeof(buff), in)!=NULL){}

	cout << buff<< endl;
	pclose(in);

	for(int i = 0; buff[i] != '\0'; i++){

		if(buff[i] != '.'){
			videoCountStr += buff[i] ;
		}else{
			break;
		}
	}

	return (atoi(videoCountStr.c_str()) + 1);
}

int Recordmode :: getVideoCount()
{

	FILE *in;
	char buff[SIZE];

	char cmd[SIZE]= "ls  /home/horusi/recordvideos/ -l | wc -l";

	if(!(in = popen(cmd, "r"))){
		cout << "popen is fail in getVideoId" << endl;
		exit(0);
	}

	string videoCountStr;

	while(fgets(buff, sizeof(buff), in)!=NULL){}

	cout << "VIDECOUNT IN GETVIDEOCOUNT " << buff<< endl;
	pclose(in);

	return (atoi(buff));

}

void Recordmode :: recordMode(void * Data)
{
	//cout << "ENTER INTo RECORD MODE " << endl;

	ThreadParam* Pass = (ThreadParam*) Data;

	/// Give count of videos present in recordVideos
	int videoCount = getVideoCount();
	/// if there is no video
	if(videoCount == 1){
		cout << "there is no video recorded" << endl;
		Pass->videoId = 1;
	}else{
		/// Give last video file recorded
		Pass->videoId = getVideoId();
	}



	cout << "VIDOEID :: " << Pass->videoId << endl;

	cout << "VIDEOCOUNT :: " << videoCount << endl;

	Mat  tmpImage;

	double startTime = 0;
	double endTime = 0;

	/// display image like memory is full when videoCount reach to predefined videosCount
	if(videoCount >= NOOFVIDOES){

		cout <<"MEMORY IS FULL" << endl;
		Mat img = imread("BackGround.jpg");
		namedWindow("RECORD MODE", WINDOW_NORMAL);
		cvSetWindowProperty("RECORD MODE", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
		putText(img, "Record Limit reached !", Point(100, 100),  FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
		putText(img, "Please delete some videos and try again", Point(100, 160),  FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);

		imshow("RECORD MODE",img);
		waitKey(5000);
		cvDestroyWindow("RECORD MODE");
		img.release();
		Pass->mode = 0;
		return;
	}


	Mat frame;
	overlayvariables overlaydata;
	Mat axBlankBackground;
	Mat axErrorWindow;
	overlaydata.BackgroundImage.copyTo(axBlankBackground);
	putText(axBlankBackground, "Loading ", Point(((Pass->m_nScreenWidth/2)-75), Pass->m_nScreenHeight/2.5), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);

	namedWindow("Record Window",WINDOW_NORMAL);
	cvSetWindowProperty("Record Window", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
	setMouseCallback("Record Window",RecordCallBackWindow, Pass);

	imshow("Record Window",axBlankBackground);
	waitKey(1);
	overlaydata.BackgroundImage.copyTo(axErrorWindow);

	//	pthread_mutex_unlock(&Pass->recordSignalMutex);

	pthread_cond_signal(&Pass->recordCond);

	while(Pass->videoId < MAXVIDOESCOUNT){

		/// Give count of videos present in recordVideos
		int videoCount = getVideoCount();
		/// if there is no video
		if(videoCount == 1){
			cout << "there is no video recorded" << endl;
			Pass->videoId = 1;
		}else{
			/// Give last video file recorded
			Pass->videoId = getVideoId();
		}


		/// display image like memory is full when videoCount reach to predefined videosCount
		if(videoCount >= NOOFVIDOES){

			cout <<"MEMORY IS FULL" << endl;
			Mat img = imread("BackGround.jpg");
			namedWindow("RECORD MODE", WINDOW_NORMAL);
			cvSetWindowProperty("RECORD MODE", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
			putText(img, "Memory is full. Please delete some videos", Point(100, 100),  FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
			imshow("RECORD MODE",img);
			waitKey(5000);
			cvDestroyWindow("RECORD MODE");
			img.release();
			Pass->mode = 0;
			cvDestroyWindow("Record Window");
			return;
		}


		char vidFile[1024];

		sprintf(vidFile , "/home/horusi/recordvideos/%d.avi", Pass->videoId);

		cout << "VIDEOFILE ::" << vidFile << endl;

		VideoCapture vcap(0);

		if(!vcap.isOpened()){
			putText(axErrorWindow, "Camera cannot open ", Point(((Pass->m_nScreenWidth/2)-200), Pass->m_nScreenHeight/2.5), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
			imshow("Record Window",axErrorWindow);
			waitKey(2000);
			Pass->mode=0;
			cout << "Error opening video stream or file" << endl;
			return;
		}

		int frame_width=   vcap.get(CV_CAP_PROP_FRAME_WIDTH);
		int frame_height=   vcap.get(CV_CAP_PROP_FRAME_HEIGHT);

		VideoWriter video(vidFile, CV_FOURCC('x','2','6','4'), 30, Size(frame_width,frame_height), true);

		time_t rawtime;
		struct tm * timeinfo;

		time (&rawtime);
		timeinfo = localtime (&rawtime);

		//cout << "CURRENT TIME::" << timeinfo->tm_hour << ":" << timeinfo->tm_min << ":" << timeinfo->tm_sec << endl;

		Pass->startTime.hours    =  timeinfo->tm_hour;
		Pass->startTime.minutes = timeinfo->tm_min;
		Pass->startTime.seconds = timeinfo->tm_sec;
		Mat overlay;
		double alpha = 0.7;

		int count = 0;


		while(Pass->mode == 4){

			startTime = cvGetTickCount();

			count++;

			if(count == RECORDMINUTES) {
				break;
			}

			vcap >> frame;

			video.write(frame);

			//pthread_mutex_lock( &Pass->recordMutex1 );

			frame.copyTo(Pass->queueFrame[Pass->writeCursor]);
			//	frame.copyTo(overlay);

			//rectangle( Pass->queueFrame[Pass->writeCursor], Point( nDeleteButtonStartx, nDeleteButtonstarty ), Point(nDeleteButtonEndx ,nDeleteButtonEndy), Scalar(0,0,0),-1 , 4 );

			//	cv::addWeighted(overlay, alpha, Pass->queueFrame[Pass->writeCursor], 1 - alpha, 0, Pass->queueFrame[Pass->writeCursor]);

			//	putText(Pass->queueFrame[Pass->writeCursor], "DELETE VIDOES", Point((Pass->m_nScreenWidth/3), nDeleteButtonstarty+50),  FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);

			//cout << "WRITE FRAME ::" << Pass->writeCursor << endl;

			endTime = cvGetTickCount();

			Pass->writeFrameTime  = (( endTime - startTime) / ((double)cvGetTickFrequency()*1000));

			cout << "\n\n Write FREAME ::   " <<  Pass->writeCursor <<  " TIME ::" << Pass->writeFrameTime <<  endl;

			Pass->writeCursor++;

			Pass->writeCursor = Pass->writeCursor % BUFFERSIZE;

			//pthread_mutex_unlock( &Pass->recordMutex2 );
		}
		time_t rawtime1;
		struct tm * timeinfo1;

		time (&rawtime1);
		timeinfo1 = localtime (&rawtime1);


		//cout << "CURRENT TIME::" << timeinfo1->tm_hour << ":" << timeinfo1->tm_min << ":" << timeinfo1->tm_sec << endl;

		Pass->endTime.hours    =  timeinfo1->tm_hour;
		Pass->endTime.minutes = timeinfo1->tm_min;
		Pass->endTime.seconds = timeinfo1->tm_sec;

		Pass->computeTimeDifference(Pass->startTime, Pass->endTime, &Pass->difference);

		cout << endl << "TIME DIFFERENCE: " << Pass->startTime.hours << ":" << Pass->startTime.minutes << ":" << Pass->startTime.seconds;
		cout << " - " << Pass->endTime.hours << ":" << Pass->endTime.minutes << ":" << Pass->endTime.seconds;
		cout << " = " << Pass->difference.hours << ":" << Pass->difference.minutes << ":" << Pass->difference.seconds << endl;


		//cout << count << endl;

		vcap.release();

		if(Pass->mode == 0){
			cout << "MODE IS ZERO OUTSIDE OF THE RECORED VIDOES in MAIN PROCESS" << endl;
			break;
		}
	}

	Pass->mode = 0;
	cvDestroyWindow("Record Window");
}
