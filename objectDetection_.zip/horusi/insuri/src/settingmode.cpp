/*
 * settingmode.cpp
 *
 *  Created on: May 23, 2017
 *      Author: horusi
 */
#include "settingmode.h"
#include "overlay.h"

void saveROISettings(void *userdata)
{
	ThreadParam* Pass=(ThreadParam *)userdata;

	FileStorage fileROI;

	fileROI.open("ROISettings.xml", FileStorage::WRITE);
	fileROI << "m_nEndROIy" << Pass->m_nEndROIy;
	fileROI << "m_nrightendx" <<Pass->m_nrightendx;
	fileROI << "m_nleftendx" << Pass->m_nleftendx;
	fileROI.release();
	cout << "file Recovered.\n" << endl;
}


void SettingCallBackWindow(int event, int x, int y, int flags, void* userdata)
{
	ThreadParam* Pass=(ThreadParam *)userdata;


	int nFirstRectangleStartx=0;
	int nFirstRectangleStarty=(Pass->m_nScreenHeight/5.5)+35;


	int nFirstRectangleEndx=nFirstRectangleStartx+(Pass->m_nScreenWidth/7);
	int nFirstRectangleEndy=nFirstRectangleStarty+(Pass->m_nScreenHeight/5.5);

	int nSecondRectangleEndx=nFirstRectangleEndx;
	int nSecondRectangleEndy=nFirstRectangleEndy+(Pass->m_nScreenHeight/5.5);

	int nThirdRectangleEndx=nSecondRectangleEndx;
	int nThirdRectangleEndy=nSecondRectangleEndy+(Pass->m_nScreenHeight/5.5);

	int nFourthRectangleEndx=(Pass->m_nScreenWidth-nFirstRectangleEndx);
	int nFourthRectangleEndy=nFirstRectangleEndy;

	int nFifthRectangleEndx=(Pass->m_nScreenWidth-nFirstRectangleEndx);
	int nFifthRectangleEndy=nSecondRectangleEndy;

	int nSixthRectangleEndx=(Pass->m_nScreenWidth-nFirstRectangleEndx);
	int nSixthRectangleEndy=nThirdRectangleEndy;


	int nSaveButtonStartx=(Pass->m_nframeWidth/5)+50;
	int nSaveButtonstarty=Pass->m_nScreenHeight/1.2;

	int nSaveButtonEndx=(Pass->m_nScreenWidth-nSaveButtonStartx)-50;
	int nSaveButtonEndy=Pass->m_nScreenHeight;


	if  ( event == EVENT_LBUTTONDOWN )
	{

		if((nFirstRectangleEndx > x) && (y > nFirstRectangleStarty) && (y < nFirstRectangleEndy))
		{
			Pass->m_nEndROIy=Pass->m_nEndROIy+5;
		}

		else if((nFirstRectangleEndx > x) && (y > nFirstRectangleEndy) && (y < nSecondRectangleEndy))
		{
			Pass->m_nleftendx=Pass->m_nleftendx-5;
		}

		else if((nFirstRectangleEndx > x) && (y > nSecondRectangleEndy) && (y < (nSecondRectangleEndy+((Pass->m_nScreenHeight/5.5)))))
		{
			if((Pass->m_nleftendx+5)<Pass->m_nrightendx)
			{
				Pass->m_nleftendx=Pass->m_nleftendx+5;
			}
		}

		else if((x>(Pass->m_nframeWidth-(Pass->m_nframeWidth/7))) && (y > nFirstRectangleStarty) && (y < nFirstRectangleEndy))
		{
			Pass->m_nEndROIy=Pass->m_nEndROIy-5;
		}

		else if((x>(Pass->m_nframeWidth-(Pass->m_nframeWidth/7))) && (y > nFirstRectangleEndy) && (y < nSecondRectangleEndy))
		{
			Pass->m_nrightendx=Pass->m_nrightendx+5;

		}

		else if(((Pass->m_nframeWidth-nFirstRectangleEndx) < x) && (y > nSecondRectangleEndy) && (y < (nSecondRectangleEndy+((Pass->m_nScreenHeight/5.5)))))
		{

			if((Pass->m_nrightendx-5)>Pass->m_nleftendx)
			{
				Pass->m_nrightendx=Pass->m_nrightendx-5;
			}

		}

		else if((x>(nSaveButtonStartx) && (x<nSaveButtonEndx)) && (y>nSaveButtonstarty))
		{
			saveROISettings(Pass);
			cout<<"Settings saved"<<endl;
			Pass->mode = 0;
		}

		else
		{
			Pass->mode=0;
		}

	}
}

void  Settingmode :: settingMode(void * Data)
{
	ThreadParam* Pass = (ThreadParam*) Data;
	overlayvariables overlaydata;
	Mat axBlankBackground;
	Mat axErrorWindow;
	Mat frame;
	Mat resizeframe;
	overlaydata.BackgroundImage.copyTo(axBlankBackground);
	putText(axBlankBackground, "Loading ", Point(((Pass->m_nScreenWidth/2)-75), Pass->m_nScreenHeight/2.5), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);

	namedWindow("Camera Window",WINDOW_NORMAL);
	cvSetWindowProperty("Camera Window", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
	setMouseCallback("Camera Window",SettingCallBackWindow,Pass);
	overlaydata.BackgroundImage.copyTo(axErrorWindow);
	imshow("Camera Window",axBlankBackground);
	waitKey(1);
	VideoCapture capture;
	Mat axUpButton=imread("up.png");
	Mat axUpButtonimageResized;
	Mat axDownButton=imread("down.png");
	Mat axDownButtonimageResized;
	Mat axLeftButton=imread("left.png");
	Mat axLeftButtonimageResized;
	Mat axRightButton=imread("right.png");
	Mat axRightButtonimageResized;
	Size xSizeOfImages;
	Mat overlay;

	int thickness=10;

	capture.open(0);

	stringstream displayHoruseye;
	stringstream displayMode;
	Mat resizedFrame;
	displayHoruseye<<"HORUS-i";
	displayMode<<"SETTINGS MODE";
	if ( ! capture.isOpened() )
	{
		putText(axErrorWindow, "Camera cannot open ", Point(((Pass->m_nScreenWidth/2)-200), Pass->m_nScreenHeight/2.5), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
		imshow("Camera Window",axErrorWindow);
		waitKey(2000);
        Pass->mode=0;
		printf("--(!)Error opening video capture\n");
		cvDestroyWindow("Camera Window");
		return;
	}

	while (  capture.read(frame) && (Pass->mode==5))
	{


		if( frame.empty() )
		{
			printf(" --(!) No captured frame -- Break!");
			break;
		}

		resize(frame, resizedFrame, Size(720, 480), 0, 0, INTER_CUBIC); // resize to 720x480 resolution


		xSizeOfImages=Size(Pass->m_nScreenWidth/7, Pass->m_nScreenHeight/5.5);
		resize(axUpButton, axUpButtonimageResized, xSizeOfImages, 0, 0, INTER_CUBIC);
		resize(axDownButton, axDownButtonimageResized, xSizeOfImages, 0, 0, INTER_CUBIC);
		resize(axLeftButton, axLeftButtonimageResized, xSizeOfImages, 0, 0, INTER_CUBIC);
		resize(axRightButton, axRightButtonimageResized, xSizeOfImages, 0, 0, INTER_CUBIC);
		resize(axRightButton, axRightButtonimageResized, xSizeOfImages, 0, 0, INTER_CUBIC);

		Pass->lineconfiguration(resizedFrame,Pass->m_nEndROIy,Pass->m_nleftendx,Pass->m_nrightendx,Pass->highwaymode);

		int nFirstRectangleStartx=0;
		int nFirstRectangleStarty=(Pass->m_nScreenHeight/5.5)+35;


		int nFirstRectangleEndx=nFirstRectangleStartx+(Pass->m_nScreenWidth/7);
		int nFirstRectangleEndy=nFirstRectangleStarty+(Pass->m_nScreenHeight/5.5);

		int nSecondRectangleEndx=nFirstRectangleEndx;
		int nSecondRectangleEndy=nFirstRectangleEndy+(Pass->m_nScreenHeight/5.5);

		int nThirdRectangleEndx=nSecondRectangleEndx;
		int nThirdRectangleEndy=nSecondRectangleEndy+(Pass->m_nScreenHeight/5.5);

		int nFourthRectangleEndx=(Pass->m_nScreenWidth-nFirstRectangleEndx);
		int nFourthRectangleEndy=nFirstRectangleEndy;

		int nFifthRectangleEndx=(Pass->m_nScreenWidth-nFirstRectangleEndx);
		int nFifthRectangleEndy=nSecondRectangleEndy;

		int nSixthRectangleEndx=(Pass->m_nScreenWidth-nFirstRectangleEndx);
		int nSixthRectangleEndy=nThirdRectangleEndy;

		int nSaveButtonStartx=nFirstRectangleEndx+50;
		int nSaveButtonstarty=Pass->m_nScreenHeight/1.2;

		int nSaveButtonEndx=nFourthRectangleEndx-50;
		int nSaveButtonEndy=Pass->m_nScreenHeight;

		Rect axFirstRowLeftButton(0,nFirstRectangleStarty, axUpButtonimageResized.cols, axUpButtonimageResized.rows);
		Rect axFirstRowRightButton( (Pass->m_nScreenWidth-(Pass->m_nScreenWidth/7)), nFirstRectangleStarty, axDownButtonimageResized.cols, axUpButtonimageResized.rows);
		Rect axSecondRowLeftButton(0, nFirstRectangleEndy, axLeftButtonimageResized.cols, axLeftButtonimageResized.rows);
		Rect axSecondRowRightButton((Pass->m_nScreenWidth-(Pass->m_nScreenWidth/7)),nFirstRectangleEndy, axRightButtonimageResized.cols, axRightButtonimageResized.rows);
		Rect axThirdRowLeftButton(0,nSecondRectangleEndy, axLeftButtonimageResized.cols, axLeftButtonimageResized.rows);
		Rect axThirdRowRightButton((Pass->m_nScreenWidth-(Pass->m_nScreenWidth/7)),nSecondRectangleEndy, axRightButtonimageResized.cols, axRightButtonimageResized.rows);

		cv::Mat roi = resizedFrame(cv::Rect(0, 0, nFirstRectangleEndx ,nFirstRectangleEndy));
		Mat overlay;
		double alpha = 0.7;
		resizedFrame.copyTo(overlay);

		axDownButtonimageResized.copyTo(resizedFrame(axFirstRowLeftButton));
		axUpButtonimageResized.copyTo(resizedFrame(axFirstRowRightButton));
		axLeftButtonimageResized.copyTo(resizedFrame(axSecondRowLeftButton));
		axRightButtonimageResized.copyTo(resizedFrame(axSecondRowRightButton));
		axRightButtonimageResized.copyTo(resizedFrame(axThirdRowLeftButton));
		axLeftButtonimageResized.copyTo(resizedFrame(axThirdRowRightButton));

		rectangle( resizedFrame, Point( nSaveButtonStartx, nSaveButtonstarty ), Point(nSaveButtonEndx ,nSaveButtonEndy), Scalar( 0, 0, 0 ),-1 , 4 );

		cv::addWeighted(overlay, alpha, resizedFrame, 1 - alpha, 0, resizedFrame);

		putText(resizedFrame, "SAVE", Point((Pass->m_nScreenWidth/2)-40, nSaveButtonstarty+50),  FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
		putText(resizedFrame,displayHoruseye.str() , Point2f(100,40), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
		putText(resizedFrame,displayMode.str() , Point2f(100,60), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
		putText(resizedFrame,"Change Field" , Point2f(3,(nFirstRectangleStarty-20)), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);
		putText(resizedFrame,"Change Field" , Point2f(((Pass->m_nScreenWidth-nFirstRectangleEndx)-30),(nFirstRectangleStarty-20)), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);


		imshow("Camera Window", resizedFrame);
		char sKeyboardInterrupt;
		sKeyboardInterrupt = (char) waitKey(1);
		if (sKeyboardInterrupt == 112)
		{
			Mat passFrame;
			resizedFrame.copyTo(passFrame);
			Pass->pauseFunction(frame,passFrame,Pass);

		}

	}

	Pass->mode = 0;
	cvDestroyWindow("Camera Window");
	capture.release();

	cout << "\n\nWINDOW DESTROY " << endl;
}
