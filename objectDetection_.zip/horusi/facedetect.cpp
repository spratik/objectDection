#include "opencv2/objdetect.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/videoio.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/core/utility.hpp"
#include "opencv2/videoio/videoio_c.h"
#include "opencv2/highgui/highgui_c.h"
#include <cctype>
#include <iostream>
#include <iterator>
#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>

#include <pthread.h>
#include <semaphore.h>
#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/time.h>
#include <fstream>
#include <iostream>


#define NUM_THREADS     5

using namespace std;
using namespace cv;

struct thread_data{
   int  thread_id;
   char *message;
};

pthread_mutex_t frame_copy_protect     = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  frameReady   = PTHREAD_COND_INITIALIZER;
sem_t no_framesReady;
sem_t analysisDone;

string cascadeName = "haarcascade_frontalface_alt.xml";
string nestedCascadeName = "haarcascade_eye_tree_eyeglasses.xml";
CvCapture* capture = 0;
Mat frame, frameCopy, image;
const string scaleOpt = "--scale=";
size_t scaleOptLen = scaleOpt.length();
const string cascadeOpt = "--cascade=";
size_t cascadeOptLen = cascadeOpt.length();
const string nestedCascadeOpt = "--nested-cascade";
size_t nestedCascadeOptLen = nestedCascadeOpt.length();
const string tryFlipOpt = "--try-flip";
size_t tryFlipOptLen = tryFlipOpt.length();
string inputName;
bool tryflip = false;
CascadeClassifier cascade, nestedCascade;
double scale = 1;

void detectAndDraw( Mat& img, CascadeClassifier& cascade,
                    CascadeClassifier& nestedCascade,
                    double scale, bool tryflip );                   
int cap_init(int,const char**);
int buf_frame();
double timeStart = 0, timeEnd = 0;

// forward declaration: user-defined timer function
static void timer_func();

// ----------------------------------------------------------------------------------------
// begin provided code part
// variables needed for timer
static sem_t timer_sem;		// semaphore that's signaled if timer signal arrived
static bool timer_stopped;	// non-zero if the timer is to be timer_stopped
static pthread_t timer_thread;	// thread in which user timer functions execute

/* Timer signal handler.
 * On each timer signal, the signal handler will signal a semaphore.
 */
static void
timersignalhandler(int dummy) 
{
	/* called in signal handler context, we can only call 
	 * async-signal-safe functions now!
	 */

dummy=0;
	sem_post(&timer_sem);	// the only async-signal-safe function pthreads defines
}

/* Timer thread.
 * This dedicated thread waits for posts on the timer semaphore.
 * For each post, timer_func() is called once.
 * 
 * This ensures that the timer_func() is not called in a signal context.
 */
static void *
timerthread(void *_) 
{
	while (!timer_stopped) {
		int rc = sem_wait(&timer_sem);		// retry on EINTR
		if (rc == -1 && errno == EINTR)
		    continue;
		if (rc == -1) {
		    perror("sem_wait");
		    exit(-1);
		}

		timer_func();	// user-specific timerfunc, can do anything it wants
	}
	return 0;
}

/* Initialize timer */
void
init_timer(void) 
{
	/* One time set up */
	sem_init(&timer_sem, /*not shared*/ 0, /*initial value*/0);
	pthread_create(&timer_thread, (pthread_attr_t*)0, timerthread, (void*)0);
	signal(SIGALRM, timersignalhandler);
}

/* Shut timer down */
void
shutdown_timer() 
{
	timer_stopped = true;
	sem_post(&timer_sem);
	pthread_join(timer_thread, 0);
}

/* Set a periodic timer.  You may need to modify this function. */
void
set_periodic_timer(long delay) 
{
	struct itimerval tval = { 
		/* subsequent firings */ .it_interval = { .tv_sec = 0, .tv_usec = delay }, 
		/* first firing */       .it_value = { .tv_sec = 0, .tv_usec = delay }};

	setitimer(ITIMER_REAL, &tval, (struct itimerval*)0);
}

static sem_t demo_over;	// a semaphore to stop the demo when done

/* Put your timer code in here */
static void 
timer_func() 
{
	/* The code below is just a demonstration. */
	static int i = 0;

	printf ("Timer called %d!\n", i);
	if (++i == 500) {
		shutdown_timer();
		sem_post(&demo_over);	// signal main thread to exit
	}
}

void *video_capture(void *) {
   
   if( capture )
    {
        cout << "In capture ..." << endl;
        while(1)
        {
			IplImage* iplImg = cvQueryFrame( capture );
            frame = cv::cvarrToMat(iplImg);
            if( frame.empty() )
                break;
            if( iplImg->origin == IPL_ORIGIN_TL )
            {
				pthread_mutex_lock( &frame_copy_protect );
                frame.copyTo( frameCopy );
                pthread_mutex_unlock( &frame_copy_protect );
			}
            else
            {
				pthread_mutex_lock( &frame_copy_protect );
                flip( frame, frameCopy, 0 );
                pthread_mutex_unlock( &frame_copy_protect );
			}
               
		//	pthread_cond_signal( &frameReady);
        //    pthread_mutex_unlock( &frame_copy_protect ); 
            sem_post(&no_framesReady);  
             if( waitKey( 10 ) >= 0 )
             goto _cleanup_;
            
        }

        waitKey(0);

_cleanup_:
        cvReleaseCapture( &capture );
        cout << "Video thread completed" << endl;
    }
    else
    {
        cout << "Couldn't read camera Inputs" << endl;     
    }
    cvDestroyWindow("result");
}

void *analyse_frame(void *) {
   
   while(1)
   {
	sem_wait(&no_framesReady);
	pthread_mutex_lock( &frame_copy_protect );
   // pthread_cond_wait( &frameReady, &frame_copy_protect );   
    detectAndDraw(frameCopy, cascade, nestedCascade, scale, tryflip );
	pthread_mutex_unlock( &frame_copy_protect );
	sem_post(&analysisDone);
   }
}

void *display_frame(void *)
{
	while(1)
	{
		sem_wait(&analysisDone);
		pthread_mutex_lock( &frame_copy_protect );
		    printf( "detection time = %g ms\n", timeEnd/((double)cvGetTickFrequency()*1000.) );

		cv::imshow( "result", frameCopy );
		pthread_mutex_unlock( &frame_copy_protect );
		
	}
}


static void help()
{
    cout << "\nThis program demonstrates the cascade recognizer. Now you can use Haar or LBP features.\n"
            "This classifier can recognize many kinds of rigid objects, once the appropriate classifier is trained.\n"
            "It's most known use is for faces.\n"
            "Usage:\n"
            "./facedetect [--cascade=<cascade_path> this is the primary trained classifier such as frontal face]\n"
               "   [--nested-cascade[=nested_cascade_path this an optional secondary classifier such as eyes]]\n"
               "   [--scale=<image scale greater or equal to 1, try 1.3 for example>]\n"
               "   [--try-flip]\n"
               "   [filename|camera_index]\n\n"
            "see facedetect.cmd for one call:\n"
            "./facedetect --cascade=\"../../data/haarcascades/haarcascade_frontalface_alt.xml\" --nested-cascade=\"../../data/haarcascades/haarcascade_eye.xml\" --scale=1.3\n\n"
            "During execution:\n\tHit any key to quit.\n"
            "\tUsing OpenCV version " << CV_VERSION << "\n" << endl;
}

int main( int argc, const char** argv )
{
// Thread creation initializaton
    pthread_t video_thread,analyse_thread, display_thread;
    struct thread_data thr_vari;
    sem_init(&no_framesReady, 0, 0);
    sem_init(&analysisDone,0,0);
    
    int response1,thread1_number,response2,thread2_number, response3, thread3_number;
    help();
    cap_init(argc, argv);    //initialization    

	//sem_init(&demo_over, /*not shared*/ 0, /*initial value*/0);

	//init_timer();
	//set_periodic_timer(/* 200ms */200000);

	/* Wait for timer_func to be called five times - note that 
	 * since we're using signals, sem_wait may fail with EINTR.
         */
//	while (sem_wait(&demo_over) == -1 && errno == EINTR)
//	    continue;
	
	response2 = pthread_create(&analyse_thread, NULL,analyse_frame, NULL);
    if (response2)
    {
         cout << "Error:unable to create thread_2," << response2 << endl;
         exit(-1);
    }
            
    response1 = pthread_create(&video_thread, NULL,video_capture, NULL);
    if (response1)
    {
         cout << "Error:unable to create thread_1," << response1 << endl;
         exit(-1);
    }
    
    response3 = pthread_create(&display_thread, NULL,display_frame, NULL);
    if (response3)
    {
         cout << "Error:unable to create thread_1," << response3 << endl;
         exit(-1);
    }


    pthread_join(video_thread,NULL);
    pthread_join(analyse_thread,NULL);
    pthread_join(display_thread,NULL);

return 0;
}

int cap_init( int argc, const char** argv )
{
    for( int i = 1; i < argc; i++ )
    {
        cout << "Processing " << i << " " <<  argv[i] << endl;
        if( cascadeOpt.compare( 0, cascadeOptLen, argv[i], cascadeOptLen ) == 0 )
        {
            cascadeName.assign( argv[i] + cascadeOptLen );
            cout << "  from which we have cascadeName= " << cascadeName << endl;
        }
        else if( nestedCascadeOpt.compare( 0, nestedCascadeOptLen, argv[i], nestedCascadeOptLen ) == 0 )
        {
            if( argv[i][nestedCascadeOpt.length()] == '=' )
                nestedCascadeName.assign( argv[i] + nestedCascadeOpt.length() + 1 );
            if( !nestedCascade.load( nestedCascadeName ) )
                cerr << "WARNING: Could not load classifier cascade for nested objects" << endl;
        }
        else if( scaleOpt.compare( 0, scaleOptLen, argv[i], scaleOptLen ) == 0 )
        {
            if( !sscanf( argv[i] + scaleOpt.length(), "%lf", &scale ) || scale < 1 )
                scale = 1;
            cout << " from which we read scale = " << scale << endl;
        }
        else if( tryFlipOpt.compare( 0, tryFlipOptLen, argv[i], tryFlipOptLen ) == 0 )
        {
            tryflip = true;
            cout << " will try to flip image horizontally to detect assymetric objects\n";
        }
        else if( argv[i][0] == '-' )
        {
            cerr << "WARNING: Unknown option %s" << argv[i] << endl;
        }
        else
            inputName.assign( argv[i] );
    }

    if( !cascade.load( cascadeName ) )
    {
        cerr << "ERROR: Could not load classifier cascade" << endl;
        help();
        return -1;
    }

    if( inputName.empty() || (isdigit(inputName.c_str()[0]) && inputName.c_str()[1] == '\0') )
    {
        capture = cvCaptureFromCAM( inputName.empty() ? 0 : inputName.c_str()[0] - '0' );
        int c = inputName.empty() ? 0 : inputName.c_str()[0] - '0' ;
        if(!capture) cout << "Capture from CAM " <<  c << " didn't work" << endl;
    }
    else if( inputName.size() )
    {
        image = imread( inputName, 1 );
        if( image.empty() )
        {
            capture = cvCaptureFromAVI( inputName.c_str() );
            if(!capture) cout << "Capture from AVI didn't work" << endl;
        }
    }
    else
    {
      cout << "Couldn't read camera Inputs" << endl;
    }
}


void detectAndDraw( Mat& img, CascadeClassifier& cascade,
                    CascadeClassifier& nestedCascade,
                    double scale, bool tryflip )
{
    int i = 0;
    vector<Rect> faces, faces2;
    const static Scalar colors[] =  { CV_RGB(0,0,255),
        CV_RGB(0,128,255),
        CV_RGB(0,255,255),
        CV_RGB(0,255,0),
        CV_RGB(255,128,0),
        CV_RGB(255,255,0),
        CV_RGB(255,0,0),
        CV_RGB(255,0,255)} ;
    Mat gray, smallImg( cvRound (img.rows/scale), cvRound(img.cols/scale), CV_8UC1 );

    cvtColor( img, gray, COLOR_BGR2GRAY );
    resize( gray, smallImg, smallImg.size(), 0, 0, INTER_LINEAR );
    equalizeHist( smallImg, smallImg );

    timeStart = (double)cvGetTickCount();
    cascade.detectMultiScale( smallImg, faces,
        1.1, 2, 0
        //|CASCADE_FIND_BIGGEST_OBJECT
        //|CASCADE_DO_ROUGH_SEARCH
        |CASCADE_SCALE_IMAGE
        ,
        Size(30, 30) );
    if( tryflip )
    {
        flip(smallImg, smallImg, 1);
        cascade.detectMultiScale( smallImg, faces2,
                                 1.1, 2, 0
                                 //|CASCADE_FIND_BIGGEST_OBJECT
                                 //|CASCADE_DO_ROUGH_SEARCH
                                 |CASCADE_SCALE_IMAGE
                                 ,
                                 Size(30, 30) );
        for( vector<Rect>::const_iterator r = faces2.begin(); r != faces2.end(); r++ )
        {
            faces.push_back(Rect(smallImg.cols - r->x - r->width, r->y, r->width, r->height));
        	cout << r->width;
        	cout << r->height;
	}
    }

    timeEnd = (double)cvGetTickCount() - timeStart;
	FILE *fptr;
	fptr = fopen("log.txt", "w");
	fprintf(fptr, "time end = %f", timeEnd);
	fclose(fptr);

    for( vector<Rect>::const_iterator r = faces.begin(); r != faces.end(); r++, i++ )
    {
        Mat smallImgROI;
        vector<Rect> nestedObjects;
        Point center;
        Scalar color = colors[i%8];
        int radius;

        double aspect_ratio = (double)r->width/r->height;
        if( 0.75 < aspect_ratio && aspect_ratio < 1.3 )
        {
            center.x = cvRound((r->x + r->width*0.5)*scale);
            center.y = cvRound((r->y + r->height*0.5)*scale);
            radius = cvRound((r->width + r->height)*0.25*scale);
            circle( img, center, radius, color, 3, 8, 0 );
        }
        else
            rectangle( img, cvPoint(cvRound(r->x*scale), cvRound(r->y*scale)),
                       cvPoint(cvRound((r->x + r->width-1)*scale), cvRound((r->y + r->height-1)*scale)),
                       color, 3, 8, 0);
        if( nestedCascade.empty() )
            continue;
        smallImgROI = smallImg(*r);
        nestedCascade.detectMultiScale( smallImgROI, nestedObjects,
            1.1, 2, 0
            //|CASCADE_FIND_BIGGEST_OBJECT
            //|CASCADE_DO_ROUGH_SEARCH
            //|CASCADE_DO_CANNY_PRUNING
            |CASCADE_SCALE_IMAGE
            ,
            Size(30, 30) );
        for( vector<Rect>::const_iterator nr = nestedObjects.begin(); nr != nestedObjects.end(); nr++ )
        {
            center.x = cvRound((r->x + nr->x + nr->width*0.5)*scale);
            center.y = cvRound((r->y + nr->y + nr->height*0.5)*scale);
            radius = cvRound((nr->width + nr->height)*0.25*scale);
            circle( img, center, radius, color, 3, 8, 0 );
        }
    }
    
}


