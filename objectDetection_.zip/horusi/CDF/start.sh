#!/bin/bash

cd /home/horusi/horus-i/

ulimit -c unlimited

datadirectory="/home/horusi/horus-i/data"
if [ ! -d "$datadirectory" ]
then
	sudo mkdir -p /home/horusi/horus-i/data
	sudo chmod -R 777 /home/horusi/horus-i/data
else
	echo "Data folder found"
fi

coredumpdirectory="/home/horusi/horus-i/data/coredumps"
if [ ! -d "$coredumpdirectory" ]
then
	sudo mkdir -p /home/horusi/horus-i/data/coredumps
	sudo chmod -R 777 /home/horusi/horus-i/data/coredumps
else
        echo "Core dump folder found"
fi

sudo ./coredump.sh

logdirectory="/home/horusi/horus-i/data/log"
if [ ! -d "$logdirectory" ]
then
	sudo mkdir -p /home/horusi/horus-i/data/log
	sudo chmod -R 777 /home/horusi/horus-i/data/log
else
        echo "Log folder found"
fi


file="/home/horusi/horus-i/updateflag"
if [ -f "$file" ]
then
	echo "Flag found."
        echo "Updating software"
        sudo python update.py /home/horusi/cache/ /home/horusi/horus-i/
else
	echo "flag not found."
        echo "Software up to date"
fi

while true
do
	sudo xinit -geometry 320x240 ./Horusi
	echo "APP Started"
done
