#!/usr/bin/python

import os
copyFrom="~/eclipse/"
copyTo="~/upload/"


try:
  path=sys.argv[1]
except:
  print "Not valid path from user for source folder to copy\n"

try:
  destinationpath=sys.argv[2]
except:
  print "Not valid path from user for destination folder\n"

fileCount=0
filePointer=open("uploadfilelist","r")
fileString=filePointer.read()
filenameArray=fileString.split("\n")
for file in filenameArray:
    if file!="":
       filename=copyFrom+file
       command="cp "+ filename+" "+copyTo
       copyStatus=os.system(command)

       if(copyStatus==0):
           print filename+" Copied Sucessfully"
           fileCount=fileCount+1
       else:
           print filename+" unable to Copy"

print "\n\n"+str(fileCount)+"Files Copied From :"+copyFrom+" To :"+copyTo

command="python "+copyFrom+"checksum.py"
status=os.system(command)

if(status==0):
    print "\nchecksum calculated sucessfully in :"+copyTo
else:
    print "\nchecksum not calculated sucessfully"


