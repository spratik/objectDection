#!/bin/bash


echo "/home/horusi/horus-i/data/coredumps/core.%e.%p.%t" > /proc/sys/kernel/core_pattern
