import os
import sys
import hashlib

path="/home/horusi/cache/"
destinationpath="/home/horusi/horus-i/"


try:
  path=sys.argv[1]
except:
  print "Not valid path from user for source folder to copy"

try:
  destinationpath=sys.argv[2]
except:
  print "Not valid path from user for destination folder"


def md5(fname):
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


files = os.listdir(path)

print "Start copying files\n"
totalchecksum=0
count=0
for filename in files:
       if((path+filename != path+"horusi.zip")):
          command="sudo cp "+path+filename+" "+destinationpath
          status=os.system(command)
          if(status==0):
              print destinationpath+filename+" copied sucessfully"
          else:
              print destinationpath+filename+" not copied sucessfully"
              command="sudo reboot"
              status=os.system(command)
              if(status==0):
                 print "Rebooting the system please wait...."
              else:
                 print "please reboot manually for update"
              sys.exit(1)
          hchecksum=md5(destinationpath+filename)
          temp = int(hchecksum, 16)
          if(path+filename != path+"checksumtotal"):
              totalchecksum=totalchecksum+temp
              count=count+1
          print destinationpath+filename+" : "+str(hchecksum)

print count
print "\nchecksum calculated after copy:\n"+str(totalchecksum)

file=open(path+"checksumtotal","r")
checksum=int(file.read())
if(checksum==totalchecksum):
   updatechecksum=open(destinationpath+"checksumtotal","w")
   updatechecksum.write(str(totalchecksum))
   updatechecksum.close()
   print "checksum written sucessfully for updated software"

command="sudo chmod -R 777 "+destinationpath
status=os.system(command)

if(status==0):
    print destinationpath+" permission set properly"
else:
    print destinationpath+"permission set not completed"

command="sudo rm "+destinationpath+"updateflag"
status=os.system(command)

if(status==0):
   print "Update sucessfull"
   command="sudo rm -rf "+path
   stat=os.system(command)
   if(stat==0):
       print "cache folder deleted"
   else:
       print "cache folder not deleted..."
else:
   print "Update failed"
   sys.exit(1)
