import zipfile
import hashlib
import os
from shutil import copyfile
import errno, sys

destinationpath="/home/horusi/horus-i/"
path="/home/horusi/cache/"


def md5(fname):
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

try:
  path=sys.argv[1]
except:
  print "Not valid path from user"

try:
  destinationpath=sys.argv[2]
except:
  print "Not valid path from user"

if(os.path.exists("/tmp/identity.pem")):
     os.system("sudo rm /tmp/identity.pem")
else: 
     print "Failed to remove the identity file" 

command="sudo unzip -o "+path+"horusi.zip -d "+path
status=os.system(command)

if(status==0):
   print "horusi.zip extracted sucessfully"
else:
   print "fail to unzip  file currupted"
   sys.exit(1)

if(os.path.exists(destinationpath)):
   print destinationpath+" folder exist continuing update...."
else:
   print "Folder not exist creating the folder....\n"
   command="sudo mkdir "+destinationpath
   status=os.system(command)
   if(status==0):
       print "horus-i folder created sucessfully"
   else:
       print "horus-i folder not created please create manually and update Again...."
       sys.exit(1)

if(os.path.exists(destinationpath+"horusiversioncheck")):
    print destinationpath+" version file found continuing update...."
    file=open(destinationpath+"horusiversioncheck","r")
    previousversion=str(file.read())
    file.close()
    file=open(path+"horusiversioncheck","r")
    currentversionversion=str(file.read())
    file.close()
    if(previousversion==currentversionversion):
        print "Horus-i already a latest version."
        sys.exit(1)

else:
    print destinationpath+" version file not found continuing update...." 


totalchecksum=0
count=0

files = os.listdir(path)

for filename in files:
    filename=path+filename
    if((filename != path+"horusi.zip")):
       hchecksum=md5(filename)
       temp = int(hchecksum, 16)
       if(filename != path+"checksumtotal"):
           totalchecksum=totalchecksum+temp
           count=count+1
       print filename+" : "+str(hchecksum)

print count
print "\nchecksum calculated :\n"+str(totalchecksum)
file=open(path+"checksumtotal","r")
checksum=int(file.read())
print "\nchecksum read :\n"+str(checksum)

if(totalchecksum==checksum):
   print "\nfiles downloaded sucessfully"
   updatefile=open(destinationpath+"updateflag","w")
   updatefile.close()
   print "\nupdate flag created\n"
   os.system("sudo reboot")
else:
   print "\nfiles not downloaded Sucessfully"
   print "\n\nchecksum error"
   print "\nUpdate flag not created"


