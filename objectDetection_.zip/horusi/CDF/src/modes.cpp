/*
 * modes.cpp
 *
 *  Created on: 28-Feb-2017
 *      Author: pratik
 */

#include "modes.h"
#include <string>
#include <iostream>
#include <fstream>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <wiringPi.h>
#include <time.h>
#include "Recordmode.h"
#include "overlay.h"
#include "enum.h"
#include "playbackmode.h"
#include "demo.h"
#include "settingmode.h"

#define INF 10000
#define SIZE 2048
#define HORUSI_BUILD "Horus-I Build " __DATE__ __TIME__


#define BUFFERSIZE 100

#define RECORDMINUTES  1800

#define NOOFVIDOES 61

#define MAXVIDOESCOUNT 100

using namespace cv;

using namespace cv::ml;

using namespace std;

int countVideo = 1;

int startVideoCount = 1;

int endVideoCount;

extern int g_nFrameHeight;
extern int g_nFrameWidth;

pthread_mutex_t mutexDisplayRecordedFrame     = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  condDisplayRecordedFrame   = PTHREAD_COND_INITIALIZER;

pthread_mutex_t mutexWifiStatus     = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  condWifiStatus   = PTHREAD_COND_INITIALIZER;

pthread_mutex_t mutexRecordModeExit     = PTHREAD_MUTEX_INITIALIZER;


extern pthread_mutex_t mutexAppmodeSignalAcess;
extern pthread_cond_t condAppmodeSignal;

extern pthread_mutex_t mutexAppmodeStopSignalAcess;
extern pthread_cond_t condAppmodeStopSignal;
extern pthread_cond_t condAppmodeDisplayFrameReady;
extern pthread_mutex_t prevetDestroyWindow;

bool Modes :: onSegment(Point p, Point q, Point r)
{
	if (q.x <= max(p.x, r.x) && q.x >= min(p.x, r.x) &&
			q.y <= max(p.y, r.y) && q.y >= min(p.y, r.y))
		return true;
	return false;
}

int Modes :: orientation(Point p, Point q, Point r)
{
	int val = (q.y - p.y) * (r.x - q.x) -
			(q.x - p.x) * (r.y - q.y);

	if (val == 0) return 0;
	return (val > 0)? 1: 2;
}

bool Modes :: doIntersect(Point p1, Point q1, Point p2, Point q2)
{

	int o1 = orientation(p1, q1, p2);
	int o2 = orientation(p1, q1, q2);
	int o3 = orientation(p2, q2, p1);
	int o4 = orientation(p2, q2, q1);

	if (o1 != o2 && o3 != o4)
		return true;

	if (o1 == 0 && onSegment(p1, p2, q1)) return true;

	if (o2 == 0 && onSegment(p1, q2, q1)) return true;

	if (o3 == 0 && onSegment(p2, p1, q2)) return true;

	if (o4 == 0 && onSegment(p2, q1, q2)) return true;

	return false; // Doesn't fall in any of the above cases
}

bool Modes :: isInside(Point polygon[], int n, Point p)
{
	if (n < 3)  return false;

	Point extreme(INF, p.y);
	int count = 0, i = 0;
	do
	{
		int next = (i+1)%n;
		if (doIntersect(polygon[i], polygon[next], p, extreme))
		{
			if (orientation(polygon[i], p, polygon[next]) == 0)
				return onSegment(polygon[i], p, polygon[next]);

			count++;
		}
		i = next;
	} while (i != 0);
	return count&1;
}

bool Modes :: isInROI(Point x1,Point x2,Point x3,Point x4,Point aROIPolygone[],int nSizeofROIPolygone)
{
	if(isInside(aROIPolygone,nSizeofROIPolygone,x1)||isInside(aROIPolygone,nSizeofROIPolygone,x2)||isInside(aROIPolygone,nSizeofROIPolygone,x3)||isInside(aROIPolygone,nSizeofROIPolygone,x4))
	{
		return true;
	}
	else
	{
		return false;
	}
}

void DemoCallBackWindow(int event, int x, int y, int flags, void* userdata)
{

	ThreadParam* PassedArguments=(ThreadParam *)userdata;
	if  ( event == EVENT_LBUTTONDOWN )
	{
		PassedArguments->mode=0;
	}
}

void guiUpdateFunctionCall(int event, int x, int y, int flags, void* Data)
{
	ThreadParam* Pass = (ThreadParam*) Data;
	if  ( event == EVENT_LBUTTONDOWN )
	{
		int nFirstRectangleEndx=Pass->m_nScreenWidth/3;
		int nFirstRectangleEndy=Pass->m_nScreenHeight/2;

		int nSecondRectangleEndx=(Pass->m_nScreenWidth/3)+nFirstRectangleEndx;
		int nSecondRectangleEndy=(Pass->m_nScreenHeight/2);

		int nThirdRectangleEndx=(Pass->m_nScreenWidth/3)+nSecondRectangleEndx;
		int nThirdRectangleEndy=Pass->m_nScreenHeight/2;

		Mat frame=imread("BackGround.jpg");
		if(x<nFirstRectangleEndx && x<nSecondRectangleEndx && y<nFirstRectangleEndy)
		{
			Pass->updateMode=1;
			cout<<"updateMode 1 switched"<<endl;
		}

		if(x>nFirstRectangleEndx && x<nSecondRectangleEndx && y<nFirstRectangleEndy)
		{
			Pass->updateMode=2;
			cout<<"updateMode 2 switched"<<endl;
		}


		if(x>nSecondRectangleEndx && x<Pass->m_nScreenWidth && y<nFirstRectangleEndy)
		{
			Pass->updateMode=3;
			Pass->mode=0;
			cout<<"updateMode 3 switched"<<endl;

		}
		if(x < nFirstRectangleEndx && x < nSecondRectangleEndx && y > nFirstRectangleEndy)
		{
			Pass->updateMode = 4;
			cout<<"updated  4 switched"<<endl;
		}

		if(x>nFirstRectangleEndx && x<nSecondRectangleEndx && y>nFirstRectangleEndy)
		{
			Pass->updateMode = 5;
			cout<<"mode 5 switched"<<endl;

		}

	}
}



void Modes :: drawPedestrianVehicle(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle,int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight)
{
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );
			ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
		}
		else
		{
			nCountingPedestrianFalseObjects++;

		}
	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{
		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{

			Point x1(vehicle[i].x,vehicle[i].y);
			Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));
			rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

		}
		else
		{
			nCountingVehicleFalseObjects++;
		}
	}

}



void Modes :: drawPedestrian(Mat& frame,std::vector<Rect> pedestrian, int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight)
{
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );
			ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
		}
		else
		{
			nCountingPedestrianFalseObjects++;

		}
	}

}

void Modes :: drawVehicle(Mat& frame,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight)
{
	for( size_t i = 0; i < vehicle.size(); i++ )
	{
		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{

			Point x1(vehicle[i].x,vehicle[i].y);
			Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));
			rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

		}
		else
		{
			nCountingVehicleFalseObjects++;
		}
	}

}


void Modes :: drawVehiclePedestrianROI(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,Point aROIPolygone[],int &nSizeofROIPolygone,bool &bBountingBoxInside,void* Data)
{
	int nPercentageMatching;
	nCountingPedestrian=0;
	nCountingPedestrianFalseObjects=0;
	nCountingVehicleFalseObjects=0;
	nCountingVehicles=0;
	ThreadParam* Pass = (ThreadParam*) Data;
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		Point x1(pedestrian[i].x,pedestrian[i].y);
		Point x2(pedestrian[i].x+pedestrian[i].width,pedestrian[i].y);
		Point x3(pedestrian[i].x,pedestrian[i].y+pedestrian[i].height);
		Point x4((pedestrian[i].x+pedestrian[i].width),(pedestrian[i].y+pedestrian[i].height));
		Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );

		bBountingBoxInside=isInROI(x1,x2,x3,x4,aROIPolygone,nSizeofROIPolygone);

		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{

			if(bBountingBoxInside)
			{
				ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
				Pass->m_nNoofpedestrianinYellowROI++;
			}

			else
			{
				ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 255, 0 ), 2, 8, 0 );
				Pass->m_nNoofpedestrianinRedROI++;
			}

		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}

	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{

		Point x1(vehicle[i].x,vehicle[i].y);
		Point x2(vehicle[i].x+vehicle[i].width,vehicle[i].y);
		Point x3(vehicle[i].x,vehicle[i].y+vehicle[i].height);
		Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));

		bBountingBoxInside=isInROI(x1,x2,x3,x4,aROIPolygone,nSizeofROIPolygone);

		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{

			if(bBountingBoxInside)
			{
				rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

			}

			else
			{
				rectangle(frame,x1,x4, Scalar( 0, 255, 0 ), 2);
			}

		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}
	}
}


void Modes :: drawVehiclePedestrianHistogramComparision(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,Point aROIPolygone[],int &nSizeofROIPolygone,bool &bBountingBoxInside,int nHistogramChannels[],Mat& xTemplateHistogram,MatND& xcropedImageHistogram,int nHistogramSize[],const float* fHistogramRanges[])
{
	int nPercentageMatching;
	nCountingPedestrian=0;
	nCountingPedestrianFalseObjects=0;
	nCountingVehicleFalseObjects=0;
	nCountingVehicles=0;
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		Mat src1 = frame(pedestrian[i]);
		calcHist( &src1, 1, nHistogramChannels, Mat(),
				xcropedImageHistogram, 2, nHistogramSize, fHistogramRanges,
				true,
				false );

		Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );
		nPercentageMatching=compareHist(xTemplateHistogram,xcropedImageHistogram,CV_COMP_CORREL)*100;
		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			if(nPercentageMatching>25)
			{
				stringstream displayMessage;
				displayMessage <<nPercentageMatching<<"%";
				putText(frame,displayMessage.str() , Point2f(pedestrian[i].x,pedestrian[i].y), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 1);
				ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
			}

			else
			{
				nCountingPedestrianFalseObjects++;

			}
		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}
	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{
		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{

			Point x1(vehicle[i].x,vehicle[i].y);
			Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));
			rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

		}
		else
		{
			nCountingVehicleFalseObjects++;
		}

	}


}

void Modes :: drawVehiclePedestrianSVM(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,Ptr<SVM> svm)
{
	int nPercentageMatching;
	nCountingPedestrian=0;
	nCountingPedestrianFalseObjects=0;
	nCountingVehicleFalseObjects=0;
	nCountingVehicles=0;
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		Point x1(pedestrian[i].x,pedestrian[i].y);
		Point x2(pedestrian[i].x+pedestrian[i].width,pedestrian[i].y);
		Point x3(pedestrian[i].x,pedestrian[i].y+pedestrian[i].height);
		Point x4((pedestrian[i].x+pedestrian[i].width),(pedestrian[i].y+pedestrian[i].height));
		Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );


		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			Mat image = frame(pedestrian[i]);
			Mat resized;
			Mat grayimage;

			resize(image, resized, Size(32,64), 0, 0, INTER_CUBIC);
			cvtColor(resized, grayimage, CV_RGB2GRAY);

			vector<float> features;
			vector<Point> locations;

			HOGDescriptor hog;
			hog.winSize =  Size(32,64);
			hog.blockSize=cv::Size(8,8);
			hog.blockStride=cv::Size(4, 4);
			hog.cellSize=cv::Size(4,4 );
			hog.L2HysThreshold= 2.0000000000000001e-01;
			hog.nbins=9;
			hog.gammaCorrection = 0;
			hog.derivAperture=1;
			hog.winSigma=4.0;
			hog.nlevels=20;
			hog.histogramNormType=0;

			hog.compute( resized, features, Size( 8, 8 ), Size( 0,0), locations );

			Mat test_data(features.size(),1,CV_32FC1);
			Mat test_data_tranpose;
			cv::transpose(test_data, test_data_tranpose);
			int nPrediction=svm->predict(test_data_tranpose);
			if(nPrediction==-1)
			{
				ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar(0,255,255), 2, 8, 0 );
			}

			else
			{
				ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 255, 0 ), 2, 8, 0 );
			}

		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}

	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{

		Point x1(vehicle[i].x,vehicle[i].y);
		Point x2(vehicle[i].x+vehicle[i].width,vehicle[i].y);
		Point x3(vehicle[i].x,vehicle[i].y+vehicle[i].height);
		Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));


		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{
			Point x1(vehicle[i].x,vehicle[i].y);
			Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));
			rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

		}
		else
		{
			nCountingVehicleFalseObjects++;
		}

	}
}

void Modes :: drawSVMHistogram(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,Point aROIPolygone[],int &nSizeofROIPolygone,bool &bBountingBoxInside,int nHistogramChannels[],Mat& xTemplateHistogram,MatND& xcropedImageHistogram,int nHistogramSize[],const float* fHistogramRanges[],Ptr<SVM> svm)
{
	nCountingPedestrian=0;
	nCountingPedestrianFalseObjects=0;
	nCountingVehicleFalseObjects=0;
	nCountingVehicles=0;
	int nPercentageMatching;
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		Mat src1 = frame(pedestrian[i]);
		calcHist( &src1, 1, nHistogramChannels, Mat(),
				xcropedImageHistogram, 2, nHistogramSize, fHistogramRanges,
				true,
				false );

		Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );
		nPercentageMatching=compareHist(xTemplateHistogram,xcropedImageHistogram,CV_COMP_CORREL)*100;
		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			if(nPercentageMatching>25)
			{
				Mat image = frame(pedestrian[i]);
				Mat resized;
				Mat grayimage;

				resize(image, resized, Size(32,64), 0, 0, INTER_CUBIC);
				cvtColor(resized, grayimage, CV_RGB2GRAY);

				vector<float> features;
				vector<Point> locations;

				HOGDescriptor hog;
				hog.winSize =  Size(32,64);
				hog.blockSize=cv::Size(8,8);
				hog.blockStride=cv::Size(4, 4);
				hog.cellSize=cv::Size(4,4 );
				hog.L2HysThreshold= 2.0000000000000001e-01;
				hog.nbins=9;
				hog.gammaCorrection = 0;
				hog.derivAperture=1;
				hog.winSigma=4.0;
				hog.nlevels=20;
				hog.histogramNormType=0;

				hog.compute( resized, features, Size( 8, 8 ), Size( 0,0), locations );

				Mat test_data(features.size(),1,CV_32FC1);
				Mat test_data_tranpose;
				cv::transpose(test_data, test_data_tranpose);
				int nPrediction=svm->predict(test_data_tranpose);
				if(nPrediction==-1)
				{
					ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar(0,255,255), 2, 8, 0 );
				}

				else
				{
					ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 255, 0 ), 2, 8, 0 );
				}
			}

			else
			{
				nCountingPedestrianFalseObjects++;

			}
		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}
	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{
		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{

			Point x1(vehicle[i].x,vehicle[i].y);
			Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));
			rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);

		}
		else
		{
			nCountingVehicleFalseObjects++;
		}





	}
}


void Modes :: checkAppMode(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,Point aHighwayROIPolygone[],int &nSizeofHighwayROIPolygone,bool &bHighwayROIBountingBoxInside,void* Data,Point aCityROIPolygone[],int &nSizeofCityROIPolygone,bool &bCityROIBountingBoxInside,int nHistogramChannels[],Mat& xTemplateHistogram,MatND& xcropedImageHistogram,int nHistogramSize[],const float* fHistogramRanges[])
{
	int nPercentageMatching;
	nCountingPedestrian=0;
	nCountingPedestrianFalseObjects=0;
	nCountingVehicleFalseObjects=0;
	nCountingVehicles=0;
	ThreadParam* Pass = (ThreadParam*) Data;
	for( size_t i = 0; i < pedestrian.size(); i++ )
	{
		Point x1(pedestrian[i].x,pedestrian[i].y);
		Point x2(pedestrian[i].x+pedestrian[i].width,pedestrian[i].y);
		Point x3(pedestrian[i].x,pedestrian[i].y+pedestrian[i].height);
		Point x4((pedestrian[i].x+pedestrian[i].width),(pedestrian[i].y+pedestrian[i].height));
		Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );

		Mat src1 = frame(pedestrian[i]);
		calcHist( &src1, 1, nHistogramChannels, Mat(),
				xcropedImageHistogram, 2, nHistogramSize, fHistogramRanges,
				true,
				false );

		nPercentageMatching=compareHist(xTemplateHistogram,xcropedImageHistogram,CV_COMP_CORREL)*100;

		bHighwayROIBountingBoxInside=isInROI(x1,x2,x3,x4,aHighwayROIPolygone,nSizeofHighwayROIPolygone);
		bCityROIBountingBoxInside=isInROI(x1,x2,x3,x4,aCityROIPolygone,nSizeofCityROIPolygone);
		int roiXpoint=pedestrian[i].y;
		if(roiXpoint > ROIHeight)
		{
			if(nPercentageMatching>25)
			{
				if(bCityROIBountingBoxInside)//red
				{
					ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
					Pass->m_nNoofpedestrianinRedROI++;
				}

				else if(bHighwayROIBountingBoxInside)//yellow
				{
					ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 255,255 ), 2, 8, 0 );
					Pass->m_nNoofpedestrianinYellowROI++;
				}

				if((pedestrian[i].x + (pedestrian[i].width/2)) >= (Pass->m_nScreenWidth/2))
				{
					Pass->m_nPedestrianRightCount++;
				}
				else
				{
					Pass->m_nPedestrianLeftCount++;
				}

			}
			else
			{
				nCountingPedestrianFalseObjects++;
			}

		}
		else
		{
			nCountingPedestrianFalseObjects++;
		}

	}

	for( size_t i = 0; i < vehicle.size(); i++ )
	{

		Point x1(vehicle[i].x,vehicle[i].y);
		Point x2(vehicle[i].x+vehicle[i].width,vehicle[i].y);
		Point x3(vehicle[i].x,vehicle[i].y+vehicle[i].height);
		Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));

		bHighwayROIBountingBoxInside=isInROI(x1,x2,x3,x4,aHighwayROIPolygone,nSizeofHighwayROIPolygone);
		bCityROIBountingBoxInside=isInROI(x1,x2,x3,x4,aCityROIPolygone,nSizeofCityROIPolygone);
		int roiXpoint=vehicle[i].y;
		if(roiXpoint > ROIHeight)
		{

			if(bCityROIBountingBoxInside)
			{
				rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);
				Pass->m_nNoofVehicleinRedROI++;
			}

			else if(bHighwayROIBountingBoxInside)
			{
				rectangle(frame,x1,x4, Scalar(0,255,255), 2);
				Pass->m_nNoofVehicleinYellowROI++;
			}
		}

		else
		{
			nCountingVehicleFalseObjects++;
		}

		if((vehicle[i].x + (vehicle[i].width/2)) <= (Pass->m_nScreenWidth/2))
		{
			Pass->m_nVehicleLeftCount++;
		}
		else
		{
			Pass->m_nVehicleRightCount++;
		}
	}
}



void Modes :: checkAppModeOverlay(Mat& frame,std::vector<Rect> vehicle,std::vector<Rect> pedestrian,
		void *globalData,bool bOverlay)
{
	ThreadParam *Pass = (ThreadParam *)globalData;


	int nPercentageMatching=0;
	int nCountingVehicleFalseObjects=0;
	int nCountingPedestrianFalseObjects=0;

	Point axHighwayROIPolygone[10];
	Point axCityROIPolygone[8];

	bool bHighwayROIBountingBoxInside;
	bool bCityROIBountingBoxInside;

	int nSizeofHighwayROIPolygone;
	int nSizeofCityROIPolygone;

	Mat detectedROI;
	std::vector<Rect> noLicenseplates;

	lineconfiguration(frame,Pass->m_nEndROIy,Pass->m_nleftendx,Pass->m_nrightendx,axHighwayROIPolygone,
			axCityROIPolygone, Pass);

	nSizeofHighwayROIPolygone = sizeof(axHighwayROIPolygone)/sizeof(axHighwayROIPolygone[0]);
	nSizeofCityROIPolygone = sizeof(axCityROIPolygone)/sizeof(axCityROIPolygone[0]);

	if(!bOverlay)
	{
		Mat xSourceImage,xcropedImage;
		MatND xTemplateHistogram,xcropedImageHistogram;

		int nHistogramSize[] = {30, 32};
		float hranges[] = { 0, 180 };
		float sranges[] = { 0, 256 };
		const float* fHistogramRanges[] = { hranges, sranges };

		int nHistogramChannels[] = {0, 1};

		xSourceImage=imread("template.jpg");
		calcHist( &xSourceImage, 1, nHistogramChannels, Mat(),
				xTemplateHistogram, 2, nHistogramSize, fHistogramRanges,
				true,
				false );



		for( size_t i = 0; i < pedestrian.size(); i++ )
		{
			Point x1(pedestrian[i].x,pedestrian[i].y);
			Point x2(pedestrian[i].x+pedestrian[i].width,pedestrian[i].y);
			Point x3(pedestrian[i].x,pedestrian[i].y+pedestrian[i].height);
			Point x4((pedestrian[i].x+pedestrian[i].width),(pedestrian[i].y+pedestrian[i].height));
			Point center( pedestrian[i].x + pedestrian[i].width/2, pedestrian[i].y + pedestrian[i].height/2 );

			Mat src1 = frame(pedestrian[i]);
			calcHist( &src1, 1, nHistogramChannels, Mat(),
					xcropedImageHistogram, 2, nHistogramSize, fHistogramRanges,
					true,
					false );

			nPercentageMatching=compareHist(xTemplateHistogram,xcropedImageHistogram,CV_COMP_CORREL)*100;

			bHighwayROIBountingBoxInside=isInROI(x1,x2,x3,x4,axHighwayROIPolygone,nSizeofHighwayROIPolygone);
			bCityROIBountingBoxInside=isInROI(x1,x2,x3,x4,axCityROIPolygone,nSizeofCityROIPolygone);
			int roiXpoint=pedestrian[i].y;
			if(roiXpoint > Pass->m_nHeightROI)
			{
				if(nPercentageMatching>25)
				{
					if(bCityROIBountingBoxInside)//red
					{
						if(Pass->ndisplayVideo)
						{

							ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 0, 255 ), 2, 8, 0 );
						}

						Pass->m_nNoofpedestrianinRedROI++;
					}

					else if(bHighwayROIBountingBoxInside)//yellow
					{
						if(Pass->ndisplayVideo)
						{

							ellipse( frame, center, Size( pedestrian[i].width/2, pedestrian[i].height/2), 0, 0, 360, Scalar( 0, 255,255 ), 2, 8, 0 );
						}

						Pass->m_nNoofpedestrianinYellowROI++;
					}

					if((pedestrian[i].x + (pedestrian[i].width/2)) >= (Pass->m_nScreenWidth/2))
					{
						Pass->m_nPedestrianRightCount++;
					}
					else
					{
						Pass->m_nPedestrianLeftCount++;
					}

				}
				else
				{
					nCountingPedestrianFalseObjects++;
				}

			}
			else
			{
				nCountingPedestrianFalseObjects++;
			}

		}
	}

	else
	{
		for( size_t i = 0; i < vehicle.size(); i++ )
		{

			Point x1(vehicle[i].x,vehicle[i].y);
			Point x2(vehicle[i].x+vehicle[i].width,vehicle[i].y);
			Point x3(vehicle[i].x,vehicle[i].y+vehicle[i].height);
			Point x4((vehicle[i].x+vehicle[i].width),(vehicle[i].y+vehicle[i].height));

			bHighwayROIBountingBoxInside=isInROI(x1,x2,x3,x4,axHighwayROIPolygone,nSizeofHighwayROIPolygone);
			bCityROIBountingBoxInside=isInROI(x1,x2,x3,x4,axCityROIPolygone,nSizeofCityROIPolygone);
			int roiXpoint=vehicle[i].y;
			if(roiXpoint > Pass->m_nHeightROI)
			{
					if(bCityROIBountingBoxInside)
					{
						rectangle(frame,x1,x4, Scalar( 0, 0, 255 ), 2);
						Pass->m_nNoofVehicleinRedROI++;
					}

					else if(bHighwayROIBountingBoxInside)
					{
						rectangle(frame,x1,x4, Scalar(0,255,255), 2);
						Pass->m_nNoofVehicleinYellowROI++;
					}
			}

			else
			{
				nCountingVehicleFalseObjects++;
			}

			if((vehicle[i].x + (vehicle[i].width/2)) <= (Pass->m_nScreenWidth/2))
			{
				Pass->m_nVehicleLeftCount++;
			}
			else
			{
				Pass->m_nVehicleRightCount++;
			}
		}
	}



}


void Modes :: lineconfiguration(Mat& frame,int nROIend,int nleftxend,
		int nrightxend, int highwaymode)
{

	cv::Point2f xHighwayModeLeftRegionStart(1,g_nFrameHeight);
	cv::Point2f xHighwayModeRightRegionStart(g_nFrameWidth,g_nFrameHeight);

	cv::Point2f xCityModeLeftRegionStart(1,g_nFrameHeight);
	cv::Point2f xCityModeRightRegionStart(g_nFrameWidth-1,g_nFrameHeight);

	cv::Point2f xHighwayModeLeftRegionEnd;
	cv::Point2f xHighwayModeRightRegionEnd;

	cv::Point2f xCityModeLeftRegionEnd;
	cv::Point2f xCityModeRightRegionEnd;

	cv::Point2f xHighwayModeLeftRegionStartalternate(1,(g_nFrameHeight-70));
	cv::Point2f xHighwayModeRightRegionStartalternate(g_nFrameWidth,(g_nFrameHeight-70));

	int nHighwayROIincrement=0;

	if(highwaymode==1)
	{
		nHighwayROIincrement=20;
	}


	xHighwayModeLeftRegionEnd.x = nleftxend;
	xHighwayModeLeftRegionEnd.y = nROIend-nHighwayROIincrement;
	xHighwayModeRightRegionEnd.x=  nrightxend;
	xHighwayModeRightRegionEnd.y = nROIend-nHighwayROIincrement;


	line(frame,xHighwayModeLeftRegionStart,xHighwayModeLeftRegionStartalternate,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionStartalternate,xHighwayModeLeftRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeRightRegionStart,xHighwayModeRightRegionStartalternate,Scalar(0,255,255),2);
	line(frame,xHighwayModeRightRegionStartalternate,xHighwayModeRightRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionEnd,xHighwayModeRightRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionStart,xHighwayModeRightRegionStart,Scalar(0,255,255),2);

	int nRedROIIncrement=20;

	xCityModeLeftRegionEnd.x =  (int)round(xHighwayModeLeftRegionEnd.x);
	xCityModeLeftRegionEnd.y =  (int)round(xHighwayModeLeftRegionEnd.y+nRedROIIncrement+nHighwayROIincrement);
	xCityModeRightRegionEnd.x=  (int)round(xHighwayModeRightRegionEnd.x);
	xCityModeRightRegionEnd.y = (int)round(xHighwayModeRightRegionEnd.y+nRedROIIncrement+nHighwayROIincrement);

	line(frame,xHighwayModeLeftRegionStart,xCityModeLeftRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xHighwayModeRightRegionStart,xCityModeRightRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xCityModeLeftRegionEnd,xCityModeRightRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xHighwayModeLeftRegionStart,xHighwayModeRightRegionStart,Scalar( 0, 0, 255 ),2);
}

void Modes :: lineconfiguration(Mat& frame,int nROIend,int nleftxend,
		int nrightxend,Point axHighwayROIPolygone[],Point axCityROIPolygone[], void* Data)
{

	ThreadParam *Pass = (ThreadParam *)Data;
	cv::Point2f xHighwayModeLeftRegionStart(1,480);
	cv::Point2f xHighwayModeRightRegionStart(719,480);

	cv::Point2f xCityModeLeftRegionStart(1,480);
	cv::Point2f xCityModeRightRegionStart(719,480);

	cv::Point2f xHighwayModeLeftRegionEnd;
	cv::Point2f xHighwayModeRightRegionEnd;

	cv::Point2f xCityModeLeftRegionEnd;
	cv::Point2f xCityModeRightRegionEnd;

	cv::Point2f xHighwayModeLeftRegionStartalternate(1,410);
	cv::Point2f xHighwayModeRightRegionStartalternate(719,410);

	if(Pass->mode==2)
	{

		xHighwayModeLeftRegionStartalternate=cv::Point2f (1,385);
		xHighwayModeRightRegionStartalternate=cv::Point2f (719,385);
	}

	int nHighwayROIincrement=0;

	if(Pass->highwaymode == 1)
	{
		nHighwayROIincrement=20;
		xHighwayModeLeftRegionEnd.y = nROIend-nHighwayROIincrement;
		xHighwayModeRightRegionEnd.y = nROIend-nHighwayROIincrement;
		if(xHighwayModeLeftRegionEnd.y<1)
		{
			nHighwayROIincrement=nHighwayROIincrement+xHighwayModeLeftRegionEnd.y;
		}
	}

	xHighwayModeLeftRegionEnd.x = nleftxend;
	xHighwayModeLeftRegionEnd.y = nROIend-nHighwayROIincrement;
	xHighwayModeRightRegionEnd.x=  nrightxend;
	xHighwayModeRightRegionEnd.y = nROIend-nHighwayROIincrement;

	line(frame,xHighwayModeLeftRegionStart,xHighwayModeLeftRegionStartalternate,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionStartalternate,xHighwayModeLeftRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeRightRegionStart,xHighwayModeRightRegionStartalternate,Scalar(0,255,255),2);
	line(frame,xHighwayModeRightRegionStartalternate,xHighwayModeRightRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionEnd,xHighwayModeRightRegionEnd,Scalar(0,255,255),2);
	line(frame,xHighwayModeLeftRegionStart,xHighwayModeRightRegionStart,Scalar(0,255,255),2);

	int nRedROIIncrement=20;
	if(Pass->mode==2)
	{
		nRedROIIncrement=50;
	}

	xCityModeLeftRegionEnd.x =  (int)round(xHighwayModeLeftRegionEnd.x);
	xCityModeLeftRegionEnd.y =  (int)round(xHighwayModeLeftRegionEnd.y+nRedROIIncrement+nHighwayROIincrement);
	xCityModeRightRegionEnd.x=  (int)round(xHighwayModeRightRegionEnd.x);
	xCityModeRightRegionEnd.y = (int)round(xHighwayModeRightRegionEnd.y+nRedROIIncrement+nHighwayROIincrement);

	line(frame,xHighwayModeLeftRegionStart,xCityModeLeftRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xHighwayModeRightRegionStart,xCityModeRightRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xCityModeLeftRegionEnd,xCityModeRightRegionEnd,Scalar( 0, 0, 255 ),2);
	line(frame,xHighwayModeLeftRegionStart,xHighwayModeRightRegionStart,Scalar( 0, 0, 255 ),2);


	Point axHPolygone[]={xHighwayModeLeftRegionStart, xHighwayModeLeftRegionStartalternate,xHighwayModeLeftRegionEnd, xHighwayModeLeftRegionEnd, xHighwayModeRightRegionEnd, xHighwayModeRightRegionEnd,xHighwayModeRightRegionStartalternate, xHighwayModeRightRegionStart, xHighwayModeRightRegionStart, xHighwayModeLeftRegionStart};
	Point axCPolygone[] = {xCityModeLeftRegionStart, xCityModeLeftRegionEnd, xCityModeLeftRegionEnd, xCityModeRightRegionEnd, xCityModeRightRegionEnd, xCityModeRightRegionStart, xCityModeRightRegionStart, xCityModeLeftRegionStart};



	Point b;
	int niterator;
	for(niterator=0;niterator<(sizeof(axHPolygone)/sizeof(b));niterator++)
	{
		axHighwayROIPolygone[niterator]=axHPolygone[niterator];
	}

	for(niterator=0;niterator<(sizeof(axCPolygone)/sizeof(b));niterator++)
	{
		axCityROIPolygone[niterator]=axCPolygone[niterator];
	}

	return;

}

void Modes :: displayBoth(Mat& frame,std::vector<Rect> pedestrian,
		std::vector<Rect> vehicle,int nEndy,int nleftendx,int nrightendx,
		int ROIHeight,bool bshowdetectedPedestrian,
		bool bshowDetectedVehicle,bool bshowDetectedAll,bool bcompareHistogram,
		string templateImage,bool bROIDisplay,
		Ptr<SVM> svm,bool bImageclassification,int nChoice,void* Data)
{
	ThreadParam *Pass = (ThreadParam *)Data;

	int nCountingPedestrianFalseObjects=0;
	int nCountingVehicleFalseObjects=0;
	int	nCountingPedestrian=0;
	int nCountingVehicles=0;

	Point axHighwayROIPolygone[10];
	Point axCityROIPolygone[8];

	int nSizeofHighwayROIPolygone;
	int nSizeofCityROIPolygone;

	lineconfiguration(frame,nEndy,nleftendx,nrightendx,axHighwayROIPolygone,
			axCityROIPolygone, Pass);

	nSizeofHighwayROIPolygone = sizeof(axHighwayROIPolygone)/sizeof(axHighwayROIPolygone[0]);
	nSizeofCityROIPolygone = sizeof(axCityROIPolygone)/sizeof(axCityROIPolygone[0]);

	bool bHighwayROIBountingBoxInside;
	bool bCityROIBountingBoxInside;

	Mat xSourceImage,xcropedImage;
	MatND xTemplateHistogram,xcropedImageHistogram;

	int nHistogramSize[] = {30, 32};
	float hranges[] = { 0, 180 };
	float sranges[] = { 0, 256 };
	const float* fHistogramRanges[] = { hranges, sranges };

	int nHistogramChannels[] = {0, 1};

	if(bcompareHistogram==true)
	{
		xSourceImage=imread(templateImage);
		calcHist( &xSourceImage, 1, nHistogramChannels, Mat(),
				xTemplateHistogram, 2, nHistogramSize, fHistogramRanges,
				true,
				false );
	}

	switch(nChoice)
	{

	case 1 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawPedestrianVehicle(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight);
		break;

	case 2:
		nCountingPedestrianFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawPedestrian(frame,pedestrian,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight);
		break;


	case 3:
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawVehicle(frame,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight);
		break;

	case 4 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawVehiclePedestrianROI(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,bHighwayROIBountingBoxInside,Data);
		break;

	case 5 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawVehiclePedestrianHistogramComparision(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,bHighwayROIBountingBoxInside,nHistogramChannels,xTemplateHistogram,xcropedImageHistogram,nHistogramSize,fHistogramRanges);
		break;

	case 6 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawVehiclePedestrianSVM(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,svm);
		break;

	case 7 :
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		drawSVMHistogram(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,bHighwayROIBountingBoxInside,nHistogramChannels,xTemplateHistogram,xcropedImageHistogram,nHistogramSize,fHistogramRanges,svm);
		break;

	case 8:
		nCountingPedestrianFalseObjects=0;
		nCountingVehicleFalseObjects=0;
		nCountingPedestrian=0;
		nCountingVehicles=0;
		checkAppMode(frame,pedestrian,vehicle,nCountingVehicleFalseObjects,nCountingPedestrianFalseObjects,nCountingPedestrian,nCountingVehicles,ROIHeight,axHighwayROIPolygone,nSizeofHighwayROIPolygone,bHighwayROIBountingBoxInside,Data,axCityROIPolygone,nSizeofCityROIPolygone,bCityROIBountingBoxInside,nHistogramChannels,xTemplateHistogram,xcropedImageHistogram,nHistogramSize,fHistogramRanges);
	}

	stringstream displaypedestrianMessage;
	displaypedestrianMessage<<"Pedestrians - "<<pedestrian.size()-nCountingPedestrianFalseObjects;
	putText(frame,displaypedestrianMessage.str() , Point2f(500,60), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 2);

	stringstream displayvehicleMessage;
	displayvehicleMessage<<"Vehicles     - "<<vehicle.size()-nCountingVehicleFalseObjects;
	putText(frame,displayvehicleMessage.str() , Point2f(500,80), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 2);

	stringstream displayTotalMessage;
	displayTotalMessage<<"Objects     - "<<(vehicle.size()-nCountingVehicleFalseObjects)+(pedestrian.size()-nCountingPedestrianFalseObjects);
	putText(frame,displayTotalMessage.str() , Point2f(500,40), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 2);

}




template <class T>
int Modes :: numDigits(T number)
{
	int digits = 0;
	if (number < 0) digits = 1; // remove this line if '-' counts as a digit
	while (number) {
		number /= 10;
		digits++;
	}
	return digits;
}


int Modes :: strToInt(char *str){

	string tmpStr="";

	for(int i = 0; i <= '9'; i++){

		tmpStr = (char)i;

		if(strcmp(tmpStr.c_str(), str) == 0){

			return i;
		}
		tmpStr="";

	}

	return 0;

}

int deleteALLVideo(ThreadParam *tp)
{

	Mat img = imread("BackGround.jpg");
	namedWindow("delete video", WINDOW_NORMAL);
	cvSetWindowProperty("delete video", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
	putText(img, "RECORDED VIDEOS ARE DELETING........", Point(100, 100),  FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
	imshow("delete video",img);
	waitKey(5000);

	system("sudo rm -rf /home/horusi/recordvideos/*");


	img.release();
	tp->updateMode = 0;
	cvDestroyWindow("delete video");

}




void Modes :: appMode(void* Data)
{
	return;
}



void Modes :: highguiDesign(Mat &guiBackground,int nScreenWidth, int nScreenHeight)
{
	int nFirstRectangleEndx=nScreenWidth/3;
	int nFirstRectangleEndy=nScreenHeight/2;

	int nSecondRectangleEndx=(nScreenWidth/3)+nFirstRectangleEndx;
	int nSecondRectangleEndy=(nScreenHeight/2);

	int nThirdRectangleEndx=(nScreenWidth/3)+nSecondRectangleEndx;
	int nThirdRectangleEndy=nScreenHeight/2;

	cv::Mat roi = guiBackground(cv::Rect(0, 0, nFirstRectangleEndx ,nFirstRectangleEndy));
	Mat overlay;
	double alpha = 0.6;
	guiBackground.copyTo(overlay);

	rectangle( guiBackground, Point( 0, 0 ), Point(nFirstRectangleEndx ,nFirstRectangleEndy), Scalar( 0, 0, 255 ), -1, 4 );
	rectangle( guiBackground, Point(nFirstRectangleEndx , 0 ), Point(nSecondRectangleEndx ,nSecondRectangleEndy), Scalar( 255, 0, 0 ), -1, 4 );
	rectangle( guiBackground, Point( nSecondRectangleEndx, 0 ), Point(nThirdRectangleEndx ,nThirdRectangleEndy), Scalar( 0, 255, 0 ), -1, 4 );

	cv::addWeighted(overlay, alpha, guiBackground, 1 - alpha, 0, guiBackground);

	putText(guiBackground, "UPLOAD", Point((nFirstRectangleEndx/10),nFirstRectangleEndy/3), FONT_HERSHEY_PLAIN, 3.0, CV_RGB(0,255,0), 3);
	putText(guiBackground, "VIDEO", Point(((nFirstRectangleEndx/6)),nFirstRectangleEndy/1.5), FONT_HERSHEY_PLAIN, 3.0, CV_RGB(0,255,0), 3);

	putText(guiBackground, "UPDATE", Point((nFirstRectangleEndx+(nFirstRectangleEndx/10)),nFirstRectangleEndy/3), FONT_HERSHEY_PLAIN, 3.0, CV_RGB(0,255,0), 3);
	putText(guiBackground, "SOFTWARE", Point((nFirstRectangleEndx),nFirstRectangleEndy/1.5), FONT_HERSHEY_PLAIN, 3.0, CV_RGB(0,255,0), 3);
	putText(guiBackground, "EXIT", Point((nSecondRectangleEndx+((nFirstRectangleEndx/6))),nFirstRectangleEndy/2), FONT_HERSHEY_PLAIN, 3, CV_RGB(0,255,0), 3);

	putText(guiBackground,HORUSI_BUILD, Point((nFirstRectangleEndx/2),(nScreenHeight-20)), FONT_HERSHEY_PLAIN, 2, CV_RGB(0,255,0), 3);

}
void uploadVideoCallBackWindow(int event, int x, int y, int flags, void* userdata)
{
	ThreadParam* PassedArguments=(ThreadParam *)userdata;

	if  ( event == EVENT_LBUTTONDOWN )
	{
		PassedArguments->updateMode = 0;
	}

}

int getUploadVideoFolderCount()
{

	FILE *in;

	char buff[SIZE];

	char cmd[SIZE]= "ls /home/horusi/horus-i/UploadVideos -l | wc -l";

	if(!(in = popen(cmd, "r"))){
		cout << "popen is fail in getVieoId" << endl;
		exit(0);
	}

	while(fgets(buff, sizeof(buff), in)!=NULL){}


	string videoCountStr;

	pclose(in);

	for(int i = 0; buff[i] != '\0'; i++){

		if(buff[i] != '\n'){
			videoCountStr += buff[i] ;
		}else{
			break;
		}
	}

	return (atoi(videoCountStr.c_str()));

}

int Modes :: getVideoCount()
{

	FILE *in;
	char buff[SIZE];

	char cmd[SIZE]= "ls  /home/horusi/recordvideos/ -l | wc -l";

	if(!(in = popen(cmd, "r"))){
		cout << "popen is fail in getVideoId" << endl;
		exit(0);
	}

	string videoCountStr;

	while(fgets(buff, sizeof(buff), in)!=NULL){}

	cout << "VIDECOUNT IN GETVIDEOCOUNT " << buff<< endl;
	pclose(in);

	return (atoi(buff));

}

string Modes :: getUploadid(ThreadParam *tp)
{

	cout << "Enter into upload Video Mode " << endl;
	Mat img = imread("BackGround.jpg");


	char videoFilePath[SIZE];


	int videoCount = getVideoCount();

	/// if there is no videos recorded
	if(videoCount == 1){

		cout <<"there is no video found" << endl;
		Mat img = imread("BackGround.jpg");
		namedWindow("upload video", WINDOW_NORMAL);
		cvSetWindowProperty("upload video", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
		putText(img, "THERE IS NO VIDEO . PLEASE RECORD VIDEOS", Point(100, 100),  FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
		imshow("upload video",img);
		waitKey(5000);
		cvDestroyWindow("upload video");
		img.release();
		tp->updateMode = 0;
		return "NULL";
	}

	//int uploadId =  getUploadVideoFolderCount();

	int uploadId =  tp->getHighestVideoFileId();

	sprintf(videoFilePath, "/home/horusi/recordvideos/%d.avi", uploadId);

	string checkSum = tp->getCheckSumOfLastRecoredVideo(videoFilePath);

	return checkSum;
}

void Modes :: createFolderInServer(string uploadId, string macAdd)
{
	char cmd[SIZE];
	char cmd1[SIZE];
	char buff[SIZE];

	Mat img = imread("./BackGround.jpg");

	namedWindow("upload video", WINDOW_NORMAL);

	cvSetWindowProperty("upload video", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);

	putText(img, "Please wait videos are going to upload..." , Point(100, 100),FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);

	imshow("upload video",img);

	waitKey(100);

	FILE *in;

	sprintf(cmd, "mkdir /tmp/%s-%s", macAdd.c_str(), uploadId.c_str());
	system(cmd);


	sprintf(cmd1, "sudo scp -i /tmp/identity.pem -r /tmp/%s-%s/ ubuntu@ec2-35-165-233-252.us-west-2.compute.amazonaws.com:/home/ubuntu/uploadVideos/",macAdd.c_str(), uploadId.c_str() );

	cout << cmd1  << endl;


	if(!(in = popen(cmd1, "w"))){
		return ;
	}

	while(fgets(buff, sizeof(buff), in)!=NULL){
		cout << buff;
	}

	pclose(in);
	img.release();
}

void Modes :: uploadFile(int vidCount,string macAdd,string uploadId)
{
	FILE *in;
	char buff[SIZE];
	char cmd[SIZE];


	sprintf(cmd, "sudo scp -i /tmp/identity.pem -r /home/horusi/recordvideos/%d.avi ubuntu@ec2-35-165-233-252.us-west-2.compute.amazonaws.com:/home/ubuntu/uploadVideos/%s-%s/",vidCount, macAdd.c_str(), uploadId.c_str());

	cout << cmd  << endl;

	if(!(in = popen(cmd, "w"))){
		return ;
	}

	while(fgets(buff, sizeof(buff), in)!=NULL){
		cout << buff;
	}

	pclose(in);


}
int Modes :: checkVideoFile(int videoCount)
{
	VideoCapture capture;
	char vidFile[SIZE];

	sprintf(vidFile, "/home/horusi/recordvideos/%d.avi",videoCount);

	//cout << "vidFile :: :"  << vidFile << endl;

	capture.open(vidFile);

	if (!capture.isOpened()){

		return VIDEOOPENINGERROR;

	}else{
		return SUCCESS;
	}


}

void Modes :: uploadVideoOneAfterAnother(string uploadId, string macAdd, ThreadParam *globalData)
{


	char cmd[SIZE];
	char displyMSG[SIZE];
	char removeVideoCmd[SIZE];

	createFolderInServer(uploadId, macAdd);

	Mat img = imread("./BackGround.jpg");

	Mat deleteVideoShow;

	Mat uploadVideoShow;


	int lowestVidoeCount = globalData->getLowestVideoFileId();

	int highestVideoCount = globalData->getHighestVideoFileId();

	cout << "LOWEST COUNT ::" << lowestVidoeCount << endl;

	cout << "HIGHEST COUNT ::" << highestVideoCount << endl;

	for(int vidCount = lowestVidoeCount; vidCount <= highestVideoCount; vidCount++){


		int rs = checkVideoFile(vidCount);
		if(rs != SUCCESS){
			continue;
		}

		img.copyTo(uploadVideoShow);
		img.copyTo(deleteVideoShow);


		sprintf(displyMSG, "%d.avi VIDEO UPLOADING", vidCount);

		putText(uploadVideoShow, displyMSG , Point(100, 100),FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);

		imshow("upload video",uploadVideoShow);

		waitKey(100);

		/// Upload each file into server
		uploadFile(vidCount, macAdd, uploadId);

		sprintf(displyMSG, "%d.avi VIDEO DELETING", vidCount);

		putText(deleteVideoShow, displyMSG , Point(100, 100),FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);

		imshow("upload video",deleteVideoShow);

		waitKey(3000);

		sprintf(removeVideoCmd, "sudo rm -rf /home/horusi/recordvideos/%d.avi", vidCount);

		system(removeVideoCmd);

	}

	cvDestroyWindow("upload video");

	sprintf(cmd, "sudo rm -rf  /tmp/%s-%s", macAdd.c_str(), uploadId.c_str());

	cout <<"REMOVE CMD :: " <<  cmd << endl;
	/// Remove create empty directory
	system(cmd);

	deleteVideoShow.release();
	uploadVideoShow.release();
	img.release();

}
void Modes :: uploadVideo(ThreadParam *tp)
{
	pthread_cond_signal(&condWifiStatus);
	pthread_cond_wait( &condWifiStatus, &mutexWifiStatus );

	if(tp->networkCheck == true){

		string uploadId	= 	getUploadid(tp);

		if(strcmp(uploadId.c_str(), "NULL") == 0){
			cout << "THERE is no vidoes recorded" << endl;
			return ;
		}

		cout << "UPLOAD ID :: " << uploadId << endl;


		FILE *xMacaddressfilepointer;
		char cMacaddress[256];
		if(!(xMacaddressfilepointer = popen("ifconfig | grep HWaddr |cut -d\\  -f11|grep :", "r"))){
			return ;
		}

		while(fgets(cMacaddress, sizeof(cMacaddress), xMacaddressfilepointer)!=NULL){

		}
		pclose(xMacaddressfilepointer);
		string temp;

		for(int i=0;cMacaddress[i] != '\0' ;i++)
		{
			if(cMacaddress[i] != '\n')
			{
				if(cMacaddress[i] != ':'){

					temp += cMacaddress[i];

				}else{
					temp += '-';
				}
			}
			else
			{
				break;
			}
		}
		cout<<"MAC :: " << temp<<endl;

		ofstream file("/tmp/identity.pem");
		if (file.is_open())
		{
			file << "-----BEGIN RSA PRIVATE KEY-----\n";
			file << "MIIEpAIBAAKCAQEAlpbNkXFJoXeuG44rGMEpBRBMZqu6GEvBn995+BSef6JCtmxsS9wou58S74CY\n";
			file << "RemFWsfwIt2JHT67Pzep7/o65dnYjNY6D+4Y043Ka5edi5hDqve86LvSyf10J0aUcbe9Cm55ceDv\n";
			file << "GfC8/1jw8qHWatxQSfDLoGAfl7M4I7OUy+DTmpD4jK6CxNLOm72ILkGXeAu23ghBDbjkEwJU0T9p\n";
			file << "LA1tWo0Tll1s0mqzXrsM/nJ8x8fTSiepPzqp3Li7LbajvJfVx93T1+njhzzc7k/t234CzACxZhnt\n";
			file << "S+0t0WD94woOXx/kWeK4yIeh71DXc+6uuBVKJMal+GIDvGd9F4Q1NwIDAQABAoIBAFeIBKl73j66\n";
			file << "4DsoIijbbkqBNMehHiStNDkHn0/yPEcYPArpbvGRYSPdzRXl+5z3pgokmZLKjr6vDgwrAN565u1f\n";
			file << "+R20ED/eOBQQIQ71LCBOO1cPdYEaW+YJKxEBV5vaH0oG+RSWmKTNaC5MtpFyPL4UnZ69Fr974CE/\n";
			file << "jWxDIER42YHEs/fxq++rxDR40+e8DMZnQHY4TcEH5sy7rFc3PzMm6DIa9YvHuOlGg0E0QGcGq/Na\n";
			file << "E46jOUogYCCi6Uqnq4gMNL29yu96YeNgeqkF8JOz/c1IVtQPfp/lGVkI26FuiyrLoSjy/O/8DjYV\n";
			file << "tCnTqVuoFoefdeAhpUOtDBVG3uECgYEA+2tso6QGP4OKXE4A+luZKuEU8So6TI89xUJbmUzyIiLt\n";
			file << "LESaD2sny9whTto1BHWWdVy1EvEiDcyXf0hVhcEJIsTuh90q5+tHPEJWY6kgRj7cs5/U1MS66mLL\n";
			file << "NP+yzRi0PKgwAvF6gCM8H3BHjFcj9vtIPESBZdQ2HeugZvD4SW8CgYEAmVUfiQNWxi7HCvVitzBT\n";
			file << "GdII1JWgJnTmdPNWf9JkwVBmYJw2I+Ico2o6TxUC9v/rzS5BTYxVDdtvSNc4R8l9rnOmsQ3GXYcf\n";
			file << "1BTH80JOTTa/br+/Ev6GTn2HydEkNONEHTbG8PRcg/IndhAZeVnJJpJp4D9qWXqw11TQfxdhHLkC\n";
			file << "gYAzBNqX3moSK2xBTObv5vSO+fvY8HvCG3Mqe0vBMRcVjEbaq9UjedgqizILIUaO8BmnGTf5bws9\n";
			file << "B55aiuAn80MaViIdWekiBOGAvelv8dsFxi3dGXsD7iQL+h5IU/cBnZi9klej0ULNi9jgfFVYijpX\n";
			file << "HSjMag5kDosoyS7UlOOdawKBgQCZL/0QgqB34RYEccHM6N+tJTSjRlU49oOjhdT+YPE+XRfbH1XL\n";
			file << "pcQc0y0sAv7yTB6F39doJXJ4JKnaqQJWXgxNdMetjeiHWk9HL/fPpYfbBn5co/6+eEEwO6Ok0miM\n";
			file << "2h0b3rUE1+1x+UTJZC4/GZ+oBJD4dALJIJV6nAatYmsoKQKBgQCW0nCFjQHRT1mDAawVholFTD5u\n";
			file << "vFKljmmbbb4iLJZzw+KMOdgjScnjXnddhX5FjutsG/ijE4o5JTfcYJbXJjxRq1CYEiGvosEUaQQg\n";
			file << "b/WnG3cR0vNTw99rNW/HCZXbDN8H5MocPGnapLlvk7Atm7Hzuw5/CYO/hkOueThsGBR6RA==\n";
			file << "-----END RSA PRIVATE KEY-----\n";
			file.close();
		}


		system("sudo chmod 400 /tmp/identity.pem");

		/// Upload Vidoe One by one to amazon server
		uploadVideoOneAfterAnother( uploadId, temp, tp);

		tp->updateMode = 0;
	}else{
		Mat img = imread("BackGround.jpg", 1);
		namedWindow("WIFI STATUS" , WINDOW_NORMAL);
		cvSetWindowProperty("WIFI STATUS", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
		putText(img, "CHECK YOUR WIFI CONNCTIVITY", Point(100, 100), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
		imshow("WIFI STATUS", img);
		waitKey(3000);
		cvDestroyWindow("WIFI STATUS");
		img.release();
		tp->updateMode = 0;
	}
}
void Modes :: downloadData(const char *cmd)
{
	FILE *in;
	char buff[2048];

	if(!(in = popen(cmd, "w"))){
		return ;
	}
	while(fgets(buff, sizeof(buff), in)!=NULL){
		cout << buff;
	}
	pclose(in);
}

void Modes :: updateSoftware(ThreadParam *tp)
{
	pthread_cond_signal(&condWifiStatus);
	pthread_cond_wait( &condWifiStatus, &mutexWifiStatus );
	if(tp->networkCheck == true){

		cout << "Enter into Software Update Mode " << endl;
		Mat img = imread("BackGround.jpg");
		namedWindow("update software", WINDOW_NORMAL);
		cvSetWindowProperty("update software", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
		Mat resizedFrame;
		resize(img, resizedFrame, Size(720, 480), 0, 0, INTER_CUBIC);
		putText(resizedFrame, "Software is Updating ", Point(100, 100), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
		imshow("update software",resizedFrame);
		waitKey(100);
		ofstream file("/tmp/identity.pem");
		if (file.is_open())
		{
			file << "-----BEGIN RSA PRIVATE KEY-----\n";
			file << "MIIEpAIBAAKCAQEAlpbNkXFJoXeuG44rGMEpBRBMZqu6GEvBn995+BSef6JCtmxsS9wou58S74CY\n";
			file << "RemFWsfwIt2JHT67Pzep7/o65dnYjNY6D+4Y043Ka5edi5hDqve86LvSyf10J0aUcbe9Cm55ceDv\n";
			file << "GfC8/1jw8qHWatxQSfDLoGAfl7M4I7OUy+DTmpD4jK6CxNLOm72ILkGXeAu23ghBDbjkEwJU0T9p\n";
			file << "LA1tWo0Tll1s0mqzXrsM/nJ8x8fTSiepPzqp3Li7LbajvJfVx93T1+njhzzc7k/t234CzACxZhnt\n";
			file << "S+0t0WD94woOXx/kWeK4yIeh71DXc+6uuBVKJMal+GIDvGd9F4Q1NwIDAQABAoIBAFeIBKl73j66\n";
			file << "4DsoIijbbkqBNMehHiStNDkHn0/yPEcYPArpbvGRYSPdzRXl+5z3pgokmZLKjr6vDgwrAN565u1f\n";
			file << "+R20ED/eOBQQIQ71LCBOO1cPdYEaW+YJKxEBV5vaH0oG+RSWmKTNaC5MtpFyPL4UnZ69Fr974CE/\n";
			file << "jWxDIER42YHEs/fxq++rxDR40+e8DMZnQHY4TcEH5sy7rFc3PzMm6DIa9YvHuOlGg0E0QGcGq/Na\n";
			file << "E46jOUogYCCi6Uqnq4gMNL29yu96YeNgeqkF8JOz/c1IVtQPfp/lGVkI26FuiyrLoSjy/O/8DjYV\n";
			file << "tCnTqVuoFoefdeAhpUOtDBVG3uECgYEA+2tso6QGP4OKXE4A+luZKuEU8So6TI89xUJbmUzyIiLt\n";
			file << "LESaD2sny9whTto1BHWWdVy1EvEiDcyXf0hVhcEJIsTuh90q5+tHPEJWY6kgRj7cs5/U1MS66mLL\n";
			file << "NP+yzRi0PKgwAvF6gCM8H3BHjFcj9vtIPESBZdQ2HeugZvD4SW8CgYEAmVUfiQNWxi7HCvVitzBT\n";
			file << "GdII1JWgJnTmdPNWf9JkwVBmYJw2I+Ico2o6TxUC9v/rzS5BTYxVDdtvSNc4R8l9rnOmsQ3GXYcf\n";
			file << "1BTH80JOTTa/br+/Ev6GTn2HydEkNONEHTbG8PRcg/IndhAZeVnJJpJp4D9qWXqw11TQfxdhHLkC\n";
			file << "gYAzBNqX3moSK2xBTObv5vSO+fvY8HvCG3Mqe0vBMRcVjEbaq9UjedgqizILIUaO8BmnGTf5bws9\n";
			file << "B55aiuAn80MaViIdWekiBOGAvelv8dsFxi3dGXsD7iQL+h5IU/cBnZi9klej0ULNi9jgfFVYijpX\n";
			file << "HSjMag5kDosoyS7UlOOdawKBgQCZL/0QgqB34RYEccHM6N+tJTSjRlU49oOjhdT+YPE+XRfbH1XL\n";
			file << "pcQc0y0sAv7yTB6F39doJXJ4JKnaqQJWXgxNdMetjeiHWk9HL/fPpYfbBn5co/6+eEEwO6Ok0miM\n";
			file << "2h0b3rUE1+1x+UTJZC4/GZ+oBJD4dALJIJV6nAatYmsoKQKBgQCW0nCFjQHRT1mDAawVholFTD5u\n";
			file << "vFKljmmbbb4iLJZzw+KMOdgjScnjXnddhX5FjutsG/ijE4o5JTfcYJbXJjxRq1CYEiGvosEUaQQg\n";
			file << "b/WnG3cR0vNTw99rNW/HCZXbDN8H5MocPGnapLlvk7Atm7Hzuw5/CYO/hkOueThsGBR6RA==\n";
			file << "-----END RSA PRIVATE KEY-----\n";
			file.close();
		}
		const char *downloadCommand = "./update.sh";
		downloadData(downloadCommand);
		cvDestroyWindow("update software");
		img.release();
		tp->updateMode = 0;
	}else{
		Mat img = imread("BackGround.jpg", 1);
		namedWindow("WIFI STATUS" , WINDOW_NORMAL);
		cvSetWindowProperty("WIFI STATUS", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
		putText(img, "CHECK YOUR WIFI CONNCTIVITY", Point(100, 100), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
		imshow("WIFI STATUS", img);
		waitKey(5000);
		cvDestroyWindow("WIFI STATUS");
		img.release();
		tp->updateMode = 0;
	}
}

void Modes :: wifiStatus(ThreadParam *tp)
{
	Mat img = imread("BackGround.jpg", 1);
	if(!img.data){
		cout << "image is fail in wifistatus " << endl;
		return;
	}

	pthread_cond_signal(&condWifiStatus);
	pthread_cond_wait( &condWifiStatus, &mutexWifiStatus );


	if(tp->networkCheck == true){
		namedWindow("WIFI STATUS",WINDOW_NORMAL);
		cvSetWindowProperty("WIFI STATUS", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
		FILE *in;
		char buff[2048];
		const char *cmd = "ifconfig | grep \"inet addr\"";

		if(!(in = popen(cmd, "r"))){
			return ;
		}
		string inetAddress = "";
		int count = 0;
		while(fgets(buff, sizeof(buff) - 1, in) != NULL){
			if(count == 0){

				char displayMSG[SIZE];
				string loopBackAddr;
				char *tmp = strstr(buff, ":");
				/// ingnore ':'
				for(int i = 1; tmp[i] != '\0'; i++){
					if(tmp[i] != ' '){

						loopBackAddr += tmp[i];

					}else{
						break;
					}
				}
				sprintf(displayMSG, "LOOP BACK ADDRESS %s", loopBackAddr.c_str());
				putText(img, displayMSG, Point(100, 150),  FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);

			}else{
				char displayMSG[SIZE];
				string ipAddr;
				char *tmp = strstr(buff, ":");
				/// ingnore ':'
				for(int i = 1; tmp[i] != '\0'; i++){
					if(tmp[i] != ' '){

						ipAddr += tmp[i];

					}else{
						break;
					}
				}
				sprintf(displayMSG, "IP ADDRESS  %s", ipAddr.c_str());
				putText(img, displayMSG, Point(100, 200),  FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);


			}
			count++;

		}

		pclose(in);
		putText(img, "WIFI Connected", Point(100, 100), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
		imshow("WIFI STATUS",img);
		waitKey(5000);



	}else{
		namedWindow("WIFI STATUS",WINDOW_NORMAL);
		cvSetWindowProperty("WIFI STATUS", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
		FILE *in;
		char buff[2048];
		const char *cmd = "ifconfig | grep \"inet addr\"";

		if(!(in = popen(cmd, "r"))){
			return ;
		}
		string inetAddress = "";
		int count = 0;
		while(fgets(buff, sizeof(buff) - 1, in) != NULL){
			if(count == 0){
				putText(img, buff, Point(1, 150),  FONT_HERSHEY_COMPLEX, 0.7, CV_RGB(255,255,255), 2);

			}else{
				putText(img, buff, Point(1, 200),  FONT_HERSHEY_COMPLEX, 0.7, CV_RGB(255,255,255), 2);

			}
			count++;

		}

		pclose(in);
		putText(img, "WIFI Connected", Point(100, 100),  FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
		imshow("WIFI STATUS",img);
		waitKey(3000);

	}

	cvDestroyWindow("WIFI STATUS");
	img.release();
	tp->updateMode = 0;
}

void Modes :: update(ThreadParam *tp)
{
	tp->cloudeModeFlag = true;
	namedWindow("Update Window", WINDOW_NORMAL);
	cvSetWindowProperty("Update Window", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
	setMouseCallback("Update Window", guiUpdateFunctionCall, tp);

	tp->updateMode = 0;

	while(1)
	{
		switch(tp->updateMode)
		{
		case 1 :
			uploadVideo(tp);
			break;

		case 2 :
			updateSoftware(tp);
			break;

		case 3 :
			wifiStatus(tp);
			break;

		case 4 :
			deleteALLVideo(tp);
			break;
		case 5:
			cout << "Exit from cloud " << endl;
			cvDestroyWindow("Update Window");
			tp->mode = 0;
			tp->cloudeModeFlag = false;
			return;

		}
		imshow("Update Window", tp->m_xGuiUpdateBackground);
		waitKey(1000);
	}

}
void Modes :: processMode(ThreadParam &tp)
{

	tp.cloudeModeFlag = false;

	Recordmode recordMode;
	Playbackmode playback;
	Settingmode settingmode;

	Demo demo;

	while(1)
	{
		switch(tp.mode)
		{
		case 1 :
			pthread_cond_signal(&condAppmodeSignal);
		        pthread_cond_wait( &condAppmodeStopSignal, &mutexAppmodeStopSignalAcess );
			break;
		case 2:
			demo.demoMode(&tp);
			break;
		case 3:
			playback.playBackMode(&tp);
			break;
		case 4:
			recordMode.recordMode(&tp);
			break;
		case 5:
			settingmode.settingMode(&tp);
			break;
		case 6:
			update(&tp);
			break;

		}
		imshow("Gui Window", tp.m_xGuiBackground);
		waitKey(1000);
	}
}
