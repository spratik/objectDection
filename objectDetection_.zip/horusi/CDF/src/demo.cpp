/*
 * demo.cpp
 *
 *  Created on: May 23, 2017
 *      Author: pratik
 */

#include "demo.h"
#include "overlay.h"

void demoCallBackWindow(int event, int x, int y, int flags, void* userdata)
{
	ThreadParam* PassedArguments=(ThreadParam *)userdata;

	if  ( event == EVENT_LBUTTONDOWN )
	{
		PassedArguments->mode=0;

	}
}


void Demo :: demoMode(void *Data)
{
	ThreadParam* Pass = (ThreadParam*) Data;
	overlayvariables overlaydata;
	Mat axBlankBackground;
	Mat axErrorWindow;
	Mat frame;
	Mat resizedFrame;
	Mat  resizedRotatedFrame;
	overlaydata.BackgroundImage.copyTo(axBlankBackground);
	putText(axBlankBackground, "Loading ", Point(((Pass->m_nScreenWidth/2)-75), Pass->m_nScreenHeight/2.5), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
	namedWindow("Demo Window",WINDOW_NORMAL);
	cvSetWindowProperty("Demo Window", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
	setMouseCallback("Demo Window", demoCallBackWindow, Pass);
	imshow("Demo Window",axBlankBackground);
	waitKey(1);
	overlaydata.BackgroundImage.copyTo(axErrorWindow);
	putText(axErrorWindow, "Demo.avi file cannot open ", Point(((Pass->m_nScreenWidth/2)-240), Pass->m_nScreenHeight/2.5), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);

	VideoCapture capture;
	capture.open("demo.avi");


	stringstream displayHoruseye;
	stringstream displayMode;

	displayHoruseye<<"HORUS-i";
	displayMode<<"DEMO MODE";

	if ( ! capture.isOpened() )
	{
		imshow("Demo Window",axErrorWindow);
		waitKey(2000);

		cvDestroyWindow("Demo Window");
		capture.release();
		Pass->mode=0;
		return;
	}

	CascadeClassifier vehicle,pedestrian ;

	if( !vehicle.load("cardemo.xml") )
	{
		printf("--(!)Error loading pedestrian cascade\n");
		return;
	}

	if( !pedestrian.load("pedestriandemo.xml") )
	{
		printf("--(!)Error loading pedestrian cascade\n");
		return;
	}

	vector<Rect> axVehicleDetectedObjects, axPedestrianDetectedObjects;

	while((capture.read(frame)) && (Pass->mode==2))
	{

		if( frame.empty())
		{
			printf(" --(!) No captured frame -- Break!");
			break;
		}

		resize(frame, resizedFrame, Size(720, 480), 0, 0, INTER_CUBIC); // resize to 1024x768 resolution
		cv::Point2f center(resizedFrame.cols/2.0F, resizedFrame.rows/2.0F);
		cv::Mat rotateMatrix = cv::getRotationMatrix2D(center, 180, 1.0);
		warpAffine(resizedFrame,resizedRotatedFrame, rotateMatrix, resizedFrame.size() );

		pedestrian.detectMultiScale(
				resizedRotatedFrame,
				axPedestrianDetectedObjects,
				1.03,
				5,
				0,
				Size(16, 16));

		vehicle.detectMultiScale(
				resizedRotatedFrame,
				axVehicleDetectedObjects,
				1.1,
				6,
				0,
				Size(24, 24));

		Pass->drawDetection(resizedRotatedFrame,axPedestrianDetectedObjects,
				axVehicleDetectedObjects,300,320,370,200,
				Pass->m_bShowDetectedPedestrian,Pass->m_bShowDetectedVehicle,Pass->m_bShowDetectedAll,
				true,Pass->m_sHistogramTemplateImage,Pass->m_bShowROIelemination,
				Pass->m_pSvm,Pass->m_bImageclassification,8,Pass);


		putText(resizedRotatedFrame,displayHoruseye.str() , Point2f(100,40), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 2);
		putText(resizedRotatedFrame,displayMode.str() , Point2f(100,60), FONT_HERSHEY_PLAIN, 1, Scalar(0,255,255), 2);

		imshow("Demo Window", resizedRotatedFrame);

		char sKeyboardInterrupt;
		sKeyboardInterrupt = (char) waitKey(1);
		if (sKeyboardInterrupt == 112)
		{
			Mat passFrame;
			resizedFrame.copyTo(passFrame);
			Pass->pauseFunction(frame,passFrame,Pass);

		}

		waitKey(1);
	}

	Pass->mode = 0;

	cvDestroyWindow("Demo Window");
	capture.release();
}
