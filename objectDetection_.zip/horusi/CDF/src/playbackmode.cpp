/*
 * playbackmode.cpp
 *
 *  Created on: 22-May-2017
 *      Author: horusi
 */

#include "playbackmode.h"
#include "overlay.h"


void  playbackCallBackWindow(int event, int x, int y, int flags, void* userdata)
{
	ThreadParam* Pass=(ThreadParam *)userdata;

	int nFirstRectangleStartx=0;
	int nFirstRectangleStarty=(Pass->m_nScreenHeight/5.5)+35;

	int nFirstRectangleEndx=nFirstRectangleStartx+(Pass->m_nScreenWidth/7);
	int nFirstRectangleEndy=nFirstRectangleStarty+(Pass->m_nScreenHeight/5.5);

	int nSecondRectangleEndx=nFirstRectangleEndx;
	int nSecondRectangleEndy=nFirstRectangleEndy+(Pass->m_nScreenHeight/5.5);

	int nThirdRectangleEndx=nSecondRectangleEndx;
	int nThirdRectangleEndy=nSecondRectangleEndy+(Pass->m_nScreenHeight/5.5);

	if  ( event == EVENT_LBUTTONDOWN )
	{

		if((x<nFirstRectangleEndx) && (y>nFirstRectangleStarty) && (y<nFirstRectangleEndy))
		{

			cout<<"move to next video"<<endl;

			Pass->lowestVideoFileId++;

			if(Pass->lowestVideoFileId > Pass->highestVideoFileId){
				Pass->lowestVideoFileId = 1;
			}

			if(Pass->lowestVideoFileId != 0){
				--Pass->lowestVideoFileId;
			}


			Pass->m_bPlaybackFileChangingFlag=true;
		}

		else if((x<nFirstRectangleEndx) && (y>nFirstRectangleEndy) && (y<nSecondRectangleEndy))
		{
			cout<<"Run Analysis"<<endl;

			if(Pass->m_bPlayBackAnalysisToggle)
			{
				Pass->m_bPlayBackAnalysisToggle=false;
			}
			else
			{
				Pass->m_bPlayBackAnalysisToggle=true;
			}
		}

		else if((x<nFirstRectangleEndx) && (y>nSecondRectangleEndy) && (y<nThirdRectangleEndy))
		{
			cout<<"Play Previous video"<<endl;

			if(Pass->lowestVideoFileId  == 1){

				Pass->lowestVideoFileId = Pass->highestVideoFileId + 1 ;

			}
			Pass->lowestVideoFileId -= 2;
			Pass->m_bPlaybackFileChangingFlag=true;

		}
		else
		{
			Pass->mode=0;
		}
	}
}

template <class T>
int ThreadParam :: numDigits(T number)
{
	int digits = 0;
	if (number < 0) digits = 1;
	while (number) {
		number /= 10;
		digits++;
	}
	return digits;
}



void *oflinemodeCaptureFrames(void *Data)
{
	ThreadParam* Pass = (ThreadParam*) Data;
	VideoCapture capture;
	Mat frame;
	Mat resizedFrame;
	int nWaitTime;

	overlayvariables overlaydata;
	Mat axBlankBackground;
	overlaydata.BackgroundImage.copyTo(axBlankBackground);
	putText(axBlankBackground, "Loading ", Point(((Pass->m_nScreenWidth/2)-75), Pass->m_nScreenHeight/2.5), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);

	namedWindow("playback Window",WINDOW_NORMAL);
	cvSetWindowProperty("playback Window", CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
	setMouseCallback("playback Window",playbackCallBackWindow, Pass);

	imshow("playback Window",axBlankBackground);
	waitKey(1);

	Mat axUpButton=imread("up.png");
	Mat axUpButtonimageResized;
	Mat axDownButton=imread("down.png");
	Mat axDownButtonimageResized;
	Mat axAnalyzeButton=imread("analyze.png");
	Mat axAnalyzeButtonimageResized;
	Size xSizeOfImages;

	int nFirstRectangleStartx=0;
	int nFirstRectangleStarty=(Pass->m_nScreenHeight/5.5)+35;

	int nFirstRectangleEndx=nFirstRectangleStartx+(Pass->m_nScreenWidth/7);
	int nFirstRectangleEndy=nFirstRectangleStarty+(Pass->m_nScreenHeight/5.5);

	int nSecondRectangleEndx=nFirstRectangleEndx;
	int nSecondRectangleEndy=nFirstRectangleEndy+(Pass->m_nScreenHeight/5.5);

	int nThirdRectangleEndx=nSecondRectangleEndx;
	int nThirdRectangleEndy=nSecondRectangleEndy+(Pass->m_nScreenHeight/5.5);

	xSizeOfImages=Size(Pass->m_nScreenWidth/7, Pass->m_nScreenHeight/5.5);

	resize(axUpButton, axUpButtonimageResized, xSizeOfImages, 0, 0, INTER_CUBIC);
	resize(axDownButton, axDownButtonimageResized, xSizeOfImages, 0, 0, INTER_CUBIC);
	resize(axAnalyzeButton, axAnalyzeButtonimageResized, xSizeOfImages, 0, 0, INTER_CUBIC);

	Rect axFirstRowLeftButton(0,nFirstRectangleStarty, axUpButtonimageResized.cols, axUpButtonimageResized.rows);
	Rect axSecondRowLeftButton(0, nFirstRectangleEndy, axAnalyzeButtonimageResized.cols, axAnalyzeButtonimageResized.rows);
	Rect axThirdRowLeftButton(0,nSecondRectangleEndy, axDownButtonimageResized.cols, axDownButtonimageResized.rows);


	double nStartTimeOfflineMode;
	double nEndTimeOfflineMode;
	double nFPS;



	char vidFile[1024];

	while(Pass->lowestVideoFileId <=  Pass->highestVideoFileId){

		VideoCapture capture;

		sprintf(vidFile, "/home/horusi/recordvideos/%d.avi",Pass->lowestVideoFileId);

		cout << "vidFile :: :"  << vidFile << endl;

		try
		{
			throw capture.open(vidFile);
		}

		catch( bool error)
		{
			std::cout << "exception caught: " << error << std::endl;

			/// if video file present then it throw 1 and if vidoe file not present then
			if(!error){

				cout  << "Could not open the input video: " << vidFile <<  endl;

				stringstream error;

				if(Pass->lowestVideoFileId == 0){

					Mat img = imread("./offlineDefaultImg.jpg", 1);
					error<<"THERE ARE NO VIDEOS RECORED";
					putText(img, error.str(), Point(100,100), FONT_HERSHEY_COMPLEX, 1, CV_RGB(255,255,255), 2);
					imshow("playback Window", img);
					waitKey(2000);
					/// if video is corrupted then it should go to next videos
					Pass->lowestVideoFileId++;
					Pass->currentVideoPlay = Pass->lowestVideoFileId;
					if(Pass->lowestVideoFileId > Pass->highestVideoFileId){
						Pass->lowestVideoFileId = 1;
					}
					img.release();
					continue;

				}else{
					/// if video is corrupted then it should go to next videos
					Pass->lowestVideoFileId++;
					Pass->currentVideoPlay = Pass->lowestVideoFileId;
					if(Pass->lowestVideoFileId > Pass->highestVideoFileId){
						Pass->lowestVideoFileId = 1;
					}

					/// Not showing Display MSG when Video is corrupted
					continue;

				}
			}
		}

		nFPS=capture.get(CV_CAP_PROP_FPS);
		capture.set(CAP_PROP_FPS, nFPS); //not changing anything

		stringstream displayHoruseye;
		stringstream displayMode;

		time_t rawtime;
		struct tm * timeinfo;

		time (&rawtime);
		timeinfo = localtime (&rawtime);

		cout << "CURRENT TIME::" << timeinfo->tm_hour << ":" << timeinfo->tm_min << ":" << timeinfo->tm_sec << endl;

		Pass->startTime.hours    =  timeinfo->tm_hour;
		Pass->startTime.minutes = timeinfo->tm_min;
		Pass->startTime.seconds = timeinfo->tm_sec;

		int rHeight = 0;
		int rWidth = 0;
		char difftime[1024];
		string diffStr = "";
		char fileName[1024];

		while (Pass->mode == 3)
		{
			nStartTimeOfflineMode=cvGetTickCount();
			capture.read(frame);
			if(frame.empty())
			{
				cout<<"NOT Valid Frame"<<endl;
				frame.release();
				break;
			}
			frame.copyTo(Pass->m_aOfflineModeFrames[Pass->m_nWriteCursorOffline]);
			Pass->m_nWriteCursorOffline++;
			Pass->m_nWriteCursorOffline=Pass->m_nWriteCursorOffline%100;
			nEndTimeOfflineMode=(cvGetTickCount()-nStartTimeOfflineMode)/((double)cvGetTickFrequency()*1000);
			Pass->m_nWriteOfflineModeFrameTime=nEndTimeOfflineMode;

			if(Pass->keyOnePress == true){

				Pass->keyOnePress = false;
				cout << "KEY ONE IS PRESS IN -------------MAIN THREAD " << endl;

				Pass->lowestVideoFileId++;

				if(Pass->lowestVideoFileId >= Pass->highestVideoFileId){
					Pass->lowestVideoFileId = 0;
				}

				if(Pass->lowestVideoFileId != 0){
					--Pass->lowestVideoFileId;
				}

				break;

			}

			if(Pass->keyThreePress == true){
				Pass->keyThreePress = false;
				cout << "KEY Three IS PRESS IN -------------MAIN THREAD " << endl;
				if(Pass->lowestVideoFileId  == 1){
					Pass->lowestVideoFileId = 2;
					break;
				}
				Pass->lowestVideoFileId -= 2;
				break;
			}


			/*  needs to be in display thread  */

			resize(frame, resizedFrame, Size(720, 480), 0, 0, INTER_CUBIC); // resize to 1024x768 resolution

			if(Pass->m_bPlayBackAnalysisToggle==true)
			{
				Pass->m_pPedestrian->detect(resizedFrame);
				Pass->m_pVehicle->detect(resizedFrame);

				Pass->drawDetection(resizedFrame,Pass->m_pPedestrian->m_axDetectedObjects,
						Pass->m_pVehicle->m_axDetectedObjects,Pass->m_nEndROIy,Pass->m_nleftendx,Pass->m_nrightendx,Pass->m_nHeightROI,
						Pass->m_bShowDetectedPedestrian,Pass->m_bShowDetectedVehicle,Pass->m_bShowDetectedAll,
						true,Pass->m_sHistogramTemplateImage,Pass->m_bShowROIelemination,
						Pass->m_pSvm,Pass->m_bImageclassification,8,Pass);
			}

			if(Pass->m_bPlaybackFileChangingFlag)
			{
				cout<<"Moving to Next video File"<<endl;
				Pass->m_bPlaybackFileChangingFlag=false;
				break;
			}


			time_t rawtime1;
			struct tm * timeinfo1;

			time (&rawtime1);
			timeinfo1 = localtime (&rawtime1);

			Pass->endTime.hours    =  timeinfo1->tm_hour;
			Pass->endTime.minutes = timeinfo1->tm_min;
			Pass->endTime.seconds = timeinfo1->tm_sec;

			Pass->computeTimeDifference(Pass->startTime, Pass->endTime, &Pass->difference);

			if(Pass->numDigits(Pass->difference.minutes) == 1 || Pass->numDigits(Pass->difference.minutes) == 0 ){
				sprintf(difftime,"0%d", Pass->difference.minutes);
				diffStr = difftime;
			}else{
				sprintf(difftime,"%d", Pass->difference.minutes);
				diffStr =difftime;
			}

			if(Pass->numDigits(Pass->difference.seconds) == 1){
				sprintf(difftime,":0%d", Pass->difference.seconds);
				diffStr = diffStr + difftime;
			}else{
				sprintf(difftime,":%d", Pass->difference.seconds);
				diffStr = diffStr + difftime;
			}

			sprintf(fileName, "FILE : %d.avi", Pass->lowestVideoFileId);

			rHeight = 80;
			rWidth = 150;

			putText(resizedFrame, fileName, Point(rWidth, rHeight), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);

			rHeight = 100;
			rWidth = 150;

			sprintf(fileName, "TIME : %s", diffStr.c_str());
			putText(resizedFrame, fileName, Point(rWidth, rHeight), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);

			rHeight = 40;
			rWidth = 150;

			putText(resizedFrame, "HORUS-I", Point(rWidth, rHeight), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);

			rHeight = 60;
			rWidth = 150;


			putText(resizedFrame, "PLAYBACK MODE", Point(rWidth, rHeight), FONT_HERSHEY_PLAIN, 1.2, CV_RGB(255,255,0), 2);

			cv::Mat roi = resizedFrame(cv::Rect(0, 0, nFirstRectangleEndx ,nFirstRectangleEndy));
			Mat overlay;
			double alpha = 0.6;
			resizedFrame.copyTo(overlay);

			axUpButtonimageResized.copyTo(resizedFrame(axFirstRowLeftButton));
			axAnalyzeButtonimageResized.copyTo(resizedFrame(axSecondRowLeftButton));
			axDownButtonimageResized.copyTo(resizedFrame(axThirdRowLeftButton));

			cv::addWeighted(overlay, alpha, resizedFrame, 1 - alpha, 0, resizedFrame);

			imshow("playback Window",resizedFrame);
			waitKey(1);

		}
		//frame.release();

		Pass->lowestVideoFileId++;

		Pass->currentVideoPlay = Pass->lowestVideoFileId;


		if(Pass->lowestVideoFileId > Pass->highestVideoFileId){
			Pass->lowestVideoFileId = 1;
		}
		capture.release();

		if(Pass->mode == 0){
			cout << "MODE IS ZERO " << endl;
			break;
		}
	}


	Pass->mode = 0;
	cvDestroyWindow("playback Window");
}

void Playbackmode :: playBackMode(void *Data)
{

	ThreadParam* Pass = (ThreadParam*) Data;
	Pass->lowestVideoFileId = Pass->getLowestVideoFileId();
	Pass->highestVideoFileId = Pass->getHighestVideoFileId();


	//cout << "CURRENT VIDEO ::" << Pass->currentVideoPlay << endl;

	///  Update lowestVideoFileId according to currentVideoPlay
	/// If you click on playBackMode then it come to main GUI
	/// again If you click on PlayBackmode then next video should be play.
	if(Pass->currentVideoPlay != 0){

		if(Pass->currentVideoPlay <= Pass->highestVideoFileId){
			Pass->lowestVideoFileId = Pass->currentVideoPlay;
		}
	}

	pthread_t capturethread,displaythread;
	pthread_create( &capturethread, NULL, &oflinemodeCaptureFrames, Data);
	//		pthread_create( &displaythread, NULL, &offlinemodeDisplayFrames, Data);
	pthread_join( capturethread, NULL);

	//		pthread_join( displaythread, NULL);
	cout<<"Threads completed...."<<endl;
	Pass->m_nWriteCursorOffline=0;
	Pass->m_nReadCursorOffline=0;

	return;

}
