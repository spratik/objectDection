/*
 * optionparser.cpp
 *
 *  Created on: 27-Feb-2017
 *      Author: pratik
 */
#include "optionparser.h"
#include <fstream>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#define SIZE 1024


void OptionParse :: help()
{
	cout << "./binary -help\n"
			"   [-videofile= <Source videofile Path.> ]\n"
			"   [-pedestrianclassifier= <Pedestrians HAAR cascade classifier Path.> ]\n"
			"   [-vehicleclassifier= <Cars HAAR cascade classifier Path.> ]\n"
			"   [-showpedestrian=<Detect only Pedestrian.>]\n"
			"   [-showvehicle=<Detect only Vehicles.>]\n"
			"   [-showboth=<Detect Pedestrian and Vehicles.>]\n"
			"   [-showroielemination=<Detect Pedestrian and Vehicles.>]\n"
			"   [-showhistogramcomparision=<Apply histogramComparision.>]\n"
			"   [-heightofroi=<Height from top of the elimination.>]\n"
			"   [-invertvideo=<invert the Roatated Video.>]\n"
			"   [-pedestrianscaling=<scaling for pedestrian.>]\n"
			"   [-vehiclescaling=<scaling for vehicle.>]\n"
			"   [-vehicleminimumsize=<minimum size for vehicle.>]\n"
			"   [-pedestrianminimumsize=<minimum size for pedestrian.>]\n"
			"   [-pedestrianminimumsize=<minimum size for pedestrian.>]\n"
			"   [-pedestrianclassification=<Classify the false from pedestrian>\n"
			"   [-raspberry=<Classify the false from pedestrian>\n"
			"   [-keypad=<Enable keypad>]"
			"	[-displayvideo<Enable DisplayVideo in appmode>]"
			<< "\n" << endl;

}
string OptionParse :: decryption(string encryptedXML)
{
	cout << "DECRYPTED FILE IN OPTIONAL PARSER :: " << encryptedXML << endl;
	//opens the file using infile2 (different input file)
	ifstream infile2(encryptedXML.c_str());

	if(!infile2.is_open()){
		cout << "FILE IS NOT OPEN : : " << encryptedXML.c_str() << endl;
		exit(0);
	}

	char decryptFileName[SIZE];

	string password = "1234";

	if(strstr(encryptedXML.c_str(), "Car")){
		strcpy(decryptFileName, "decryptCar.xml");
	}else if(strstr(encryptedXML.c_str(), "Pedestrin")){
		strcpy(decryptFileName, "decryptedPedestrin.xml");
	}else if(strstr(encryptedXML.c_str(), "HogPedestrianClassifier")){
		strcpy(decryptFileName, "decryptedHogPedestrianClassifier.xml");
	}

	ofstream file(decryptFileName);
	int  i = 0;
	while (!infile2.eof())	//while not the end of the file
	{
		for (i = 0 ;i < 4 ; i++)	//for loop cycles through the positions of the password array until end of file is reached
		{
			if(infile2.eof()){
				//cout << "END OF THE FILE " << endl;
				break;
			}
			char name;	//character from file to be decrypted
			infile2.get(name);	//gets character from file
			if(infile2.eof()){
				//cout << "END OF THE FILE " << endl;
				break;
			}
			name = name + password[0];	//re-adds the first letter of the password
			name = name - password[i];	//subtracts the proper letter from the password array
			file << name ;
			//cout << name;	//prints decrypted character to screen
		}
		i = 0;
	}

	infile2.close();	//closes file that was being decrypted
	file.close();

	return string(decryptFileName);

}
void OptionParse :: passArgument(int argc,char **argv,
		const cv :: String parameters, ThreadParam &tp){

	cv::CommandLineParser parser(argc, argv, parameters);
	if (parser.has("help"))
	{
		help();
		exit(0);
	}

	if(parser.has("keypad")){
		cout << "KEYPAD flag is present" << endl;
		tp.keyPadAccessFlag = true;
	}

	if(parser.has("displayvideo")){
		cout << "KEYPAD flag is present" << endl;
		tp.displayvideoCmdLine = true;
	}

	if (parser.has("videofile"))
	{
		tp.m_sVideoFilename.clear();
		tp.m_sVideoFilename = parser.get<string>("videofile");
	}

	if (parser.has("recordmodetime"))
	{
		//cout << "RECORD MODE : " << tp.recordmin  << endl;

		tp.recordmin = parser.get<int>("recordModeTime");
		//cout << "RECORD MODE : " << tp.recordmin  << endl;
	}

	if (parser.has("pedestrianclassifier"))
	{
		tp.m_bShowDetectedPedestrian = true;
		tp.m_bShowDetectedAll = false;
		tp.sPedestrianFilename = parser.get<string>("pedestrianclassifier");
		//tp.sPedestrianFilename = decryption(tp.sPedestrianFilename);
	}

	if (parser.has("vehicleclassifier"))
	{
		tp.m_bShowDetectedVehicle = true;
		tp.m_bShowDetectedAll = false;
		tp.sVehicleFilename = parser.get<string>("vehicleclassifier");
		//tp.sVehicleFilename = decryption(tp.sVehicleFilename);
		//cout << "CARXML IN OPTIONAL PARSER ::" << tp.sVehicleFilename << endl;
	}

	if (parser.has("showhistogramcomparision"))
	{
		tp.m_bHistogramComparision=true;
		tp.m_sHistogramTemplateImage=parser.get<string>("showhistogramcomparision");
	}

	if (parser.has("showboth"))
	{
		tp.m_bShowDetectedAll = true;
	}

	if (parser.has("showroielemination"))
	{
		tp.m_bShowROIelemination=true;
	}

	if (parser.has("heightofroi"))
	{
		tp.m_nHeightROI=parser.get<float>("heightofroi");
	}

	if (parser.has("invertvideo"))
	{
		tp.m_bInvertVideo=true;
	}


	if (parser.has("pedestrianscaling"))
	{
		tp.fPedestrianDetectionScale=parser.get<float>("pedestrianscaling");
	}

	if (parser.has("vehiclescaling"))
	{
		tp.fVehicleDetectionScale=parser.get<float>("vehiclescaling");
	}


	if (parser.has("pedestrianminimumsize"))
	{
		tp.nPedestrianDetectionminSize=parser.get<float>("pedestrianminimumsize");
	}


	if (parser.has("vehicleminimumsize"))
	{
		tp.nVehicleDetectionminSize=parser.get<float>("vehicleminimumsize");
	}

	if (parser.has("pedestrianclassification"))
	{
		tp.m_bImageclassification=true;
	}


	if (parser.has("raspberry"))
	{
		tp.m_bRaspberry=false;
	}


	if(tp.m_bShowDetectedVehicle==true)
	{
		tp.m_nChoice=3;
	}

	if(tp.m_bShowDetectedPedestrian==true)
	{
		tp.m_nChoice=2;
	}

	if(	tp.m_bShowDetectedAll)

	{
		tp.m_nChoice=1;
		cout<<"Detecting Pedestrian and Vehicles............\n"<<endl;
	}

	if(tp.m_bShowROIelemination)
	{
		tp.m_nChoice=4;
		cout<<"Detecting Pedestrian and Vehicles with ROI Elemination............\n"<<endl;

	}

	if(tp.m_bHistogramComparision)
	{

		tp.m_nChoice=5;
		cout<<"Detecting Pedestrian and Vehicles with Pedestrian histogram matching ............\n"<<endl;

	}

	if(tp.m_bImageclassification)
	{
		tp.m_nChoice=6;
		cout<<"Detecting Pedestrian and Vehicles with SVM Pedestrian Classification ............\n"<<endl;

	}

	if(tp.m_bImageclassification && tp.m_bHistogramComparision)
	{
		tp.m_nChoice=7;
		cout<<"Detecting Pedestrian and Vehicles with SVM histogram Classification ............\n"<<endl;

	}


}

