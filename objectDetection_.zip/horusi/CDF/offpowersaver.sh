#!/bin/sh

sleep 5
xset -display :0 s off
xset -display :0 -dpms
xset -display :0 s noblank
