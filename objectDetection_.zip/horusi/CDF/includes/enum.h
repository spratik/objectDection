/*
 * enum.h
 *
 *  Created on: 19-May-2017
 *      Author: horusi
 */

#ifndef INCLUDES_ENUM_H_
#define INCLUDES_ENUM_H_


enum return_type
{
	SUCCESS,
	VIDEOOPENINGERROR,
	NOVIDEOSFOUND

};


#endif /* INCLUDES_ENUM_H_ */
