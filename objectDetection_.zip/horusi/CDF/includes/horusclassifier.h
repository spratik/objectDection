/*
 * horusclassifierh
 *
 *  Created on: 27-Feb-2017
 *      Author: pratik
 */

#ifndef INCLUDES_HORUSCLASSIFIER_H_
#define INCLUDES_HORUSCLASSIFIER_H_

#include "opencv2/opencv.hpp"
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include "opencv2/imgcodecs.hpp"
#include <opencv2/highgui.hpp>
#include <opencv2/ml.hpp>

#include <string>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>
#include <queue>
#include "difftime.h"
#include <vector>
#include<unistd.h>

using namespace std;
using namespace cv;
using namespace cv::ml;


class HorusClassifier;

class Detectobjectdata
{
public:
	double startTime;
	double endTime;
	int index;
	Rect rect[1024];
	int avg[1024];
	Mat frame;
	int indexforAvg;

	Detectobjectdata(){
		startTime = 0;
		endTime = 0;
		index = 0;
		indexforAvg = 0;
	}

	~Detectobjectdata(){
		startTime = 0;
		endTime = 0;
		index = 0;
		indexforAvg = 0;
	}

};

class ThreadParam : public Detectobjectdata
{
public:
	HorusClassifier* m_pPedestrian;
	HorusClassifier* m_pVehicle;
	HorusClassifier* m_pLicencePlate;

	Detectobjectdata vehicleDetect;
	Detectobjectdata pedDetect;
	Detectobjectdata licencePlateDetect;

	vector <Rect> detectedRect;
	vector <Rect> detectedRectPed;
	vector <Rect> detectedRectLic;


	std::string m_sVideoFilename;
	std::string m_sPedestrianFilename;
	std::string m_sVehicleFilename;
	std::string m_sLicencePlateFileName;
	std::string m_sHistogramTemplateImage;
	std::string m_sRecordedfile;
	cv :: Mat tmpDisplayFrame;
	cv :: Mat tmpDisplayFramePed;
	cv :: Mat tmpDisplayFrameLic;


	int m_nHeightROI;
	int m_nEndROIy;
	int m_nleftendx;
	int m_nrightendx;
	int m_nChoice;
	int m_nPlayBackVideoCount;
	int m_nRecordedVideoCount;
	int m_nObjectDistance;

	bool m_bPlaybackFileChangingFlag=false;
	bool m_bPlayBackAnalysisToggle=false;
	bool m_bShowDetectedPedestrian;
	bool m_bShowDetectedVehicle;
	bool m_bShowDetectedAll;
	bool m_bHistogramComparision;
	bool m_bShowROIelemination;
	bool m_bImageclassification;
	bool m_bInvertVideo;
	bool m_bRaspberry;
	bool m_bAppmodeavilable;

	int m_nScreenWidth;
	int m_nScreenHeight;
	int m_nNoofpedestrianinYellowROI;
	int m_nNoofpedestrianinRedROI;
	int m_nNoofVehicleinYellowROI;
	int m_nNoofVehicleinRedROI;

	int m_nPedestrianLeftCount=0;
	int m_nPedestrianRightCount=0;
	int m_nVehicleLeftCount=0;
	int m_nVehicleRightCount=0;

	int m_nframeHeight;
	int m_nframeWidth;
	int m_nflag;
	int recordmin;
	int m_nKey1;
	int m_nKey2;
	int m_nKey3;
	int m_nModeSwitch;
	int m_nUpdateModeSwitch;

	int m_nvectorsize;

	Mat m_xGuiBackground;
	Mat m_xGuiUpdateBackground;
	Mat m_xGuiBackgroundunresized;
	Mat m_xGuiUpdateBackgroundUnresized;
	Mat m_xAppFrame;
	Mat m_xAppDisplayFrame;
	Mat m_xAppDiplaywitoutvideoFrame;

	std::string sSoftwareVersion;
	std::string sPedestrianFilename;
	std::string sVehicleFilename;
	std::string sVehiceSuperclasifierName;

	int nPedestrianDetectionminSize;
	int nVehicleDetectionminSize;

	float fPedestrianDetectionScale;
	float fVehicleDetectionScale;
	float fLicencePlateDetectionScale;

	int licencePlateNeighbour;
	Ptr<cv :: ml::SVM> m_pSvm;

	int mode;
	int updateMode;
	int citymode;
	bool citymodeUserFeedBackStatus;
	int  highwaymode;
	bool highwaymodeUserFeedBackStatus;
	bool pauseButtonUserFeedBackStatus;
	bool swithchInputUserFeedBackStatus;
	bool videoDisplayUserFeedBackStatus;
	int ndisplayVideo;

	void *thread;
	void *thread1;

	bool interruptFlag;
	pthread_mutex_t dataMutex;

	bool cloudeModeFlag;
	bool networkCheck ;
	Mat updateImage;
	Mat displayFrame;

	pthread_t DisplayThread;
	pthread_t keyReaderThread;
	pthread_t wifiStatusThread;
	pthread_t threadCapture;
	pthread_t threadVehicleDetect;
	pthread_t threadPedestrianDetect;
	pthread_t threadDisplay;
	pthread_t playRecorededVideo;
	pthread_t threadLogging;
	pthread_t recordVideo;
	pthread_t licencePlate;
	pthread_t displayUserFeedback;
	pthread_t waitTime;


	pthread_mutex_t recordMutex1;
	pthread_mutex_t recordMutex2;
	pthread_mutex_t recordSignalMutex;
	pthread_cond_t recordCond;

	bool displayImageFlag;
	bool exitRecordModeThreadFlag;

	int videoId;
	Mat queueFrame[100];
	int writeFrameTime;
	int writeCursor ;
	int readCursor;

	int lowestVideoFileId;
	int highestVideoFileId;
	int currentVideoPlay;

	Mat m_aOfflineModeFrames[100];
	int m_nWriteOfflineModeFrameTime=0;
	int m_nWriteCursorOffline=0;
	int m_nReadCursorOffline=0;

	struct TIME startTime, endTime, difference;

	bool keyOnePress;
	bool keyThreePress;
	bool appModeFlag;
	bool destroyRecordModeWindowFlag;
	bool recordVideoFlag;
	bool exitFromPlayVideo;
	bool noVideoRecordedFlag;
	bool pauseButton;
	bool cameraInputFlag ;
	float Ref_distance;
	float Ref_area;
	float Obj_area;
	int Obj_distance;
	bool videoChangeFlag;
	bool keyPadAccessFlag;
	bool displayvideoCmdLine;
	bool enterIntoSwitchInput;
	bool exitIntoSwitchInput;

	Mat recordFrame;
	// Initializing default values for options
	ThreadParam(){
		m_nframeWidth=720;
		m_nframeHeight=480;
		m_nScreenWidth=720;
		m_nScreenHeight=550;
		sPedestrianFilename="pedestrian.xml";
		sVehicleFilename="car.xml";
		m_sVideoFilename.clear();
		m_sHistogramTemplateImage="template.jpg";
		m_bShowDetectedPedestrian = false;
		m_bShowDetectedVehicle = false;
		m_bShowDetectedAll = true;
		m_bShowROIelemination=false;
		m_bHistogramComparision=false;
		m_bImageclassification=false;
		m_bRaspberry=true;
		m_nHeightROI = 0;
		fPedestrianDetectionScale= 1.03;
		fVehicleDetectionScale=1.03;
		nPedestrianDetectionminSize=16;
		nVehicleDetectionminSize=24;
		m_nChoice=1;
		mode=0;
		citymode=1;
		highwaymode=0;
		ndisplayVideo=0;
		recordmin = 1;//sec
		m_bInvertVideo = false;
		m_nKey1=1;
		m_nKey2=4;
		m_nKey3=5;
		m_nModeSwitch=1;
		m_nUpdateModeSwitch=1;
		interruptFlag = true;
		thread = NULL;
		updateMode = 0;
		thread1 = NULL;
		cloudeModeFlag = false;
		networkCheck  = false;
		displayImageFlag = false;
		exitRecordModeThreadFlag = false;
		keyOnePress = false;
		keyThreePress = false;
		appModeFlag = false;
		writeCursor =  0 ;
		readCursor  = 0;
		destroyRecordModeWindowFlag = false;
		lowestVideoFileId = 0;
		highestVideoFileId = 0;
		currentVideoPlay = 0;
		recordVideoFlag = false;
		exitFromPlayVideo = false;
		noVideoRecordedFlag = false;
		pauseButton = false;
		cameraInputFlag = false;
		Ref_distance = 8;
		Ref_area = 19000;
		Obj_area;
		Obj_distance;
		videoChangeFlag = false;
		fLicencePlateDetectionScale = 0.0;
		licencePlateNeighbour = 0;
		keyPadAccessFlag =false;
		displayvideoCmdLine = false;
		enterIntoSwitchInput = false;
		exitIntoSwitchInput = false;
		citymodeUserFeedBackStatus = false;
		highwaymodeUserFeedBackStatus = false;
		pauseButtonUserFeedBackStatus = false;
		swithchInputUserFeedBackStatus = false;
		videoDisplayUserFeedBackStatus = false;
	}
	~ThreadParam(){}
	void setDefultValue();
	void setROI();
	string decryption(string encryptedXML);
	int buttonPress();
	void  nextMode(Mat);
	void  nextCloudeMode(Mat xGuiWindow);
	void computeTimeDifference(struct TIME t1, struct TIME t2, struct TIME *difference);
	int getLowestVideoFileId();
	int getHighestVideoFileId();
	int getLowestVideoFileId(char fileList[][256], int index);
	int getHighestVideoFileId(char fileList[][256], int index);
	int getfileCount(char *);
	string getCheckSumOfLastRecoredVideo(char *videoFilePath);

	void lineconfiguration(Mat& frame,int nROIend,int nleftxend,
			int nrightxend, int highwaymode);

	void lineconfiguration(Mat& frame,int nROIend,int nleftxend,
			int nrightxend,Point axHighwayROIPolygone[],Point axCityROIPolygone[], void* Data);

	void drawPedestrianVehicle(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight);

	void drawPedestrian(Mat& frame,std::vector<Rect> pedestrian, int &nCountingVehicleFalseObjects,
			int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight);

	void drawVehicle(Mat& frame,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,
			int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight);

	void drawVehiclePedestrianROI(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle,
			int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,
			int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,Point aROIPolygone[],int &nSizeofROIPolygone,bool &bBountingBoxInside,void* Data);

	void drawVehiclePedestrianHistogramComparision(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle,
			int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,
			int &nCountingVehicles,int &ROIHeight,Point aROIPolygone[],int &nSizeofROIPolygone,
			bool &bBountingBoxInside,int nHistogramChannels[],Mat& xTemplateHistogram,MatND& xcropedImageHistogram,int nHistogramSize[],const float* fHistogramRanges[]);

	void drawVehiclePedestrianSVM(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle,
			int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,Ptr<SVM> svm);

	void drawSVMHistogram(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,
			int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,
			Point aROIPolygone[],int &nSizeofROIPolygone,bool &bBountingBoxInside,int nHistogramChannels[],
			Mat& xTemplateHistogram,MatND& xcropedImageHistogram,int nHistogramSize[],const float* fHistogramRanges[],Ptr<SVM> svm);

	bool  onSegment(Point p, Point q, Point r);

	bool isInROI(Point x1,Point x2,Point x3,Point x4,Point aROIPolygone[],int nSizeofROIPolygone);

	void  checkAppMode(Mat& frame,Detectobjectdata pedestrian,Detectobjectdata vehicle, Detectobjectdata licenceRect, int &nCountingVehicleFalseObjects,
			int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,
			Point aHighwayROIPolygone[],int &nSizeofHighwayROIPolygone,bool &bHighwayROIBountingBoxInside,
			void* Data,Point aCityROIPolygone[],int &nSizeofCityROIPolygone,bool &bCityROIBountingBoxInside,
			int nHistogramChannels[],Mat& xTemplateHistogram,MatND& xcropedImageHistogram,int nHistogramSize[],const float* fHistogramRanges[]);

	void  checkAppMode(Mat& frame,std::vector<Rect> pedestrian,std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,
				int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,int &nCountingVehicles,int &ROIHeight,
				Point aHighwayROIPolygone[],int &nSizeofHighwayROIPolygone,bool &bHighwayROIBountingBoxInside,
				void* Data,Point aCityROIPolygone[],int &nSizeofCityROIPolygone,bool &bCityROIBountingBoxInside,
				int nHistogramChannels[],Mat& xTemplateHistogram,MatND& xcropedImageHistogram,int nHistogramSize[],const float* fHistogramRanges[]);
	bool isInside(Point polygon[], int n, Point p);

	int  orientation(Point p, Point q, Point r);

	void drawDetection(Mat& frame,Detectobjectdata pedestrian,
			Detectobjectdata vehicle, Detectobjectdata licenceRect, int nEndy,int nleftendx,int nrightendx,
			int ROIHeight,bool bshowdetectedPedestrian,
			bool bshowDetectedVehicle,bool bshowDetectedAll,bool bcompareHistogram,
			string templateImage,bool bROIDisplay,
			Ptr<SVM> svm,bool bImageclassification,int nChoice,void* Data);

	void drawDetection(Mat& frame,std::vector<Rect> pedestrian,
			std::vector<Rect> vehicle, int nEndy,int nleftendx,int nrightendx,
			int ROIHeight,bool bshowdetectedPedestrian,
			bool bshowDetectedVehicle,bool bshowDetectedAll,bool bcompareHistogram,
			string templateImage,bool bROIDisplay,
			Ptr<SVM> svm,bool bImageclassification,int nChoice,void* Data);
	bool  doIntersect(Point p1, Point q1, Point p2, Point q2);

	template <class T>
	int  numDigits(T number);

	void  pauseFunction(Mat preAnalysedFrame,Mat analysedFrame,void *Data);
	int  errorHandler(VideoCapture &capture,bool error);
	void  setInitParaForPlayRecordedVideo();
	void playRecordedVideo();
	int getVideoCount(bool lowestVideoCount = false);
};

class HorusClassifier : public ThreadParam
{
public:
	CascadeClassifier m_xClassifier;
	String m_sClassifierPath;
	double m_nScaleFactor;
	int m_nMinNeighbors;
	int m_nFlags;
	Size m_xMinSize;
	Size m_xMaxSize;
	double m_nTimeTaken;
	int m_nDisplayShape;
	std::vector<Rect> m_axDetectedObjects;

	HorusClassifier(){

		m_sClassifierPath="";
		m_nScaleFactor = 0;
		m_nMinNeighbors = 0;
		m_nFlags = 0;
		m_xMinSize = Size(0, 0);
		m_xMaxSize = Size(0, 0);
		m_nTimeTaken = 0;
		m_nDisplayShape = 0;
		m_axDetectedObjects.clear();
	}
	~HorusClassifier(){}

	vector <Rect>  detect( Mat& frame, double m_nScaleFactor, int m_nMinNeighbors,
			int m_nFlags, Size m_xMinSize);
	void  detect( Mat& frame);
	void display(Mat &frame);
	void loadXml(string fileName, float objectScale, int size,
			int displayShap, int minNeg);
	void loadXml(string fileName, float objectScale);

	void initHOGFeature();

};




#endif /* INCLUDES_HORUSCLASSIFIER_H_ */
