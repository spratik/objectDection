/*
 * modes.h
 *
 *  Created on: 28-Feb-2017
 *      Author: pratik
 */

#ifndef INCLUDES_MODES_H_
#define INCLUDES_MODES_H_

#include <opencv2/opencv.hpp>
#include "horusclassifier.h"
using namespace cv;
using namespace cv::ml;


class Modes
{
	cv :: Mat frame;
	cv :: Mat resizedFrame;
	cv :: Mat resizedRotatedFrame;
	cv :: Mat resizedRotatedFrameGray;
	int videCount;
public:
	Modes(){
		frame.release();
		resizedFrame.release();
		resizedRotatedFrame.release();
		resizedRotatedFrameGray.release();
		videCount = 1;
	}
	~Modes(){
		frame.release();
		resizedFrame.release();
		resizedRotatedFrame.release();
		resizedRotatedFrameGray.release();
	}

	void  processMode(ThreadParam &tp);
	bool  onSegment(Point p, Point q, Point r);
	int   orientation(Point p, Point q, Point r);
	bool  doIntersect(Point p1, Point q1, Point p2, Point q2);
	bool  isInside(Point polygon[], int n, Point p);
	bool  isInROI(Point x1,Point x2,Point x3,Point x4,
			Point aROIPolygone[],int nSizeofROIPolygone);

	void  drawPedestrianVehicle(Mat& frame,std::vector<Rect> pedestrian,
			std::vector<Rect> vehicle,int &nCountingVehicleFalseObjects,
			int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,
			int &nCountingVehicles,int &ROIHeight);

	void  drawPedestrian(Mat& frame,std::vector<Rect> pedestrian,
			int &nCountingVehicleFalseObjects,
			int &nCountingPedestrianFalseObjects,
			int &nCountingPedestrian,
			int &nCountingVehicles,int &ROIHeight);

	void wifiStatus(ThreadParam *tp);

	void  drawVehicle(Mat& frame,std::vector<Rect> vehicle,
			int &nCountingVehicleFalseObjects,
			int &nCountingPedestrianFalseObjects,
			int &nCountingPedestrian,
			int &nCountingVehicles,int &ROIHeight);

	void  drawVehiclePedestrianROI(Mat& frame,std::vector<Rect> pedestrian,
			std::vector<Rect> vehicle,
			int &nCountingVehicleFalseObjects,
			int &nCountingPedestrianFalseObjects,
			int &nCountingPedestrian,
			int &nCountingVehicles,
			int &ROIHeight,Point aROIPolygone[],int &nSizeofROIPolygone,
			bool &bBountingBoxInside,void* Data);
	void  switchUpdateMode(Mat xGuiWindow,void *Data);

	void  drawVehiclePedestrianHistogramComparision(Mat& frame,
			std::vector<Rect> pedestrian,std::vector<Rect> vehicle,
			int &nCountingVehicleFalseObjects,
			int &nCountingPedestrianFalseObjects,
			int &nCountingPedestrian,int &nCountingVehicles,
			int &ROIHeight,Point aROIPolygone[],
			int &nSizeofROIPolygone,bool &bBountingBoxInside,
			int nHistogramChannels[],
			Mat& xTemplateHistogram,MatND& xcropedImageHistogram,
			int nHistogramSize[],const float* fHistogramRanges[]);

	void  drawVehiclePedestrianSVM(Mat& frame,
			std::vector<Rect> pedestrian,std::vector<Rect> vehicle,
			int &nCountingVehicleFalseObjects,
			int &nCountingPedestrianFalseObjects,
			int &nCountingPedestrian,int &nCountingVehicles,
			int &ROIHeight,Ptr<SVM> svm);

	void  drawSVMHistogram(Mat& frame,std::vector<Rect> pedestrian,
			std::vector<Rect> vehicle,
			int &nCountingVehicleFalseObjects,int &nCountingPedestrianFalseObjects,
			int &nCountingPedestrian,int &nCountingVehicles,
			int &ROIHeight,Point aROIPolygone[],int &nSizeofROIPolygone,
			bool &bBountingBoxInside,int nHistogramChannels[],
			Mat& xTemplateHistogram,MatND& xcropedImageHistogram,
			int nHistogramSize[],const float* fHistogramRanges[],Ptr<SVM> svm);

	void  checkAppMode(Mat& frame,std::vector<Rect> pedestrian,
			std::vector<Rect> vehicle, int &nCountingVehicleFalseObjects,
			int &nCountingPedestrianFalseObjects,int &nCountingPedestrian,
			int &nCountingVehicles,int &ROIHeight,Point aHighwayROIPolygone[],
			int &nSizeofHighwayROIPolygone,bool &bHighwayROIBountingBoxInside,
			void* Data,Point aCityROIPolygone[],int &nSizeofCityROIPolygone,
			bool &bCityROIBountingBoxInside,int nHistogramChannels[],
			Mat& xTemplateHistogram,MatND& xcropedImageHistogram,
			int nHistogramSize[],const float* fHistogramRanges[]);
	void  checkAppModeOverlay(Mat& frame,std::vector<Rect> vehicle,std::vector<Rect> pedestrian,
			void * data,bool overlay);


	void lineconfiguration(Mat& frame,int nROIend,int nleftxend,
			int nrightxend, int highwaymode);
	void lineconfiguration(Mat& frame,int nROIend,int nleftxend,
			int nrightxend,Point axHighwayROIPolygone[],
			Point axCityROIPolygone[], void *Data);
	void  displayBoth(Mat& frame,std::vector<Rect> pedestrian,
			std::vector<Rect> vehicle,int nEndy,int nleftendx,
			int nrightendx,int ROIHeight,bool bshowdetectedPedestrian,
			bool bshowDetectedVehicle,bool bshowDetectedAll,
			bool bcompareHistogram,string templateImage,bool bROIDisplay,
			Ptr<SVM> svm,bool bImageclassification,int nChoice,void* Data);

	void  pauseFunction(Mat preAnalysedFrame,Mat analysedFrame,void *Data);

	void  demoMode(void *Data);

	void  dashMode(void * Data);

	template <class T>
	int  numDigits(T number);

	int  strToInt(char *str);

	void  recordMode(void * Data);



	void  appMode(void* Data);

	void update(ThreadParam *tp);

	void  highguiDesign(Mat &guiBackground,int nScreenWidth, int nScreenHeight);

	void  uploadVideo(ThreadParam *tp);

	void  updateSoftware(ThreadParam *tp);

	void downloadData(const char *cmd);

	int getVideoId();

	string getUploadid(ThreadParam *tp);

	int getVideoCount();

	void createFolderInServer(string uploadId, string macAdd);

	void uploadFile(int vidCount,string macAdd,string uploadId);

	void uploadVideoOneAfterAnother(string uploadId, string macAdd, ThreadParam *globalData);

	int checkVideoFile(int vidCount);
};



#endif /* INCLUDES_MODES_H_ */
