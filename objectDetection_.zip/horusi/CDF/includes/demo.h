/*
 * demo.h
 *
 *  Created on: May 23, 2017
 *      Author: pratik
 */

#ifndef DEMO_H_
#define DEMO_H_

#include "horusclassifier.h"

class Demo
{

public:
	void demoMode(void *Data);
	void pauseFunction(Mat preAnalysedFrame,Mat analysedFrame,void *Data);


};

#endif /* DEMO_H_ */
