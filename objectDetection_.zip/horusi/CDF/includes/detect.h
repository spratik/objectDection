/*
 * detect.h
 *
 *  Created on: 08-Dec-2016
 *      Author: nchaturvedi
 */

#ifndef SRC_DETECT_H_
#define SRC_DETECT_H_

#define MIN (0)
#define MAX (255)



#endif /* SRC_DETECT_H_ */
