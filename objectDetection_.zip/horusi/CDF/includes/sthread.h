/*
 * Thread.h
 *
 *  Created on: Jul 29, 2016
 *      Author: root
 */

#ifndef THREAD_H_
#define THREAD_H_

#include <pthread.h>
#include "horusclassifier.h"


class Sthread
{

public:
	void initializeThread(ThreadParam & );

	void release(ThreadParam &);

};

#endif /* THREAD_H_ */
