/*
 * Playbackmode.h
 *
 *  Created on: 22-May-2017
 *      Author: horusi
 */

#ifndef INCLUDES_PLAYBACKMODE_H_
#define INCLUDES_PLAYBACKMODE_H_

#include "horusclassifier.h"

class Playbackmode
{
public:

	void playBackMode(void *Data);


};



#endif /* INCLUDES_PLAYBACKMODE_H_ */
