/*
 * optionparser.h
 *
 *  Created on: 27-Feb-2017
 *      Author: pratik
 */

#ifndef INCLUDES_OPTIONPARSER_H_
#define INCLUDES_OPTIONPARSER_H_

#include <opencv2/opencv.hpp>
#include <iostream>
#include "horusclassifier.h"
using namespace std;
using namespace cv;

class OptionParse
{
public:
    void passArgument(int argc,char **argv, const cv :: String parameters,
    		ThreadParam &tp);
	string decryption(string encryptedXML);
    void help();
};



#endif /* INCLUDES_OPTIONPARSER_H_ */
