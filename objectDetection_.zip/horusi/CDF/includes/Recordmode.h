/*
 * Recordmode.h
 *
 *  Created on: 16-May-2017
 *      Author: horusi
 */

#ifndef INCLUDES_RECORDMODE_H_
#define INCLUDES_RECORDMODE_H_

#include "horusclassifier.h"

class Recordmode
{

public:
	int getVideoId();
	int getVideoCount();


	void recordMode(void * Data);

};


#endif /* INCLUDES_RECORDMODE_H_ */
