/*
 * difftime.h
 *
 *  Created on: Feb 21, 2017
 *      Author: spratik
 */

#ifndef DIFFTIME_H_
#define DIFFTIME_H_
struct TIME
{
	int seconds;
	int minutes;
	int hours;
};



#endif /* DIFFTIME_H_ */
