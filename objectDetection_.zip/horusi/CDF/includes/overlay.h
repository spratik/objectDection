/*
 * overlay.h
 *
 *  Created on: 19-May-2017
 *      Author: horusi
 */

#ifndef OVERLAY_H_
#define OVERLAY_H_
#include <opencv2/opencv.hpp>
#include <sstream>

using namespace cv;
using namespace std;

struct overlayvariables
{
	Mat BackgroundImage;
	Mat BackgroundImageunresized;

	stringstream displayHoruseye;
	String DisplayStringVideoMode;
	stringstream displayMode;

	int nHeightofBackground;
	int nWidthofBackground;
	int hgap;

	double startTime;
	double Endtime;

	Size xSizeOfImages;

	Mat pedestrianiconImage;
	Mat pedestrianiconImageresized;

	Mat pedestrianrediconImage;
	Mat pedestrianrediconImageresized;

	Mat vehicleiconImage;
	Mat vehicleiconImageresized;

	Mat vehiclerediconImage;
	Mat vehiclerediconImageresized;

	int nLeftFirstRectangleStartx;
	int nLeftFirstRectangleStarty;

	int nLeftSecondRectangleStartx;
	int nLeftSecondRectangleStarty;

	int nLeftThirdRectangleStartx;
	int nLeftThirdRectangleStarty;

	int nLeftFourthRectangleStartx;
	int nLeftFourthRectangleStarty;

	int nRightFirstRectangleStartx;
	int nRightFirstRectangleStarty;

	int nRightSecondRectangleStartx;
	int nRightSecondRectangleStarty;

	int nRightThirdRectangleStartx;
	int nRightThirdRectangleStarty;

	int nRightFourthRectangleStartx;
	int nRightFourthRectangleStarty;

	int nButtonTotalRegion;
	int nFirstButtonEndx;
	int nFirstButtonEndy;

	int nFirstButtonStartx;
	int nFirstButtonStarty;

	int nSecondButtonStarty;

	int nSecondButtonEndx;
	int nSecondButtonEndy;

	int nSecondButtonStartx;
	int nSecondButtonStart;

	int nThirdButtonEndx;
	int nThirdButtonEndy;

	int nThirdButtonStartx;
	int nThirdButtonStarty;

	int playRecordedVideoFirstStartx;
	int playRecordedVideoFirstStarty;

	int playRecordedVideoFirstEndx;
	int playRecordedVideoFirstEndy;

	int playRecordedVideoSecondStartx;
	int playRecordedVideoSecondStarty;

	int playRecordedVideoSecondEndx;
	int playRecordedVideoSecondEndy;

	int buttonRegionCol;
	int buttonRegionRow;

	overlayvariables()
	{
		displayHoruseye<<"HORUS-i";
		displayMode<<"APP MODE";
		BackgroundImageunresized=imread("BackGround.jpg");
		resize(BackgroundImageunresized, BackgroundImage, Size(640, 480), 0, 0, INTER_CUBIC); // resize to 1024x768 resolution

		nHeightofBackground=BackgroundImage.rows;
		nWidthofBackground=BackgroundImage.cols;
		hgap=10;

		xSizeOfImages=Size(BackgroundImage.cols/5, BackgroundImage.rows/5);

		pedestrianiconImage=imread("pedestrian.png");
		resize(pedestrianiconImage, pedestrianiconImageresized, xSizeOfImages, 0, 0, INTER_CUBIC); // resize to 1024x768 resolution

		pedestrianrediconImage=imread("pedestrianred.png");
		resize(pedestrianrediconImage, pedestrianrediconImageresized, xSizeOfImages, 0, 0, INTER_CUBIC); // resize to 1024x768 resolution

		vehicleiconImage=imread("vehicle.png");
		resize(vehicleiconImage, vehicleiconImageresized, xSizeOfImages, 0, 0, INTER_CUBIC); // resize to 1024x768 resolution

		vehiclerediconImage=imread("vehiclered.png");
		resize(vehiclerediconImage, vehiclerediconImageresized, xSizeOfImages, 0, 0, INTER_CUBIC); // resize to 1024x768 resolution

		nLeftFirstRectangleStartx=(nWidthofBackground/10);
		nLeftFirstRectangleStarty=nHeightofBackground/4;

		playRecordedVideoFirstStartx = nWidthofBackground - (nWidthofBackground /6);
		playRecordedVideoFirstStarty = 0;

		playRecordedVideoFirstEndx = nWidthofBackground;
		playRecordedVideoFirstEndy = nHeightofBackground/3;


		playRecordedVideoSecondStartx = playRecordedVideoFirstStartx;
		playRecordedVideoSecondStarty = playRecordedVideoFirstEndy;

		playRecordedVideoSecondEndx = nWidthofBackground,
		playRecordedVideoSecondEndy = (nHeightofBackground/3) * 2;

		nLeftSecondRectangleStartx=nLeftFirstRectangleStartx;
		nLeftSecondRectangleStarty=nLeftFirstRectangleStarty+pedestrianiconImageresized.rows+hgap;

		nLeftThirdRectangleStartx=nLeftFirstRectangleStartx+pedestrianiconImageresized.cols;
		nLeftThirdRectangleStarty=nLeftFirstRectangleStarty;

		nLeftFourthRectangleStartx=nLeftThirdRectangleStartx;
		nLeftFourthRectangleStarty=nLeftThirdRectangleStarty+vehicleiconImageresized.rows+hgap;

		nRightFirstRectangleStartx=(nWidthofBackground/2);
		nRightFirstRectangleStarty=nHeightofBackground/4;

		nRightSecondRectangleStartx=nRightFirstRectangleStartx;
		nRightSecondRectangleStarty=nRightFirstRectangleStarty+pedestrianiconImageresized.rows+hgap;

		nRightThirdRectangleStartx=nRightFirstRectangleStartx+pedestrianiconImageresized.cols;
		nRightThirdRectangleStarty=nRightFirstRectangleStarty;

		nRightFourthRectangleStartx=nRightThirdRectangleStartx;
		nRightFourthRectangleStarty=nRightThirdRectangleStarty+vehicleiconImageresized.rows+hgap;

		Rect LeftpedestrianRectangle(nLeftFirstRectangleStartx,nLeftFirstRectangleStarty, pedestrianiconImageresized.cols, pedestrianiconImageresized.rows);
		Rect LeftPedestrianredRectangle(nLeftSecondRectangleStartx,nLeftSecondRectangleStarty, pedestrianiconImageresized.cols, pedestrianiconImageresized.rows);
		Rect LeftVehicleRectangle(nLeftThirdRectangleStartx,nLeftThirdRectangleStarty, pedestrianiconImageresized.cols, pedestrianiconImageresized.rows);
		Rect LeftVehicleredRectangle(nLeftFourthRectangleStartx,nLeftFourthRectangleStarty, pedestrianiconImageresized.cols, pedestrianiconImageresized.rows);

		Rect RightpedestrianRectangle(nRightFirstRectangleStartx,nRightFirstRectangleStarty, pedestrianiconImageresized.cols, pedestrianiconImageresized.rows);
		Rect RightPedestrianredRectangle(nRightSecondRectangleStartx,nRightSecondRectangleStarty, pedestrianiconImageresized.cols, pedestrianiconImageresized.rows);
		Rect RightVehicleRectangle(nRightThirdRectangleStartx,nRightThirdRectangleStarty, pedestrianiconImageresized.cols, pedestrianiconImageresized.rows);
		Rect RightVehicleredRectangle(nRightFourthRectangleStartx,nRightFourthRectangleStarty, pedestrianiconImageresized.cols, pedestrianiconImageresized.rows);

		nButtonTotalRegion=(BackgroundImage.cols-BackgroundImage.cols/10)-(BackgroundImage.cols/10);
		nFirstButtonEndx=(BackgroundImage.cols/10)+(nButtonTotalRegion/3);
		nFirstButtonEndy=BackgroundImage.rows;

		nFirstButtonStartx=BackgroundImage.cols/10;
		nFirstButtonStarty=BackgroundImage.rows/1.15;

		nSecondButtonEndx=nFirstButtonEndx+(nButtonTotalRegion/3);
		nSecondButtonEndy=BackgroundImage.rows;

		nSecondButtonStartx=nFirstButtonEndx;
		nSecondButtonStarty=BackgroundImage.rows/1.15;

		nThirdButtonEndx=BackgroundImage.cols-BackgroundImage.cols/10;
		nThirdButtonEndy=BackgroundImage.rows;

		nThirdButtonStartx=nSecondButtonEndx;
		nThirdButtonStarty=BackgroundImage.rows/1.15;
	}
	~overlayvariables(){

		BackgroundImage.release();
		BackgroundImageunresized.release();
		pedestrianiconImage.release();
		pedestrianiconImageresized.release();
		pedestrianrediconImage.release();
		pedestrianrediconImageresized.release();
		vehicleiconImage.release();
		vehicleiconImageresized.release();
		vehiclerediconImage.release();
		vehiclerediconImageresized.release();
	}
};



#endif /* OVERLAY_H_ */
