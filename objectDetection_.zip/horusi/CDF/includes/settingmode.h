/*
 * setting.h
 *
 *  Created on: May 23, 2017
 *      Author: horusi
 */

#ifndef SETTING_H_
#define SETTING_H_

#include "horusclassifier.h"

class Settingmode
{
public:
	void settingMode(void * Data);

};

#endif /* SETTING_H_ */
