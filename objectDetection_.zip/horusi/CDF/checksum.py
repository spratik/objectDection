import hashlib
import zipfile
import os
import sys
import getpass
import time

def md5(fname):
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

totalchecksum=0
count=0
username=getpass.getuser()
path="/home/"+getpass.getuser()+"/upload/"

try:
   path=sys.argv[1]
except:
   print "path not valid"

print path

if(os.path.exists(path)):
   print "folder exist"
else:
   print "Folder not exist please check....\n\n"
   print "Please Create folder and /home/username/upload/ and store data and try it"
   sys.exit(1) 

buildfile=open("build.txt","r")
buildversion=time.strftime(buildfile.read())
buildfile.close()
file=open(path+"horusiversioncheck","w")
file.write(buildversion)
file.close()

files = os.listdir(path)

print files
for filename in files:
   filename=path+filename
   if((filename != path+"horusi.zip") and (filename != path+"checksumtotal")):
       hchecksum=md5(filename)
       temp = int(hchecksum, 16)
       if(filename != path+"checksumtotal"):
           totalchecksum=totalchecksum+temp
       print filename+" : "+str(hchecksum)
       count=count+1


file=open(path+"checksumtotal","w")
file.write(str(totalchecksum))
file.close()

print "\nSum of check sum :"+str(totalchecksum)
print str(count)+" files checksum has been added\n"


