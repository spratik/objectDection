import hashlib
import sys

def md5(fname):
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()



#filepath="/home/horusi/recordvideos/1.avi"


try:
  filepath=sys.argv[1]
except:
  print "Not valid path from user for source folder to copy"


hchecksum=md5(filepath)
print hchecksum

