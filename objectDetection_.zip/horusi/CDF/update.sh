#/bin/bash

sudo rm -rf /home/horusi/cache

sudo mkdir /home/horusi/cache

sudo chmod 400 /tmp/identity.pem

sudo scp -i /tmp/identity.pem ubuntu@ec2-35-165-233-252.us-west-2.compute.amazonaws.com:/home/ubuntu/UpdateSoftware/horusi.zip /home/horusi/cache/

sudo python  downloadandcheck.py /home/horusi/cache/ /home/horusi/horus-i/
