#include<stdio.h>
int main()
{
	int n,a[100];
	int i;
	printf("\nenter the number of elements : \n");
	scanf("\n%d", &n);
	printf("\nenter the values : \n");
	for(i=0;i<n;i++)
	{
		scanf("\n%d",&a[i]);
	}
	printf("\nvalues befor sorting : ");
	for(i=0;i<n;i++)
	{
		printf("\n%d",a[i]);
	}
        
       	radixsort(&a,n);
		
}
int radixsort(int a[],int n)
{
	int i,j,q=1,r=10,temp;
	max(&a,n);
	int s=max(&a,n);
	while(s!=0)
	{
		for(i=0;i<n-1;i++)
		{
			for(j=0;j<n-i-1;j++)
			{
				if((a[j]/q)%r > (a[j+1]/q)%r)
				{
					temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		
		q=q*10;
		s--;
		
	}
	printf("\nvalues after sorting : \n");
			for(i=0;i<n;i++)
			{
				printf("%d\n",a[i]);
			}
	
}
int max(int a[],int n)
{
	int size=0,bigv,i;
	bigv=a[0];
	for(i=0;i<n;i++)
	{
		if(bigv<a[i])
		{
			bigv=a[i];
		}
	}
		while(bigv)
		{
			bigv=bigv/10;
			size++;
		}
	return size;	
}
