#include<stdio.h>
int main()
{
	int r,c,i,j;
	printf("enter the number of rows\n");
	scanf("%d",&r);
	printf("enter the number of columns\n");
	scanf("%d",&c);
	int a[r][c],b[r][c];
	printf("enter the elements of matrix 1\n");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	printf("enter the elements of matrix 2\n");
		for(i=0;i<r;i++)
		{
			for(j=0;j<c;j++)
			{
				scanf("%d",&b[i][j]);
			}
		}
	printf("matrix before swap\n");
		printf("\na= ");
		for(i=0;i<r;i++)
		{
			for(j=0;j<c;j++)
			{
				printf("%d  ",a[i][j]);
			}
			printf("\n   ");
		}
		printf("\n");
		printf("b= ");
		for(i=0;i<r;i++)
			{
			for(j=0;j<c;j++)
			{
				printf("%d  ",b[i][j]);
			}
			printf("\n   ");
			}
	printf("\nmatrix after swap\n");
	printf("\na= ");
		for(i=0;i<r;i++)
				{
				for(j=0;j<c;j++)
					{
					a[i][j]=a[i][j]+b[i][j];
					b[i][j]=a[i][j]-b[i][j];
					a[i][j]=a[i][j]-b[i][j];
						printf("%d  ",a[i][j]);
					}
					printf("\n   ");
				}
				printf("\n");
				printf("b= ");
		for(i=0;i<r;i++)
				{
				for(j=0;j<c;j++)
					{
						printf("%d  ",b[i][j]);
					}
					printf("\n   ");
				}
}

