#include<stdio.h>
int main()
{
	int count=0;
	char SPACE=' ';
	char c;
	FILE *fp;
	fp=fopen("/home/horusi/siva/songs/sample.text","r");
	if(fp==NULL)
	{
		printf("\nfile doesn`t exist\n");
	}
	else {
		while(c!=EOF)
		{
			c=getc(fp);
			if(c==SPACE)
			{
				count++;
			}
		}
		printf("\n%d\n",count+1);
		
	fclose(fp);

	     }
	return 0;
}
