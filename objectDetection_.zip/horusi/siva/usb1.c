#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>
#include <iostream>

int main(void)
{
    
    FILE *f = popen("mount | grep /dev/sda1", "r");
    if (NULL != f)
    {
        if (EOF == fgetc(f))
        {
	    system("sudo mount /dev/sda1 mount");
	    puts("/dev/sda1 is mounted Now");

        }
        else
        {
            puts("/dev/sda1 is already mounted");
	    system("sudo df -h | grep -i /dev/sda1");
        }        
             pclose(f);        
    } 
    return 0;
}

