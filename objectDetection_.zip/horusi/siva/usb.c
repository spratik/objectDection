#include <stdio.h>
#include <dirent.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
using namespace std;
int main()
{
  	DIR *pdirectory;
	struct dirent *aFolder; 
	pdirectory= opendir("/dev");
	if (pdirectory != NULL)
	{
		while (aFolder = readdir(pdirectory))
		{
			if(strstr(aFolder->d_name,"sd"))
			{
				cout<<"USB Found /dev/"<<aFolder->d_name<<endl;
				
			}
		}
		system("sudo mount /dev/sda1 backup");
	}
}


